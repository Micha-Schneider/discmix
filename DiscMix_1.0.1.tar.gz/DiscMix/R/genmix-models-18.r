################################################################################
#####    Models for genmix; part of DiscMix                                #####
################################################################################
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker

###### to save time, we initialize all possible MLSP.model objects and store
###### them. then, the genmix driver functions (which follow below) can use them
###### without having to recompute them in every EM iteration.
multinomlogitmodel <- multinomlogit()
sequentiallogitmodel <- sequentiallogit()
cumulativelogitmodel <- cumulativelogit()
cubbinomialmodel <- CUBbinomiallogit()
#curemodel <- cure()

#' Internal function for concomitant ('z'-component)
#' @author Wolfgang Pößnecker and Micha Schneider
#' @param y response
#' @param z covariates for concomitant
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import MRSP
#'
## first the default function for concomitant models:
## (note: any concomitant function must return a list with entries "mu", "coef"
##  and "df". all self-written functions for the concomitant model must take
##  the same arguments as concomitant.default below.)
concomitant.default <- cmpfun(function(y, z, M, coef = NULL, weights, ...){

 colnames(y) <- 1:ncol(y) #hier: y = postweights (nicht uebergebener y-vector)
 dotlist <- list(...)

 if(!is.list(coef)) coef <- list(coef)
 if(!all(v.allequal(coef[[1]], 0))){
  coef[[1]] <- sweep(coef[[1]], 2, c(coef[[1]][1,]))
 }

 if("standardize" %in% names(dotlist)){
  standardize <- dotlist$standardize
 }else{
  standardize <- F
 }

 if("rel.tol" %in% names(dotlist)){
  rel.tol <- dotlist$rel.tol
 }else{
  rel.tol <- 1e-6  #get("rel.tol", envir = parent.frame())  # i.e. use same rel.tol as in genmix
 }

 if("c.maxiter" %in% names(dotlist)){
   max.iter <- dotlist$c.maxiter
 }else{
   max.iter <- 2000
 }

 if(!("lambda" %in% names(dotlist))){
  dotlist$lambda <- 123456789
  #dotlist$lambda <- 0 #MS
 }

 #if("constr" %in% names(dotlist)){
 # constr <- dotlist$constr
 #}else{
  #constr <- 1
  #if(!is.null(coef)){
  # coef[[1]] <- sweep(coef[[1]], 2, coef[[1]][1,, drop = T])
  #}
 # constr <- "symmetric"
 #}

 if(!("constr" %in% names(dotlist))){
  dotlist$constr <- 1 # "symmetric" -> 1.Modellkomponente Refernz #bei 2 2te refernz
 }
 if(!("grpindex" %in% names(dotlist))){
   dotlist$grpindex <- list(1:ncol(z))
 }

 if(!("penindex" %in% names(dotlist))){
  if(dotlist$lambda != 123456789){ # MS: dotlist$lambda != 0
   dotlist$penindex <- list(c(10, rep(12, ncol(z)-1))) # 12 normales Lasso;
   standardize = F #MS besser aussenrum
  }else{
   dotlist$penindex <- list(rep(10, ncol(z)))
  }
 }

 if(("offset" %in% names(dotlist))){
   if(is.null(dotlist$offset))
     dotlist$offset<-NULL}

 if(!("control" %in% names(dotlist))){
  dotlist$control <- MRSP.control(standardize = standardize, rel.tol = rel.tol, max.iter=max.iter,
                                  doMLfit = T, computeDF = T, fisher = F, expandcall = F)
 }

 dat <- list(y=y, x=z)
 fit <- eval(as.call(c(as.symbol("MRSP.fit"), list(dat = substitute(dat),       ## NOTE the double list!! This is necessary for technical reasons.
                       coef.init = coef, weights = weights,
                       model = multinomlogitmodel), dotlist)))

 out <- list(fit = fit,
             coef = fit@coef,
             coef.stand = fit@coef.stand,
             mu = fit@mu,
             df = fit@df,
             penalty = fit@penalty)
 out
})

#' Internal function for linear regression models
#' @author Wolfgang Pößnecker
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import stats
#'
## a model driver function for linear regression models:
## (note: any model driver function must return a list with entries "coef",
##  "mu", "df", "logl" and "loglik". "loglik" is the overall loglikelihood,
##  "logl" is the vector (or matrix in case of a multivariate response) of
##  (unweighted) loglikelihood values for the individual observations. Also
##   note that all self-written model driver functions must take the same
##   arguments as linreg below.)
linreg <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){
 totalweights <- postweight * weights

 fit <- lm(y ~ 0 + x, weights = totalweights, offset = offset, model = F, ...)

 coef <- fit$coefficients
 mu <- fit$fitted.values
 df <- sum(!v.allequal(coef, 0)) + 1 # +1 for the dispersion!
 #sigma <- summary(fit)$sigma ## this is problematic because it allows for sigmas that go to zero.
 res <- fit$residuals
 sigma <- sqrt(sum(totalweights * res^2/mean(totalweights)) / (nrow(y) - df + 1))
 ## note for future self: the line above is much better since it automatically tunes up the sigma
 ## estimates for empty or close-to-empty components. therefore, this formula avoids almost empty
 ## components with a perfect fit. (and thus the whole "RSS -> 0 => sigma -> 0 => loglik of that
 ## component -> infty => loglik of whole mixture -> infty" - pitfall.)

 logl <- dnorm(y, mean = mu, sd = sigma, log = T)
 loglik <- sum(weights*logl)

 out <- list(fit = fit,
             coef = coef,
             mu = mu,
             df = df,
             sigma = sigma,
             logl = logl,
             loglik = loglik)
 out
}

#' Internal model function for linear regression models
#' @author Wolfgang Pößnecker
#' @param M number of components
#' @export
## and a constructor function for the call to genmix:
linregmix <- function(M){
 modellist <- list(); length(modellist) <- M
 for(m in seq_len(M)){
  modellist[[m]] <- "linreg"
 }
 modellist
}

################################################################################

#' Internal function for linear regression models 2
#' @author Wolfgang Pößnecker
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param sigma fixed sigma parameter
#' @param ... further arguments
#' @import stats
#'
## a model driver function for linear regression models with fixed, prespecified
## variances:
fixvarlinreg <- function(y, x, M, coef = NULL, postweight, offset, weights, sigma, ...){
 totalweights <- postweight * weights

 fit <- lm(y ~ 0 + x, weights = totalweights, offset = offset, model = F, ...)

 coef <- fit$coefficients
 mu <- fit$fitted.values
 df <- sum(!v.allequal(coef, 0)) + 1 # +1 for the dispersion!
 res <- fit$residuals

 logl <- dnorm(y, mean = mu, sd = sigma, log = T)
 loglik <- sum(weights*logl)

 out <- list(fit = fit,
             coef = coef,
             mu = mu,
             df = df,
             sigma = sigma,
             logl = logl,
             loglik = loglik)
 out
}

#' Internal model function for linear regression models 2
#' @author Wolfgang Pößnecker
#' @param M number of mixture components
#' @export
## the constructor:
fixvarlinregmix <- function(M){
 modellist <- list(); length(modellist) <- M
 for(m in seq_len(M)){
  modellist[[m]] <- "fixvarlinreg"
 }
 modellist
}

################################################################################

#' Internal function for discrete uniform component
#' @author Wolfgang Pößnecker and Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
## model driver function for discrete uniform distributions:
discr.uniform <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){
 if(is.matrix(y)){
  if(any(rowSums(y) == 0)){
   K <- ncol(y) + 1
  }else if(all(rowSums(y) == 1)){
   K <- ncol(y)
  }else{
   K <- max(y)
  }
 }else{
  K <- max(y)
 }

 nobs <- nrow(y)

 coef <- NULL
 mu <- matrix((1+K)/2, nrow = nobs, ncol = K)
 df <- 0 # maybe 1?!

 logl <- rep(log(1/K), nobs)
 loglik <- sum(weights*logl)

 out <- list(coef = coef,
             mu = mu,
             df = df,
             logl = logl,
             loglik = loglik)
 out
}

#' Internal function for sequential logit component
#' @author Wolfgang Pößnecker and Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import MRSP
#'
## a model driver function for sequential logit models:
seqlogit <- function(y, x, M, coef = NULL, postweight, offset = NULL, weights, ...){
 totalweights <- postweight * weights
 dotlist <- list(...)
 # it is important that the first column of x is the intercept column...
 if(!(all(abs(x[,1]) == 1))) stop("the first column of x must be an intercept column!")

 if("standardize" %in% names(dotlist)){
  standardize <- dotlist$standardize
 }else{
   if (dotlist$cublass==T){standardize <- F} #F
   else{standardize <- T} # T NEU wichtig, wenn genmix alleine aufgerufen wird; ansonsten auf F ?!
 }

 if("rel.tol" %in% names(dotlist)){
  rel.tol <- dotlist$rel.tol
 }else{
  rel.tol <- 1e-6  #get("rel.tol", envir = parent.frame())  # i.e. use same rel.tol as in genmix
 }

 if("maxiter2" %in% names(dotlist)){
   max.iter <- dotlist$maxiter2
 }else{
   max.iter <- 2000 #2000 MRSP-default; 30 vgam-default
 }


 if(!("lambda" %in% names(dotlist))){
  dotlist$lambda <- 123456789   # w
   #dotlist$lambda <- 0           # m
 }

 if(!("penindex" %in% names(dotlist))){
  if(dotlist$lambda != 123456789){ # dotlist$lambda != 0 # MS
   dotlist$penindex <- list(c(16, rep(4, ncol(x)-1)))   # pen # w: dotlist$penindex <- list(c(10, rep(4, ncol(x)-1))); ich: list(c(16, rep(4, ncol(x)-1)))                                              ### EDITME
  }else{
   dotlist$penindex <- list(c(10, rep(40, ncol(x)-1)))   # nicht pen # MS: list(c(16, rep(40, ncol(x)-1))) ; w: list(c(10, rep(40, ncol(x)-1)))                                            ### EDITME
  }
 }


 if(!("control" %in% names(dotlist))){
  #dotlist$control <- MRSP.control(standardize=standardize, rel.tol=rel.tol,
  #                                doMLfit = F, computeDF = F, fisher=F, expandcall=F) # lasso?!
  dotlist$control <- MRSP.control(standardize=standardize, rel.tol=rel.tol, max.iter=max.iter,
                                  doMLfit = T, computeDF = T, fisher=F, expandcall=T) # genmix
  # Achtung doMLfit+compuetDF fuerr penmix=F fuer genmix=T MS !!!!!!!!!!!

 ### EDITME - if you write a genmix driver based on MLSP, you might want to change some of these...
 }

 dat <- list(y=y, x=x)
if (dotlist$cublass==T){
fit <- eval(as.call(c(as.symbol("MRSP.fit"), list(dat = substitute(dat),
                                                  coef.init = coef, weights = totalweights, constr = "none",                            # if you use a different model class, you maybe need a different constraint
                                                  offset = offset, model = sequentiallogitmodel), dotlist)))} # MRSP ### EDITME - if you want to write a new genmix driver based on MLSP, just copy # totalweigths
else{
fit <- eval(as.call(c(as.symbol("MRSP.fit"), list(dat = substitute(dat),
                                                    coef.init = coef, weights = totalweights, constr = "none",                            # if you use a different model class, you maybe need a different constraint
                                                    offset = offset, model = sequentiallogitmodel, fusion="adja"), dotlist)))} # MRSP ### EDITME - if you want to write a new genmix driver based on MLSP, just copy
#adaptive=F, refit=F ?, fusion="adja" -> bei genmix-Aufruf direkt wichtig
 coef <- fit@coef
 mu <- fit@mu
 df <- fit@df
 penalty <- fit@penalty

 #getlogl <- function(y, mu){
 #                     y <- cbind(y, 1 - rowSums(y))
 #                     mu <- cbind(mu, 1 - rowSums(mu))
 #                     mu[which(mu <= 1e-8)] <- 1e-8
 #                     mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
 #                     logl <-  rowSums(y * log(mu))
 #                     return(logl)
 #                    }

 #logl <- getlogl(y = y, mu = mu)
 logl <- fit@model@logl(y = y, mu = mu)
 loglik <- sum(weights*logl)

 out <- list(fit = fit,
             coef = coef,
             mu = mu,
             df = df,
             logl = logl,
             loglik = loglik,
             penalty = penalty)
 out
}

#' Internal model function for disc. uniform + seq. logit
#' @author Wolfgang Pößnecker and Micha Schneider
#' @param M number of mixture components
#' @export
## the constructor for a mixture between one discrete uniform distribution and
## M-1 sequential logit models:
uniform.seqlogit.mix <- function(M){
 modellist <- list(); length(modellist) <- M
 modellist[[1]] <- "discr.uniform"
 for(m in 2:M){
  modellist[[m]] <- "seqlogit"
 }
 modellist
}

#if(dotlist[which(names(dotlist)=="survindicator")] ==T) ...
#if(dotlist$survindicator==T) ...

#' Internal function for sequential logit (vgam) component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import VGAM
#' @import stats
#'
##### sequential logit model with vgam:
vgamseqlogit <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){
 #require(VGAM)
 dotlist <- list(...)

 if("maxiter2" %in% names(dotlist)){
   max.iter <- dotlist$maxiter2
 }else{
   max.iter <- 30 #2000 MRSP-default; 30 vgam-default
 }
 #dotlist$family <- NULL
 y.names <- dotlist$y.names
 #x.names <- dotlist$x.names[-1] #

 y <- as.ordered(c(y[,1]))
 if(is.matrix(coef)){
  coef <- c(coef[-1,1], coef[1,])
 }

 if(ncol(x) == 1 & all(x == 1)){
   x.names <- dotlist$x.names
   #form <- as.formula(y ~ 0 + x)
   dat <- as.data.frame(cbind(y,x))
   colnames(dat) <- c(y.names,x.names)
   form <- as.formula(paste(paste(y.names),"~","0 +", paste(x.names, collapse= "+")))
  parallel <- F
 }else{
   x.names <- dotlist$x.names[-1]
  #form <- as.formula(y ~ x[,-1])
   dat <- as.data.frame(cbind(y,x[,-1]))
   colnames(dat) <- c(y.names,x.names)
   form <- as.formula(paste(paste(y.names),"~", paste(x.names, collapse= "+")))
  parallel <- T
 }

 totalweights <- postweight * weights
 fit <- vglm(formula = form, family = sratio(parallel = parallel), weights = totalweights,
             offset = offset, coefstart = coef, data=dat, maxit=max.iter, ...)

 fit@call$offset <- offset ### MS
 coef <- fit@coefficients
 mu <- fit@fitted.values
 df <- fit@df.total - fit@df.residual
 y <- fit@y

 getlogl <- function(y, mu){
                      mu[which(mu <= 1e-8)] <- 1e-8
                      mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
                      logl <-  rowSums(y * log(mu))
                      return(logl)
                     }

 logl <- getlogl(y = y, mu = mu)
 loglik <- sum(weights*logl)

 out <- list(fit = fit,
             coef = coef,
             mu = mu,
             df = df,
             logl = logl,
             loglik = loglik)
 out
}

#' Internal model function for disc. uniform + seq. logit (vgam) component
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## a constructor function for vgamseqlogit mixed with one uniform component:
uniform.seqlogit.mix.vgam <- function(M){
 modellist <- list(); length(modellist) <- M
 modellist[[1]] <- "discr.uniform"
 for(m in 2:M){
  modellist[[m]] <- "vgamseqlogit"
 }
 modellist
}

#' Internal model function for seq. logit
#' @author Wolfgang Pößnecker
#' @param M number of mixture components
#' @export
## a constructor function for a mixture of M seqlogit models based on MLSP:
seqlogit.mix <- function(M){
 modellist <- list(); length(modellist) <- M
 for(m in 1:M){
  modellist[[m]] <- "seqlogit"
 }
 modellist
}

#' Internal model function for seq. logit (vgam)
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## a constructor function for a mixture of M seqlogit models based on vgam:
seqlogit.mix.vgam <- function(M){
 modellist <- list(); length(modellist) <- M
 for(m in 1:M){
  modellist[[m]] <- "vgamseqlogit"
 }
 modellist
}

#' Internal function for cumulative logit (vgam) component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import VGAM
#' @import stats
#'
#'
#################################################################################
# cumulative
##### vgam:
vgamcumlogit <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){
  #require(VGAM)
  dotlist <- list(...)
  y.names <- dotlist$y.names

  if("maxiter2" %in% names(dotlist)){
    max.iter <- dotlist$maxiter2
  }else{
    max.iter <- 30 #2000 MRSP-default; 30 vgam-default
  }

  #x.names <- dotlist$x.names[-1] #
  #dotlist$family2 <- NULL

  y <- as.ordered(c(y[,1]))
  if(is.matrix(coef)){
    coef <- c(coef[-1,1], coef[1,])
  }

  if(ncol(x) == 1 & all(x == 1)){
    x.names <- dotlist$x.names
    #form <- as.formula(y ~ 0 + x)
    dat <- as.data.frame(cbind(y,x))
    colnames(dat) <- c(y.names,x.names)
    form <- as.formula(paste(paste(y.names),"~","0 +", paste(x.names, collapse= "+")))
    parallel <- F
  }else{
    x.names <- dotlist$x.names[-1]
    #form <- as.formula(y ~ x[,-1])
    dat <- as.data.frame(cbind(y,x[,-1]))
    colnames(dat) <- c(y.names,x.names)
    form <- as.formula(paste(paste(y.names),"~", paste(x.names, collapse= "+")))
    parallel <- T
  }
  totalweights <- postweight * weights
  fit <- vglm(formula = form, family = cumulative(parallel = parallel), weights = totalweights,
              offset = offset, coefstart = coef, data=dat, maxit = max.iter, trace=T, ...) # andere family
  #exclude <- c(1, which(names(fit@call) %in% c("formula")))
  #fit@call[-exclude] <- mget(names(fit@call[-exclude]), envir = as.environment(-1)) ######
  fit@call$offset <- offset ### Micha

  coef <- fit@coefficients
  mu <- fit@fitted.values # fuer jede spalte von y
  df <- fit@df.total - fit@df.residual
  y <- fit@y # matrix mit 1/0

  getlogl <- function(y, mu){
    mu[which(mu <= 1e-8)] <- 1e-8
    mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
    logl <-  rowSums(y * log(mu))
    return(logl)
  }

  logl <- getlogl(y = y, mu = mu)
  loglik <- sum(weights*logl)
  out <- list(fit = fit,
              coef = coef,
              mu = mu,
              df = df,
              logl = logl,
              loglik = loglik)
  out
}

#' Internal model function for disc. uniform + cum. logit (vgam)
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## a constructor function for vgamseqlogit mixed with one uniform component:
uniform.cumlogit.mix.vgam <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "discr.uniform"
  for(m in 2:M){
    modellist[[m]] <- "vgamcumlogit"
  }
  modellist
}

################################################################################

#' Internal function for cumulative logit component
#' @author Micha Schneider and Wolfgang Pößnecker
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import MRSP
#'
## a model driver function for sequential logit models:
cumlogit <- function(y, x, M, coef = NULL, postweight, offset = NULL, weights, ...){
  totalweights <- postweight * weights
  dotlist <- list(...)
  y <- dotlist$ymat
  # it is important that the first column of x is the intercept column...
  if(!all(x[,1] == 1)) stop("the first column of x must be an intercept column!")

  if("standardize" %in% names(dotlist)){
    standardize <- dotlist$standardize
  }else{
    standardize <- F
  }

  if("rel.tol" %in% names(dotlist)){
    rel.tol <- dotlist$rel.tol
  }else{
    rel.tol <- 1e-6 #1e-6  #get("rel.tol", envir = parent.frame())  # i.e. use same rel.tol as in genmix
  }

  if("maxiter2" %in% names(dotlist)){
    max.iter <- dotlist$maxiter2
  }else{
    max.iter <- 2000 #2000 MRSP-default; 30 vgam-default
  }

  if(!("lambda" %in% names(dotlist))){
    dotlist$lambda <- 123456789   # w
    #dotlist$lambda <- 0           # m
  }

  if(!("penindex" %in% names(dotlist))){
    if(dotlist$lambda != 123456789){ # dotlist$lambda != 0 # MS
      dotlist$penindex <- list(c(16, rep(4, ncol(x)-1)))   # pen # w: dotlist$penindex <- list(c(10, rep(4, ncol(x)-1))); MS: list(c(16, rep(4, ncol(x)-1)))                                              ### EDITME
    }else{
      dotlist$penindex <- list(c(10, rep(40, ncol(x)-1)))   # nicht pen # ich: list(c(16, rep(40, ncol(x)-1))) ; w: list(c(10, rep(40, ncol(x)-1)))                                            ### EDITME
      #dotlist$penindex[[1]][7] <- 10 #nur spezielles Modell
    }
  }

  if(!("control" %in% names(dotlist))){
    dotlist$control <- MRSP.control(standardize=standardize, rel.tol=rel.tol, max.iter=max.iter,
                                    doMLfit = T, computeDF = T, fisher=F, expandcall=F)
    # Achtung doMLfit+compuetDF fuer penmix=F fuer genmix=T MS !!!!!!!!!!!

    ### EDITME - if you write a genmix driver based on MLSP, you might want to change some of these...
    #print(dotlist$control)
  }
  # debug
  #fistaControl <- fista.control(BB.stepsize=T,m=5)# letzte m iterationen; Abbruchkriterium fuer Schrittlaenge; worse.max: wieviele iteration verschlechterung akzeptiert bevor abbruch
  # fista M-Schritt in einzelner Iteration nicht monoton <-> EM monoton wenn im M-Schritt optimiert

  #dotlist$fista.control <- fistaControl
  dat <- list(y=y, x=x)
  fit <- eval(as.call(c(as.symbol("MRSP.fit"), list(dat = substitute(dat),
                                                    coef.init = coef, weights = totalweights, constr = "none",                           # if you use a different model class, you maybe need a different constraint
                                                    offset = offset, model = cumulativelogitmodel), dotlist))) # MRSP               ### EDITME - if you want to write a new genmix driver based on MLSP, just copy
  ### the code of this function ("seqlogit") and change the model-entry in the line above.
  ### you might have to initialize the MLSP.model at the top of this file if you want to
  ### use one that isnt already included (see top of this file...)
  #fit <- MRSP.fit(dat = dat, penindex = penindex, grpindex = grpindex, model = sequentiallogitmodel(),
  #                adaptive = F, refit = F, control = MRSP.control(), lambda=5.4,
  #                 lambdaF=1.5, fusion="adja")

  coef <- fit@coef
  mu <- fit@mu
  df <- fit@df

  penalty <- fit@penalty

  getlogl2 <- function(y, mu){
                       y <- cbind(y, 1 - rowSums(y))
                       #mu <- cbind(mu, 1 - rowSums(mu))
                       mu[which(mu <= 1e-8)] <- 1e-8
                       mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
                       logl <-  rowSums(y * log(mu))
                       return(logl)
                      }

  logl <- getlogl2(y = y, mu = mu)
  loglik <- sum(weights*logl)

  out <- list(fit = fit,
              coef = coef,
              mu = mu,
              df = df,
              logl = logl,
              loglik = loglik,
              penalty = penalty)
  out
}

#' Internal model function for disc. uniform + cum. logit
#' @author Micha Schneider and Wolfgang Pößnecker
#' @param M number of mixture components
#' @export
## the constructor for a mixture between one discrete uniform distribution and
## M-1 sequential logit models:
uniform.cumlogit.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "discr.uniform"
  for(m in 2:M){
    modellist[[m]] <- "cumlogit"
  }
  modellist
}

#' Internal model function for beta binomial (without covars) + cum. logit
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
betabinom.cumlogit.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "beta.binom"
  for(m in 2:M){
    modellist[[m]] <- "cumlogit"
  }
  modellist
}

#' Internal model function for beta binomial (with covars) + cum. logit
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
betabinom.vglm.cumlogit.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "beta.binom.vglm"
  for(m in 2:M){
    modellist[[m]] <- "cumlogit"
  }
  modellist
}
################################################################################

#' Internal function for adjacent category logit (vgam) component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import VGAM
#' @import stats
#'
# Acat
vgamacatlogit <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){
 #require(VGAM)
 dotlist <- list(...)
 y.names <- dotlist$y.names

 if("maxiter2" %in% names(dotlist)){
   max.iter <- dotlist$maxiter2
 }else{
   max.iter <- 30 #2000 MRSP-default; 30 vgam-default
 }

 y <- as.ordered(c(y[,1]))
 if(is.matrix(coef)){
   coef <- c(coef[-1,1], coef[1,])
 }

 if(ncol(x) == 1 & all(x == 1)){
   x.names <- dotlist$x.names
   #form <- as.formula(y ~ 0 + x)
   dat <- as.data.frame(cbind(y,x))
   colnames(dat) <- c(y.names,x.names)
   form <- as.formula(paste(paste(y.names),"~","0 +", paste(x.names, collapse= "+")))
   parallel <- F
 }else{
   x.names <- dotlist$x.names[-1]
   #form <- as.formula(y ~ x[,-1])
   dat <- as.data.frame(cbind(y,x[,-1]))
   colnames(dat) <- c(y.names,x.names)
   form <- as.formula(paste(paste(y.names),"~", paste(x.names, collapse= "+")))
   parallel <- T
 }
  totalweights <- postweight * weights
  fit <- vglm(formula = form, family = acat(reverse=TRUE,parallel = parallel), weights = totalweights,
             offset = offset, coefstart = coef, data=dat, maxit=max.iter, ...) # andere family
  #exclude <- c(1, which(names(fit@call) %in% c("formula")))
 #fit@call[-exclude] <- mget(names(fit@call[-exclude]), envir = as.environment(-1)) ######
 fit@call$offset <- offset ### Micha

 coef <- fit@coefficients
 mu <- fit@fitted.values
 df <- fit@df.total - fit@df.residual
 y <- fit@y

 getlogl <- function(y, mu){
  mu[which(mu <= 1e-8)] <- 1e-8
  mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
  logl <-  rowSums(y * log(mu))
  return(logl)
 }

 logl <- getlogl(y = y, mu = mu)
 loglik <- sum(weights*logl)

 out <- list(fit = fit,
             coef = coef,
             mu = mu,
             df = df,
             logl = logl,
             loglik = loglik)
 out
}

#' Internal model function for disc. uniform + acat logit (vgam)
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## a constructor function for vgamseqlogit mixed with one uniform component:
uniform.acatlogit.mix.vgam <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "discr.uniform"
  for(m in 2:M){
    modellist[[m]] <- "vgamacatlogit"
  }
  modellist
}
################################################################################


################################################################################
## model driver function for discrete uniform distributions:
#dbb {TailRank}
#dbetabinom {emdbook}
#
#' Internal function for beta binomial (without covars) component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import VGAM
#'
beta.binom <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){
  #require(VGAM)
  dotlist <- list(...)
  alpha <- dotlist$alpha
  if(is.null(alpha)) {alpha <- 1}
  if(is.matrix(y)){
    # y 0,1-Matrix
    if(any(rowSums(y) == 0) && max(y)==1){
      K <- ncol(y) + 1
    }else {
      if(all(rowSums(y) == 1)){
        K <- ncol(y)}
      else{
        # Ein-Spaltrige y-Matrix
        if(ncol(y)==1){
          if(min(y)==1){
            y <- y-1}
          K <- max(y)+1
        }
      }
    }
  }
  # nicht-Matrix=Vektor?!
  else{
    if (min(y)==1){
      y <- y-1}
    K <- max(y)+1
  }

  nobs <- nrow(y)

  ##
  coef <- NULL
  bet <- alpha
  #K <- K+1 # test
  #y <- y+1 # test
  #mu <- matrix(K*alpha/(alpha+beta), nrow = nobs, ncol = K) # allg
  mu <- matrix((K-1)*0.5, nrow = nobs, ncol = K) # k-1, da von 0,...,n
  #sigma <- sqrt(K*mu*(1-mu)*(1+(K-1)*1/(alpha+beta+1)) # allg
  sigma <- sqrt(((K-1)/4)*(2*alpha+K-1)/(2*alpha+1))
  df <- 1 # maybe 1?!
  #logl2<- log(choose(K-1,y-1)*beta(alpha+y-1,bet+(K-1)-(y-1))/beta(alpha,bet))
  #logl <- dbetabinom(y, size = K-1, prob=0.5, rho=1/(2*alpha+1),log=T) # identisch mit version b
  #logl <- apply(logl, 1, min) # jetzt vektor davor matrix
  logl <- dbetabinom.ab(y, size = K-1, shape1=alpha, shape2=alpha, log=T) #vgam version b
  #logl <- log(choose(K,y)*beta(alpha+y,alpha+K-y)/beta(alpha,alpha))
  loglik <- sum(weights*logl)
  #loglik2 <- sum(weights*logl2)
  out <- list(coef = coef,
              mu = mu,
              sigma=sigma,
              df = df,
              logl = logl,
              loglik = loglik)
  out
}

#' Internal model function for beta binomial (without covars) + cum. logit (vgam)
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## a constructor function for vgamseqlogit mixed with one uniform component:
betabinom.cumlogit.mix.vgam <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "beta.binom"
  for(m in 2:M){
    modellist[[m]] <- "vgamcumlogit"
  }
  modellist
}

#' Internal model function for disc. uniform + beta binomial (without covars)
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
uniform.betabinom.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "discr.uniform"
  for(m in 2:M){
    modellist[[m]] <- "beta.binom"
  }
  modellist
}
################################################################################
## model driver function for discrete uniform distributions:
#dbb {TailRank}
#dbetabinom {emdbook}
#
#' Internal function for beta binomial (with covars) component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import VGAM
#' @import stats
#'
beta.binom.vglm <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){
  #require(VGAM)
  dotlist <- list(...)
  y.names <- dotlist$y.names
  x.names <- dotlist$x.names[-1]
  ishape1 <- dotlist$ishape1
  ishape2 <- dotlist$ishape2
  BS.seedindex <- dotlist$BS.seedindex

  if("maxiter1" %in% names(dotlist)){
    max.iter <- dotlist$maxiter1
  }else{
    max.iter <- 30 #2000 MRSP-default; 30 vgam-default
  }

  if(is.null(ishape1)){ishape1 <- 1}

  if(!is.null(dotlist$u)) {
    x <- dotlist$u
    x.names <- dotlist$u.names[-1]} # auch -1?
  #alpha <- dotlist$alpha
  if(is.matrix(y)){
    # y 0,1-Matrix
    if(any(rowSums(y) == 0) && max(y)==1){
      K <- ncol(y) + 1
    }else {
      if(all(rowSums(y) == 1)){
      K <- ncol(y)}
        else{
        # Ein-Spaltrige y-Matrix
        if(ncol(y)==1){
          if(min(y)==1){
            y <- y-1}
        K <- max(y)+1
        }
      }
    }
  }
  # nicht-Matrix=Vektor?!
  else{
    if (min(y)==1){
      y <- y-1}
    K <- max(y)+1
  }
  #print(K)
  #s1 <- log(alpha)
  #s2 <- log((alpha*(3-K))/(K-1))
  nobs <- nrow(y)
  if(is.matrix(coef)){
    coef <- c(coef[-1,1], coef[1,])
  }

  cmat <- matrix(1,2,1) # Constraint for alpha=beta for all parameters!
  #print(cmat)
  if(ncol(x) == 1 & all(x == 1)){
    #form <- as.formula(y ~ 0 + x)
    if (length(x.names)==0){
      x.names <- "Constant"
      colnames(x) <- x.names}
    dat <- as.data.frame(cbind(y,x,K-1))
    colnames(dat) <- c(y.names,x.names,"K")
    form <- as.formula(paste(paste("cbind(",y.names,", K -",y.names,")"),"~","0 +", paste(x.names, collapse= "+")))
    clist <-rep(list(cmat), length(x.names))
    names(clist) <- x.names
    }else{
    #form <- as.formula(y ~ x[,-1])
    #dat <- as.data.frame(cbind(y,x[,-1]))
    #colnames(dat) <- c(y.names,x.names)
    dat <- as.data.frame(cbind(y,x[,-1],K-1))
    colnames(dat) <- c(y.names,x.names,"K")
    form <- as.formula(paste(paste("cbind(",y.names,", K -",y.names,")"),"~", paste(x.names, collapse= "+")))
    #form <- as.formula(paste(paste("cbind(",y.names,",", K-1,"-",y.names,")"),"~", paste(x.names, collapse= "+")))
    clist <-rep(list(cmat), length(x.names)+1)
    #clist <- vector("list", length=length(x.names)+1)
    names(clist) <- c("(Intercept)",x.names)
    }

  totalweights <- postweight * weights
#print("beta.binomal:")
  fit <- vglm(formula = form, family=betabinomialff(lshape1=loge(bvalue=1e-6),lshape2=loge(bvalue=1e-6)), weights = totalweights,
         offset=offset, coefstart=coef, data = dat, constraints=clist, trace=T, ishape1=ishape1, ishape2=ishape2,maxit=max.iter)

  coef <- coef(fit)
  fit@call$offset <- offset ### M

  df <- fit@df.total - fit@df.residual
  pred1 <- predict(fit, newdata=data.frame(x),type="link")

    mu_matrix1 <- matrix(NA, nrow=nrow(y),ncol=K)
  y_matrix <- matrix(0, nrow=nrow(y),ncol=K)
  for (i in 1:nrow(y)){
    mu_matrix1[i,] <- dbetabinom.ab(0:(K-1),size=(K-1),shape1=exp(pred1[i,1]),shape2=exp(pred1[i,2]),log=F) #
    y_matrix[i,y[i]+1] <- 1 # weil davor auf 0 verschoben
  }
  test <- round(rowSums(mu_matrix1),3)
  if( !all(test==1))
  {
    test_index <- which(test!=1)
    for (j in 1:length(test_index))
    {
      #(a1 <- dbinom(0:(K-1),size=(K-1),prob=0.5, log=F))
      #(a2 <-dbetabinom.ab(0:(K-1),size=(K-1),shape1=exp(12),shape2=exp(12),log=F))
      #(a2 <-dbetabinom.ab(0:(K-1),size=(K-1),shape1=exp(-15),shape2=exp(-15),log=F))
      #sum(a2)
      #sum((a1-a2)^2)
      # if alpha plus infinitive -> binomial-distribution
      if (pred1[test_index[j],1]> 12){
            mu_matrix1[test_index[j],] <- dbinom(0:(K-1),size=(K-1),prob=0.5, log=F) #extreme Verteilung bei alpha unendlich
            }
      # if alpha 0 -> 0.5...0.5 mit Korrekturfaktor 1e-8
      if (pred1[test_index[j],1]< -15){
        mu_matrix1[test_index[j],] <- c(0.5-(K-2)*1e-8/2,rep(1e-8,K-2),0.5-(K-2)*1e-8/2)
             }
      }
  }
  if (!all(round(rowSums(mu_matrix1),3)==1))
  {
    warning("not all rowSums of mu-Matrix are equal to 1 (betabinomial)")
  }
  getlogl <- function(y, mu){
    mu[which(mu <= 1e-8)] <- 1e-8
    mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
    logl <-  rowSums(y * log(mu))
    return(logl)
  }
  logl1 <- getlogl(y = y_matrix, mu = mu_matrix1)
  loglik1 <- sum(weights*logl1)
  ###
  # alt
  #logl2 <- getlogl(y = y_matrix2, mu = mu_matrix2)
  #loglik2a <- sum(totalweights*logl2)
  #loglik2 <- sum(weights*logl2)
  ###
  logl3 <- as.numeric(logLik(fit,summation=F)/totalweights) # praktisch nicht identisch mit anderen
  loglik3 <- sum(weights*logLik(fit,summation=F)/totalweights)

 if (!all(round(logl1-as.numeric(logl3),2)==0))
 {
   if (is.null(BS.seedindex))
   {
    number <- sample(999999,1)
   }
   else{
    number <- BS.seedindex
   }
 #save(fit,y,totalweights,mu_matrix1,loglik1,loglik3,logl1,logl3,pred1, file=paste("error",number,".RData",sep="_"))
}
  mu <- mu_matrix1

  out <- list(fit = fit,
              coef = coef,
              mu = mu,
              df = df,
              logl = logl1,
              loglik = loglik1)
  out
}

#' Internal model function for beta binomial (with covars) + cum. logit (vgam)
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## a constructor function for vgamseqlogit mixed with one uniform component:
betabinom.vglm.cumlogit.mix.vgam <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "beta.binom.vglm"
  for(m in 2:M){
    modellist[[m]] <- "vgamcumlogit"
  }
  modellist
}

#' Internal model function for beta binomial (with covars) + shifted binomial
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
betabinom.vglm.cubbinomial.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "beta.binom.vglm"
  for(m in 2:M){
    modellist[[m]] <- "cubbinomiallasso"
  }
  modellist
}

#' Internal model function for disc. uniform + beta binomial (with covars)
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
uniform.betabinom.vglm.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "discr.uniform"
  for(m in 2:M){
    modellist[[m]] <- "beta.binom.vglm"
  }
  modellist
}

#' Internal model function for beta binomial (with covars) + acat logit (vgam)
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
betabinom.vglm.acatlogit.mix.vgam <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "beta.binom.vglm"
  for(m in 2:M){
    modellist[[m]] <- "vgamacatlogit"
  }
  modellist
}

# aus genmix_functions
#shifted_bin <- function (k=10,xi)
#{
#  r <- 1:k
#  prob <- vector(length=k)
#  for (i in r)
#  {
#    prob[i] <- choose(k-1,r[i]-1)*(xi^(k-r[i]))*(1-xi)^(r[i]-1)
#  }
#  prob
#}

#probs <- shifted_bin(k=10,xi=0.35)
#dbinom(0:9,9,prob=0.65) # damit identisch !!!
################################################################################
## Survival Modelle
################################################################################

#' Internal function for zero hazard component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
zero.hazard <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){

  K <- ncol(y) ### y selbe struktur wie in "seqlogit"-treiberfunktion (glm anders!)
  nobs <- nrow(y)

  coef <- NULL
  mu <- matrix(0, nrow = nobs, ncol = K)
  df <- 0 # maybe 1?!

  getlogl <- function(y, mu){
    y <- cbind(y, 1 - rowSums(y))
    mu <- cbind(mu, 1 - rowSums(mu))
    mu[which(mu <= 1e-8)] <- 1e-8
    mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
    logl <-  rowSums(y * log(mu))
    return(logl)
  }

  logl <- getlogl(y = y, mu = mu)
  loglik <- sum(weights*logl)

  out <- list(coef = coef,
              mu = mu,
              df = df,
              logl = logl,
              loglik = loglik)
  out
}

#' Internal model function zero hazard + seq. logit
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## the constructor for a mixture between one zero.hazard and
## M-1 sequential logit models:
# MS18: funktioniert nur ohne Zensierung?!
zero.seqlogit.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "zero.hazard"
  for(m in 2:M){
    modellist[[m]] <- "seqlogit"
  }
  modellist
}

#################################################################################
#' Internal function for generalized linear model (glm) component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import stats
#'
# glm-version - zurzeit ohne Bestrafung für dispersionsparameter - da fix
glmcomp <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){

  dotlist <- list(...)
  family <- dotlist$family2
  if(is.na(family)){stop("family argument is missing")}

  y.names <- dotlist$y.names
  x.names <- dotlist$x.names[-1]

  if(ncol(x) == 1 & all(x == 1)){
    dat <- as.data.frame(cbind(y,x))
    dat[,2] <- as.factor(dat[,2]) # erste x-Spalte muss immer Zeit sein!!!
    colnames(dat) <- c(y.names,x.names)
    form <- as.formula(paste(paste(y.names),"~","0 +", paste(x.names, collapse= "+")))
  }else{
    dat <- as.data.frame(cbind(y,x[,-1]))
    dat[,2] <- as.factor(dat[,2]) # erste x-Spalte muss immer Zeit sein!!!
    colnames(dat) <- c(y.names,x.names)
    form <- as.formula(paste(paste(y.names),"~","-1 +", paste(x.names, collapse= "+"))) # ohne intercept -> 10 Zeit-Effekte; ansonsten immer ab zweiter Zeitstufe: intercept+Faktorwet
  }

  totalweights <- postweight * weights


  fit <- glm(form, weights = totalweights, offset = offset, model = F, family = family, data=dat)
  #fit <- glm(form, weights = totalweights, offset = offset, model = F, family = binomial(link = "cloglog"), data=dat)


  coef <- fit$coefficients
  mu <- fit$fitted.values
  df <- sum(!v.allequal(coef, 0)) # + 1 # (+1 for the dispersion!)


  # Likelihood
  getlogl <- function(y, mu){
    mu[which(mu <= 1e-8)] <- 1e-8
    mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
    #logl <-  rowSums(y * log(mu))
    logl <- dbinom(y, size=rep(1,nrow(y)), prob=mu, log = T)
    return(logl)
  }

  logl <- getlogl(y = y, mu = mu)
  loglik <- sum(weights*logl)

  out <- list(fit = fit,
              coef = coef,
              mu = mu,
              df = df,
              logl = logl,
              loglik = loglik)
  out
}

#' Internal model function for zero hazard + glm
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## a constructor function for glm mixed with one zero.hazard:
# wenig erprobt bzw. evtl. nicht korrekt?
zero.glm.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "zero.hazard"
  for(m in 2:M){
    modellist[[m]] <- "glmcomp"
  }
  modellist
}


#################################################################################
#' Internal function for Generalized additive models (gam) component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import mgcv
#' @import stats
#'
# mgcv: gam-treiber
gamcomp <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){

  dotlist <- list(...)
  family <- dotlist$family2
  if(is.na(family)){stop("family argument is missing")}

  y.names <- dotlist$y.names
  x.names <- dotlist$x.names[-1]

  if(ncol(x) == 1 & all(x == 1)){
    case2 <- F
    #form <- as.formula(y ~ 0 + x)
    dat <- as.data.frame(cbind(y,x))
    dat[,2] <- as.factor(dat[,2]) # erste x-Spalte muss immer Zeit sein!!!
    colnames(dat) <- c(y.names,x.names)
    form <- as.formula(paste(paste(y.names),"~","0 +", paste(x.names, collapse= "+")))
  }else{
    case2 <- T
    dat <- as.data.frame(cbind(y,x[,-1]))
    #dat[,2] <- as.factor(dat[,2]) # erste x-Spalte muss immer Zeit sein!!! -> hier zurzrit immer smooth
    colnames(dat) <- c(y.names,x.names)
    if (length(x.names)==1)
    {form <- as.formula(paste(paste(y.names),"~" ,paste(x.names[1])))} # Test ohne penalisierung
    #form <- as.formula(paste(paste(y.names),"~ s(",paste(x.names[1]),",bs=\"ps\",m=c(NA,10))"))} # m=3 oder m=c(3,3)
    else {
      form <- as.formula(paste(paste(y.names),"~  s(",paste(x.names[1]),") +", paste(x.names[-1], collapse= "+")))}
  }

  totalweights <- postweight * weights

  fit <- gam(form, data = dat, family = family, weights = totalweights, method = "REML")                                                          #### modifiziert!!

  # Berechnung echter Koeffizienten (nicht bezogen auf Intercept)
  if (case2 == T){
    coef <- numeric(length(fit$coefficients))
    coef[1] <- fit$coefficients[1]
    for (i in 2:length(fit$coefficients))
    {coef[i] <- fit$coefficients[1] + fit$coefficients[i]}
  }

  #coef <- fit$coefficients
  mu <- fit$fitted.values
  df <- attr(logLik(fit), "df")
  #y <- fit$y

  # Likelihood
  getlogl <- function(y, mu){
    mu[which(mu <= 1e-8)] <- 1e-8
    mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
    #logl <-  rowSums(y * log(mu))
    logl <- dbinom(y, size=rep(1,nrow(y)), prob=mu, log = T)
    return(logl)
  }

  logl <- getlogl(y = y, mu = mu)
  loglik <- sum(weights*logl)

  out <- list(fit = fit,
              coef = coef,
              mu = mu,
              df = df,
              logl = logl,
              loglik = loglik)
  out
}

#' Internal model function for zero hazard + gam
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## a constructor function for glm mixed with one zero.hazard:
zero.gam.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "zero.hazard"
  for(m in 2:M){
    modellist[[m]] <- "gamcomp"
  }
  modellist
}



#################################################################################
# modified survival
#################################################################################
#' Internal function for Generalized additive models (gam) in long format component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import mgcv
#' @import stats
#'
# mgcv: gam-treiber
gamcompsurv <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){

  #print("gamcomp")
  dotlist <- list(...)
  family <- dotlist$family2
  intercept.smooth <- dotlist$intercept.smooth
  if(is.null(intercept.smooth)){intercept.smooth <- F}
  if(is.na(family)){stop("family argument is missing")}
  sp <- dotlist$sp

  nobs <- nrow(y)## begin new stuff
  ti <- dotlist$ti
  if (is.null(ti))
  {ID <- rep(1:nobs, y)}
  else {ID <- rep(1:nobs, ti)} # ti: Anzahl Beobachtungen von Individium i (muss uebergeben werden); "y" stimmt nur, wenn keine links-zensierten daten

  postweight.long <- postweight[ID]
  weights.long <- weights[ID]

  if(!("y.long" %in% names(dotlist))){
    stop("An object named 'y.long' which contains the response info in long format must be supplied for driver function gamcompsurv!")
  }else{
    y.long <- dotlist$y.long
    if(is.vector(y.long)) y.long <- as.matrix(y.long)
  }

  if(nrow(y.long) != length(ID))
    stop("The length of the ID vector implied in the original observations ( 'y' ) does not match the length of the supplied response vector in long format ( 'y.long' )!")

  if(!("x.long" %in% names(dotlist))){
    stop("An object named 'x.long' which contains the covariate matrix in long format must be supplied for driver function gamcompsurv!")
  }else{
    x.long <- dotlist$x.long
  }
  ## end new stuff
  y.names <- dotlist$y.names
  #x.names <- dotlist$x.names[-1]
  x.names <- dotlist$x.names

  if(ncol(x.long) == 1 & all(x.long == 1)){
    case2 <- F
    #form <- as.formula(y ~ 0 + x)
    #dat <- as.data.frame(cbind(y,x))
    dat <- as.data.frame(cbind(y.long, x.long))   ## new
    dat[,2] <- as.factor(dat[,2]) # erste x-Spalte muss immer Zeit sein!!!
    colnames(dat) <- c(y.names,x.names)
    if(intercept.smooth==F){
    form <- as.formula(paste(paste(y.names),"~","-1 +", paste(x.names, collapse= "+")))
    dat[,2] <- as.ordered(dat[,2])
    }else{
    form <- as.formula(paste(paste(y.names),"~","0 +", paste(x.names, collapse= "+")))
    }
  }else{
    case2 <- T
    #dat <- as.data.frame(cbind(y,x[,-1]))
    #dat <- as.data.frame(cbind(y.long,x.long[,-1]))
    dat <- as.data.frame(cbind(y.long,x.long))  ## new
    if(intercept.smooth==F){dat[,2] <- as.ordered(dat[,2])}
    #dat[,2] <- as.factor(dat[,2]) # erste x-Spalte muss immer Zeit sein!!! -> hier zurzrit immer smooth
    # ziemlich wichtig, ob Faktor oder nicht!!!
    colnames(dat) <- c(y.names,x.names)
    #print(x.names)
    if (length(x.names)==1)
    {#form <- as.formula(paste(paste(y.names),"~" ,paste(x.names[1])))} # Test ohne penalisierung
    #form <- as.formula(paste(paste(y.names),"~ s(",paste(x.names[1]),",bs=\"re\")"))} # soviel Knoten wie Zeitpunkte
      if(intercept.smooth==F){
        form <- as.formula(paste(paste(y.names),"~ -1 +", paste(x.names[1])))
      }else{
    form <- as.formula(paste(paste(y.names),"~ s(",paste(x.names[1]),",bs=\"ps\",k=",paste(max(x.long[,1])),")"))} # soviel Knoten wie Zeitpunkte
    }#form <- as.formula(paste(paste(y.names),"~ s(",paste(x.names[1]),",bs=\"ps\")"))} # m=3 oder m=c(3,3)
    else {
      if(intercept.smooth==F){
        form <- as.formula(paste(paste(y.names),"~ -1 +", paste(x.names[1]), "+", paste(x.names[-1], collapse= "+")))
      }else{
      form <- as.formula(paste(paste(y.names),"~  s(",paste(x.names[1]),",bs=\"ps\",k=",paste(max(x.long[,1])),") +", paste(x.names[-1], collapse= "+")))}
    }
  }

  totalweights <- postweight.long * weights.long                                                             ## modified

  fit <- gam(form,sp=sp, data = dat, family = family, weights = totalweights, method = "REML") # sp                    ## modified

  coef <- fit$coefficients #-> nur richtig, wenn kein Intercept + 10 coefs/Zeitpunkte


  mu <- fit$fitted.values
  df <- attr(logLik(fit), "df")

  # Likelihood
  getlogl <- function(y.long, mu, ID){
    mu[which(mu <= 1e-8)] <- 1e-8
    mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
    logl.long <- dbinom(y.long, size=rep(1,nrow(y.long)), prob=mu, log = T)                                 ## modified
    logl <- sapply(split(logl.long, ID), sum)                                                               ## new
    return(logl)
  }

  logl <- getlogl(y.long = y.long, mu = mu, ID = ID)                                                        ## modified
  loglik <- sum(weights*logl)

  out <- list(fit = fit,
              coef = coef,
              mu = mu,
              df = df,
              logl = logl,
              loglik = loglik)
  out
}

#' Internal function for zero hazard with long format component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import stats
#'
zero.hazard.surv <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){                      ## new stuff
  # y=y_short, x=x_short  ?!
  dotlist <- list(...) # MS !!!
  #K <- ncol(y) ### y selbe struktur wie in "seqlogit"-treiberfunktion (glm anders!)

  nobs <- nrow(y)
  ti <- dotlist$ti
  if (is.null(ti))
  {ID <- rep(1:nobs, y)}
  else {ID <- rep(1:nobs, ti)}

  postweight.long <- postweight[ID]
  weights.long <- weights[ID]
  if(!("y.long" %in% names(dotlist))){
    stop("An object named 'y.long' which contains the response info in long format must be supplied for driver function gamcompsurv!")
  }else{
    y.long <- dotlist$y.long
    if(is.vector(y.long)) y.long <- as.matrix(y.long)
  }
  #print(nrow(y.long))
  #print(length(ID))
  if(nrow(y.long) != length(ID))
    stop("The length of the ID vector implied in the original observations ( 'y' ) does not match the length of the supplied response vector in long format ( 'y.long' )!")


  coef <- NULL
  #mu <- matrix(0, nrow = nobs, ncol = K)
  mu <- rep(0, nrow(y.long))

  df <- 0 # maybe 1?!


  # Likelihood
  getlogl <- function(y.long, mu, ID){
    mu[which(mu <= 1e-10)] <- 1e-10
    mu[which(mu >= 1 - 1e-10)] <- 1 - 1e-10
    logl.long <- dbinom(y.long, size=rep(1,nrow(y.long)), prob=mu, log = T)                                 ## modified
    logl <- sapply(split(logl.long, ID), sum)                                                               ## new
    return(logl)
  }
  #test
  #logl.long <- dbinom(y_long[1:11,], size=rep(1,11), prob=rep(0, 11), log = T)                                 ## modified
  #ti <- c(1,3,7)
  #ID <- rep(1:3, ti)

  logl <- getlogl(y.long = y.long, mu = mu, ID = ID)                                                        ## modified
  loglik <- sum(weights*logl)

  out <- list(coef = coef,
              mu = mu,
              df = df,
              logl = logl,
              loglik = loglik)
  out
}


#' Internal model function for zero hazard + gam (survival) in long format
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## a constructor function for glm mixed with one zero.hazard:                            ## begin new
zero.gamsurv.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "zero.hazard.surv"
  for(m in 2:M){
    modellist[[m]] <- "gamcompsurv"
  }
  modellist
}

###########################################################################################################################
#' Internal function for sequential logit (survival) component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import MRSP
#'
## a model driver function for sequential logit models:
seqlogitsurv <- function(y, x, M, coef = NULL, postweight, offset = NULL, weights, ...){
  # y ymat mit NAs?!, x_short
  #print("driver:seqlogitsurv")
  totalweights <- postweight * weights
  dotlist <- list(...)
  intercept.smooth <- dotlist$intercept.smooth
  intercept.lambda <- dotlist$intercept.lambda
  if(is.null(intercept.smooth)){intercept.smooth <- F}
  ti <- dotlist$ti
  V <- dotlist$xv #19
  hasV <- !is.null(V) #19
  if (is.null(ti)){
    ti <- apply(y,1,function(x){sum(!is.na(x))})
  }
  # it is important that the first column of x is the intercept column...
  if(!(all(abs(x[,1]) == 1))) stop("the first column of x must be an intercept column!")

  if("standardize" %in% names(dotlist)){
    standardize <- dotlist$standardize
  }else{
    if (dotlist$cublass==T){standardize <- F} #F
    else{standardize <- T} # T NEU wichtig, wenn genmix alleine aufgerufen wird; ansonsten auf F ?!
  }

  if("rel.tol" %in% names(dotlist)){
    rel.tol <- dotlist$rel.tol
  }else{
    rel.tol <- 1e-6  #get("rel.tol", envir = parent.frame())  # i.e. use same rel.tol as in genmix
  }

  if("maxiter2" %in% names(dotlist)){
    max.iter <- dotlist$maxiter2
  }else{
    max.iter <- 2000 #2000 MRSP-default; 30 vgam-default
  }


  if(!("lambda" %in% names(dotlist))){
    dotlist$lambda <- 123456789   # wp
    #dotlist$lambda <- 0           # ms Test -> schauen/checken
  }

  if(!("penindex" %in% names(dotlist))){
    if(dotlist$lambda != 123456789){ # dotlist$lambda != 0 # ich
      dotlist$penindex <- list(c(16, rep(4, ncol(x)-1)))   # pen # w: dotlist$penindex <- list(c(10, rep(4, ncol(x)-1))); ich: list(c(16, rep(4, ncol(x)-1)))                                              ### EDITME
        if(hasV){dotlist$penindex[[2]] <- rep(2, ncol(V[[1]]))} #19   # mit/ohne Intercept? mit/ohne list()
      }else{
      dotlist$penindex <- list(c(10, rep(40, ncol(x)-1)))   # nicht pen # ich: list(c(16, rep(40, ncol(x)-1))) ; w: list(c(10, rep(40, ncol(x)-1)))                                            ### EDITME
      #dotlist$penindex[[1]][7] <- 10 #nur spezielles Modell
        if(hasV){dotlist$penindex[[2]] <- rep(20, ncol(V[[1]]))} #19
      if(intercept.smooth==T){
        dotlist$penindex <- list(c(16, rep(40, ncol(x)-1)))
        dotlist$lambdaF <- intercept.lambda}
      }

  }
  if(!("control" %in% names(dotlist))){
    #dotlist$control <- MRSP.control(standardize=standardize, rel.tol=rel.tol,
    #                                doMLfit = F, computeDF = F, fisher=F, expandcall=F) # lasso?!
    dotlist$control <- MRSP.control(standardize=standardize, rel.tol=rel.tol, max.iter=max.iter,
                                    doMLfit = T, computeDF = T, fisher=F, expandcall=T) # genmix
    # Achtung doMLfit+compuetDF fuer penmix=F fuer genmix=T MS !!!!!!!!!!!
  }

  if(hasV){dat <- list(y=y, x=x, ytimes=ti, V=V)}else{ # 19
  dat <- list(y=y, x=x, ytimes=ti)} # ytimes unterschied zu seqlogit!
  #print("Start: Fit")

  #print(dotlist$penindex)
  if (dotlist$cublass==T){
    fit <- eval(as.call(c(as.symbol("MRSP.fit"), list(dat = substitute(dat),
                                                      coef.init = coef, weights = totalweights, constr = "none",                            # if you use a different model class, you maybe need a different constraint
                                                      offset = offset, model = sequentiallogitmodel), dotlist)))} # MRSP ### EDITME - if you want to write a new genmix driver based on MLSP, just copy # totalweigths
  else{
    fit <- eval(as.call(c(as.symbol("MRSP.fit"), list(dat = substitute(dat),
                                                      coef.init = coef, weights = totalweights, constr = "none",                            # if you use a different model class, you maybe need a different constraint
                                                      offset = offset, model = sequentiallogitmodel, fusion="adja"), dotlist)))} # MRSP ### EDITME - if you want to write a new genmix driver based on MLSP, just copy

  #adaptive=F, refit=F ?, fusion="adja" -> bei genmix-Aufruf direkt wichtig
  coef <- fit@coef
  #print(coef)
  mu <- fit@mu
  df <- fit@df # + (K-2) # K-2 ich -> fuer unterschiedliche Interceots?
  penalty <- fit@penalty

  #getlogl <- function(y, mu){
  #                     y <- cbind(y, 1 - rowSums(y))
  #                     mu <- cbind(mu, 1 - rowSums(mu))
  #                     mu[which(mu <= 1e-8)] <- 1e-8
  #                     mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
  #                     logl <-  rowSums(y * log(mu))
  #                     return(logl)
  #                    }

  #logl <- getlogl(y = y, mu = mu)
  logl <- fit@model@logl(y = y, mu = mu)
  loglik <- sum(weights*logl)

  out <- list(fit = fit,
              coef = coef,
              mu = mu,
              df = df,
              logl = logl,
              loglik = loglik,
              penalty = penalty)
  out
}

#' Internal function for long term survivors component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
zero.hazard.seq <- function(y, x, M, coef = NULL, postweight, offset, weights, ...){
  # y mit NAs?!
  K <- ncol(y) ### y selbe struktur wie in "seqlogit"-treiberfunktion (glm anders!)
  nobs <- nrow(y)

  coef <- NULL
  mu <- matrix(0, nrow = nobs, ncol = K)
  df <- 0 # maybe 1?!

  getlogl <- function(y, mu){
    #y <- cbind(y, 1 - rowSums(y))
    #mu <- cbind(mu, 1 - rowSums(mu))
    mu[which(mu <= 1e-10)] <- 1e-10
    mu[which(mu >= 1 - 1e-10)] <- 1 - 1e-10
    logl <-  rowSums(y * log(mu),T) #remove NAs!!!
    return(logl)
  }

  logl <- getlogl(y = y, mu = mu)
  loglik <- sum(weights*logl)

  out <- list(coef = coef,
              mu = mu,
              df = df,
              logl = logl,
              loglik = loglik)
  out
}

#' Internal model function for Cure model
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
zero.seqlogitsurv.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "zero.hazard.seq"
  for(m in 2:M){
    modellist[[m]] <- "seqlogitsurv"
  }
  modellist
}

###########################################################################################################################
#' Internal function for shifted binomial component
#' @author Wolfgang Pößnecker
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import MRSP
#'
#'
######       now the driver function for CubLasso        ##################################################################
###########################################################################################################################
cubbinomiallasso <- cmpfun(function(y, x, M, coef = NULL, postweight, offset, weights, ...){
 totalweights <- postweight * weights
dotlist <- list(...)
#if(!is.null(dotlist$u)) {
#  x <- dotlist$u
#  x.names <- dotlist$u.names}

if("standardize" %in% names(dotlist)){
  standardize <- dotlist$standardize
}else{
  standardize <- F
}

if("rel.tol" %in% names(dotlist)){
  rel.tol <- dotlist$rel.tol
}else{
  rel.tol <- 1e-6  #get("rel.tol", envir = parent.frame())  # i.e. use same rel.tol as in genmix
}

if("maxiter2" %in% names(dotlist)){
  max.iter <- dotlist$maxiter2
}else{
  max.iter <- 2000 #2000 MRSP-default; 30 vgam-default
}

if(!("lambda" %in% names(dotlist))){
  dotlist$lambda <- 123456789   # w
  #dotlist$lambda <- 0           # m
}

if(!("penindex" %in% names(dotlist))){
  if(dotlist$lambda != 123456789){ # dotlist$lambda != 0 # ich
    dotlist$penindex <- list(c(10, rep(12, ncol(x)-1))) # ???!!!! list(c(16, rep(4, ncol(x)-1)))                     ### EDITME
  }else{
    dotlist$penindex <- list(rep(10, ncol(x)))
  }
}

if(!("control" %in% names(dotlist))){
  dotlist$control <- MRSP.control(standardize=standardize, rel.tol=rel.tol, max.iter=max.iter,
                                  doMLfit = T, computeDF = T, fisher=F, expandcall=F)}
# Achtung doMLfit+compuetDF fuer penmix=F fuer genmix=T MS !!!!!!!!!!!

  if(!("grpindex" %in% names(dotlist))){
    dotlist$grpindex <- list(1:ncol(x))
  }

 if(!is.matrix(y)) y <- as.matrix(y)
 if(ncol(y) != 1) stop("y must be a one column matrix in driver cubbinomiallasso")

 dat <- list(y=y, x=x)
 # MRSP
 fit <- eval(as.call(c(as.symbol("MRSP.fit"), list(dat = substitute(dat),       ## NOTE the double list!! This is necessary for technical reasons.
                       coef.init = coef, weights = totalweights, constr = "none",
                       model = cubbinomialmodel), dotlist)))
if(class(fit)=="MRSP.list") {fit <- fit[[1]]}

coef <- fit@coef
 mu <- fit@mu
 df <- fit@df
 penalty <- fit@penalty

 getlogl <- function(y, mu){                                                    ## essentially, getlogl is always the same function as slot 'loglik' in the corresponding MLSP family.
                     k <- max(y)                                                ## the only difference is that getlogl does not use weights and does not sum up the individual
                     binomcoefs <- log(choose(k-1, y-1))                        ## loglikelihood contributions over observations.
                     mu[which(mu <= 1e-6)] <- 1e-8
                     mu[which(mu >= 1 - 1e-6)] <- 1 - 1e-8
                     logl <- (y-1)*log(1-mu) + (k-y)*log(mu) + binomcoefs
                     return(logl)
                    }

 logl <- getlogl(y = y, mu = mu)
 loglik <- sum(weights*logl)

 out <- list(fit = fit,
             coef = coef,
             mu = mu,
             df = df,
             logl = logl,
             loglik = loglik,
             penalty = penalty)
 out
})

#' Internal model function for disc. uniform + shifted binomial
#' @author Wolfgang Pößnecker
#' @param M number of mixture components
#' @export
## a constructor function
uniform.cubbinomial <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "discr.uniform"
  for(m in 2:M){
    modellist[[m]] <- "cubbinomiallasso"
  }
  modellist
}

#' Internal model function for beta binomial + shifted binomial
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## a constructor function
betabinom.cubbinomial <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "beta.binom"
  for(m in 2:M){
    modellist[[m]] <- "cubbinomiallasso"
  }
  modellist
}

#' Internal model function for disc. uniform + beta binomial
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
## a constructor function
uniform.betabinomial <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "discr.uniform"
  for(m in 2:M){
    modellist[[m]] <- "beta.binom"
  }
  modellist
}

##############################################################################################
#' Internal function for multinomial component
#' @author Micha Schneider
#' @param y response
#' @param x covariates for model component
#' @param M number of mixture components
#' @param coef coefficients for initialization
#' @param postweight postweight
#' @param offset offset (optional)
#' @param weights weights for each observation (optional)
#' @param ... further arguments
#' @import MRSP
#'
multinom <- function(y, x, M, coef = NULL, postweight, offset = NULL, weights, ...){
  totalweights <- postweight * weights
  dotlist <- list(...)
  # it is important that the first column of x is the intercept column...
  if(!all(x[,1] == 1)) stop("the first column of x must be an intercept column!")

  if("standardize" %in% names(dotlist)){
    standardize <- dotlist$standardize
  }else{
    standardize <- F
  }

  if("rel.tol" %in% names(dotlist)){
    rel.tol <- dotlist$rel.tol
  }else{
    rel.tol <- 1e-6  #get("rel.tol", envir = parent.frame())  # i.e. use same rel.tol as in genmix
  }

  if("maxiter2" %in% names(dotlist)){
    max.iter <- dotlist$maxiter2
  }else{
    max.iter <- 2000 #2000 MRSP-default; 30 vgam-default
  }

  if(!("lambda" %in% names(dotlist))){
    dotlist$lambda <- 123456789   # wolfgang
    #dotlist$lambda <- 0           # ich Test -> schauen/checken
  }
  #print("Model: lambda")
  #print(dotlist$lambda)

  # NEU
  if(!("constr" %in% names(dotlist))){
    dotlist$constr <- 1 # "symmetric"
  }

  if(!("penindex" %in% names(dotlist))){
    if(dotlist$lambda != 123456789){ # ich: dotlist$lambda != 0
      dotlist$penindex <- list(c(10, rep(12, ncol(x)-1))) # 12 normales Lasso
      standardize = F #MS besser aussenrum
    }else{
      dotlist$penindex <- list(rep(10, ncol(x))) # unpen, kat.spezifisch ?!
    }
  }

  if(!("grpindex" %in% names(dotlist))){
    dotlist$grpindex <- list(1:ncol(x))
  }

  if(!("control" %in% names(dotlist))){
    dotlist$control <- MRSP.control(standardize=standardize, rel.tol=rel.tol, max.iter=max.iter,
                                    doMLfit = F, computeDF = F, fisher=F, expandcall=F)

    ### EDITME - if you write a genmix driver based on MLSP, you might want to change some of these...
    #print(dotlist$control)
  }

  dat <- list(y=y, x=x)

  fit <- eval(as.call(c(as.symbol("MRSP.fit"), list(dat = substitute(dat),
                                                    coef.init = coef, weights = totalweights,                           # if you use a different model class, you maybe need a different constraint
                                                    offset = offset, model = multinomlogitmodel), dotlist))) # MRSP               ### EDITME - if you want to write a new genmix driver based on MLSP, just copy
  ### the code of this function ("seqlogit") and change the model-entry in the line above.
  ### you might have to initialize the MLSP.model at the top of this file if you want to
  ### use one that isnt already included (see top of this file...)

  coef <- fit@coef
  mu <- fit@mu
  df <- fit@df # + (K-2) # K-2 ich -> fuer unterschiedliche Interceots?
  #print(df)
  penalty <- fit@penalty

  #getlogl <- function(y, mu){
  #                     y <- cbind(y, 1 - rowSums(y))
  #                     mu <- cbind(mu, 1 - rowSums(mu))
  #                     mu[which(mu <= 1e-8)] <- 1e-8
  #                     mu[which(mu >= 1 - 1e-8)] <- 1 - 1e-8
  #                     logl <-  rowSums(y * log(mu))
  #                     return(logl)
  #                    }

  #logl <- getlogl(y = y, mu = mu)
  logl <- fit@model@logl(y = y, mu = mu)
  loglik <- sum(weights*logl)

  out <- list(fit = fit,
              coef = coef,
              mu = mu,
              df = df,
              logl = logl,
              loglik = loglik,
              penalty = penalty)
  out
}

#' Internal model function for disc. uniform + multinomial
#' @author Micha Schneider
#' @param M number of mixture components
#' @export
uniform.multinom.mix <- function(M){
  modellist <- list(); length(modellist) <- M
  modellist[[1]] <- "discr.uniform"
  for(m in 2:M){
    modellist[[m]] <- "multinom"
  }
  modellist
}





