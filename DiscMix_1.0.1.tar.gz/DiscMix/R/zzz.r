DiscMixwelcomemessage <- function(){
  cat("-----------------------------",
      "This is DiscMix version 1.0.1",
      #"-----------------------------",
      "Authors: Micha Schneider \n Wolfgang Poessnecker",
      "-----------------------------",
      sep = "\n")   }

.onAttach <- function(libname, pkgname){
  packageStartupMessage(DiscMixwelcomemessage())
  #install_github("WolfgangPoessnecker/MRSP")
  #https://github.com/WolfgangPoessnecker/MRSP/blob/master/MRSP_0.6.11.tar.gz
  #if(!("MRSP" %in% loadedNamespaces())){ library(MRSP) }
  #%multinomlogitmodel <- multinomlogit()
  #%sequentiallogitmodel <- sequentiallogit()
  #%cumulativelogitmodel <- cumulativelogit()
  #%cubbinomialmodel <- CUBbinomiallogit()
}
