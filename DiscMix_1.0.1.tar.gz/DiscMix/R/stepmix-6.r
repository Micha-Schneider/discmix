# Function for stepwise (forward) selection of mixture models, part of DiscMix
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker

#' Function for stepwise (forward) selection of mixture models
#'
#' @param y response as character string
#' @param data data set
#' @param x.min if used it is possible to specify pre selected variables in the x component (same form as in \code{x.max})
#' @param x.max character string ("~ VariableName1 + VariableName2 + ...") of maximal possible variables in the x component
#' @param z.min if used it is possible to specify pre selected variables in the z component (same form as in \code{z.max})
#' @param z.max character string ("~ VariableName1 + VariableName2 + ...") of maximal possible variables in the z component
#' @param u.min if used it is possible to specify pre selected variables in the u component (same form as in \code{u.max})
#' @param u.max character string ("~ VariableName1 + VariableName2 + ...") of maximal possible variables in the u component
#' @param x.long design matrix for specific survival models (usually not in use)
#' @param y.long response matrix for specific survival models (usually not in use)
#' @param M number of mixture components (usually 2)
#' @param model Choose the kind of Mixture Model to be fitted. For an overview see discmix
#' @param model.args additional model arguments
#' @param GEM Type of EM-algorithm: \code{GEM=T} Generalized EM-algorithm is used (fewer iterations in one em-step)
#' @param criteria criteria for stepwise selection: \code{"BIC"}, \code{"AIC"} or \code{"Deviance"} (-> Likelihood-Ratio test (LR-test))
#' @param criteria.threshold Deviance criterion: Specify alpha value of LR test (default 0.05); AIC/BIC: minimum improvement which need to be reached (default 0)
#' @param concomitant type of concomitant (do not change)
#' @param concomitant.args additional concomitant arguments
#' @param model.coef.init specific model coefficient initialization
#' @param concomitant.coef.init specific concomitant coefficient initialization
#' @param postweight.init specific postweight initialization
#' @param pi.init specific pi initialization
#' @param offset offset
#' @param weights vector of individual weights different from one (ussually not in use)
#' @param control control informations, i.e. \code{rel.tol} for relative tolerance or \code{max.iter} for maximum number of em iterations
#' @param control.init control information for initialization
#' @param checks internal checks
#' @param initialseed initial seed
#' @param model.initialseed model initial seed
#' @param cublass internal parameter
#' @param cub internal parameter
#' @param survival internal parameter
#' @param alpha alpha value to specify specific beta-binomial distributions
#' @param family2 family argument for specific model components
#' @param sp smoothing for specific model components (in combination with family2)
#' @param ti cure model only: vector with length of number of observations with the entries ti indicating the time an observation has been observed
#' @param event cure mode only: vector with length of number of observations with the entries zero or one indicating if an event has taken place
#' @param ishape1 value to specify specific beta-binomial distributions
#' @param ishape2 value to specify specific beta-binomial distributions
#' @param c.maxiter maximum number of iterations in the z/concomitant component
#' @param maxiter1  maximum number of iterations in the first model component
#' @param maxiter2  maximum number of iterations in the second model component
#' @param BS.seed Bootstrap seed
#' @param BS.seedindex vector of Bootstrap seeds
#' @param method internal method
#' @param pwi Weight initialization: weight value
#' @param nr.seeds Weight initialization: Number of draws for each pwi
#' @param pwi.method Weight initialization: "both": constant weights and sample; "fix": only constant weights; "sample": only sample
#' @param seed.init initial seed
#' @param parallel parallilzed stepwise procedure (strongly recommended)
#' @param cores number of cores
#' @param small.output Reduction of size of the output object
#' @param dat data for specific models
#' @param help Stabilization of estimation process by preventing weights to be too close to zero or one
#' @param trace additional fitting information
#' @param fn.val.option change which likelihood should be used to be optimized (usually do not change)
#' @param max.reach maximum number of selection steps
#' @param ... further arguments
#'
#' @return Result of stepwise selection; Note that at each step one element is added to BIC,AIC,loglik etc.. Thus if the process runs until the end, the last element of AIC,BIC, loglik, etc. is the first one which is NOT selected.
#' \item{fit}{discmic fit of the selected model}
#' \item{df}{development of degrees of freedoms}
#' \item{loglik}{development of loglikelihoods}
#' \item{AIC}{development of AICs}
#' \item{BIC}{development of BICs}
#' \item{vars.global}{seected variables}
#'
#'
#' @references{
#' Schneider, Micha, Pößnecker, Wolfgang and Gerhard Tutz (2019): Variable Selection in Mixture Models with an Uncertainty Component. Technical Report 225, Department of Statistics, Ludwig-Maximilians-Universität München.
#'
#' Schneider, Micha (2019): Dealing with Heterogeneity in Discrete Survival Analysis using the Cure Model. Technical Report 224, Department of Statistics, Ludwig-Maximilians-Universität München.
#' }
#'
#' @author Micha Schneider
#'
#' @examples
#' ## Example forward selection discrete Cure Model (~ 7.5 min using 6 cores)
#' # Data
#' library(RcmdrPlugin.survival)
#' data(Rossi)
#'
#' # Data Structure
#' ymat <- matrix(NA, nrow=nrow(Rossi), ncol=52)
#' for(i in seq(nrow(ymat))){
#' yi <- Rossi$week[i]
#' ymat[i, 1:(yi-1)] <- 0
#' ymat[i, yi] <- Rossi$arrest[i]*1
#' }
#' head(ymat)
#'
#' # Model (max.reach=1, max.iter=20 not recommended)
#' forw <- stepmix(y=ymat, x.max= "~ age + wexp", z.max="~ age + wexp", data=Rossi, ti=Rossi$week,
#'         event=Rossi$arrest, max.reach=1, control=genmix.control(max.iter=20),
#'         model = zero.seqlogitsurv.mix, criteria="BIC", cores=2)
#'
#' # Output
#' forw$fit$model.coef[[2]][[1]][1,2,drop=FALSE]
#' forw$fit$concomitant.coef[[1]][2,]
#' forw$vars.global
#' forw$BIC
#'
#' @import parallel
#' @import stats
#' @export
#'
stepmix <- function(y=NULL, data=NULL, x.min=NULL, x.max=NULL, z.min=NULL, z.max=NULL, u.min=NULL, u.max=NULL,
                           x.long=NULL,y.long=NULL,M = 2, model, model.args = NULL,GEM=F, criteria="BIC", criteria.threshold=NULL,
                           concomitant = "concomitant.default", concomitant.args = NULL,
                           model.coef.init = NULL, concomitant.coef.init = NULL,
                           postweight.init = NULL, pi.init = NULL, offset = NULL,
                           weights = NULL, control = genmix.control(), control.init=genmix.control(),
                           checks = checks.default, initialseed = sample(1000, size=1),model.initialseed=NULL,
                           cublass=F,cub=F,survival=F,alpha=NULL,family2=NA,sp=NULL,ti=NULL,event=NULL,
                           #c.lambda=NULL, penindex=NULL, grpindex=NULL, lambda=123456789, lambdaF=123456789,
                           ishape1=1, ishape2=NULL, c.maxiter=NULL,
                           maxiter1=NULL,maxiter2=NULL, BS.seed=NULL,BS.seedindex=NULL,
                           method=1,pwi=c(0.7,0.8,0.9),nr.seeds=2,pwi.method="both", seed.init=1000, parallel=T, cores=detectCores()-1,small.output=T,dat=NULL,help=F,trace=F,
                           fn.val.option="NA", max.reach=ncol(data)+1,...){

  if(is.null(y)|is.null(data)){stop("y and/or data is missing.")}
  hasx <- !is.null(x.min)|!is.null(x.max)
  hasz <- !is.null(z.min)|!is.null(z.max)
  hasu <- !is.null(u.min)|!is.null(u.max)


  if(!is.list(model)) model.test <- evalh(model)

  # test auf cure
  if(model.test[[1]]=="zero.hazard.seq" & model.test[[2]]=="seqlogitsurv"){
    cure <- T
  }else{cure <- F}

  # models
  if(hasx){
    if(is.null(x.min)) {x.min <- "~ 1"}
    if(is.null(x.max)) {x.max <- "~ ."}
    #x.min <- as.formula(x.min)
    #x.max <- as.formula(x.max)
    #x.form <- as.formula(" ~ 1") # <- x[,1]
    x.vars  <- all.vars(as.formula(x.max)) # colnames(x)
    if(length(x.vars)>0){if(x.max=="."){x.vars <- colnames(data)[colnames(data)!=y]}}
    x.min.vars <- all.vars(as.formula(x.min))
    if(length(x.min.vars)>0){if(x.min=="."){x.min.vars <- colnames(data)[colnames(data)!=y]}}
    x.vars <- x.vars[!(x.vars %in% x.min.vars)] # delete vars which are in x.min
    x.n <- length(x.vars) # ncol(x)
    x.global <- paste("x",x.vars, sep =":")
    }
  else {#x.form <- NULL
        x.vars <- NULL
        x.n <- 0
        x.global <- NULL}

  if(hasz){
    if(is.null(z.min)) {z.min <- "~ 1"}
    if(is.null(z.max)) {z.max <- "~ ."}
    #x.min <- as.formula(x.min)
    #x.max <- as.formula(x.max)
    #x.form <- as.formula(" ~ 1") # <- x[,1]
    z.vars  <- all.vars(as.formula(z.max)) # colnames(x)
    if(length(z.vars)>0){if(z.max=="."){z.vars <- colnames(data)[colnames(data)!=y]}}
    z.min.vars <- all.vars(as.formula(z.min))
    if(length(z.min.vars)>0){if(z.min=="."){z.min.vars <- colnames(data)[colnames(data)!=y]}}
    z.vars <- z.vars[!(z.vars %in% z.min.vars)] # # delete vars which are in z.min
    z.n <- length(z.vars) # ncol(x)
    z.global <- paste("z",z.vars, sep =":")
  }
  else {
    z.vars <- NULL
    z.n <- 0
    z.global <- NULL}

  if(hasu){
    if(is.null(u.min)) {u.min <- "~ 1"}
    if(is.null(u.max)) {u.max <- "~ ."}
    #x.min <- as.formula(x.min)
    #x.max <- as.formula(x.max)
    #x.form <- as.formula(" ~ 1") # <- x[,1]
    u.vars  <- all.vars(as.formula(u.max)) # colnames(x)
    if(length(u.vars)>0){if(u.max=="."){u.vars <- colnames(data)[colnames(data)!=y]}}
    u.min.vars <- all.vars(as.formula(u.min))
    if(length(u.min.vars)>0){if(u.min=="."){u.min.vars <- colnames(data)[colnames(data)!=y]}}
    u.vars <- u.vars[!(u.vars %in% u.min.vars)] # delete vars which are in u.min
    u.n <- length(u.vars) # ncol(x)
    u.global <- paste("u",u.vars, sep =":")
  }
  else {
    u.vars <- NULL
    u.n <- 0
    u.global <- NULL}

  # mit s globale ergebnisse; ohne s innerhalb parallel
  pos.vars <- c("x"=x.vars,"z"=z.vars,"u"=u.vars)
  nmax <- x.n + z.n + u.n +1
  if(sum(length(x.global),length(z.global),length(u.global))!=nmax-1){stop("internal error: .global doesn't match")}
  vars.global <- rep(0,nmax-1)
  names(vars.global) <- names(pos.vars)
  #print(vars.global)
  logliks <- rep(NA,nmax)
  Devs <- rep(NA,nmax)
  aics <- rep(NA,nmax)
  bics <- rep(NA,nmax)
  dfs <- rep(NA,nmax)
  selected <- c(rep(NA,nmax)) # c("Intercept",rep(NA,nmax-1))
  selected.names <- c(rep(NA,nmax))
  #names(selected) <- 1:nmax
  tests <- c(0,rep(NA,nmax-1)) # LQ-Test-Ergebnis
  x.fitcalls <- vector("list", nmax)
  z.fitcalls <- vector("list", nmax)
  u.fitcalls <- vector("list", nmax)

  #MS Init
  x.min.res <- x.min
  z.min.res <- z.min
  u.min.res <- u.min

  # Start-Modell
  start <- discmix(y=y, data=data, x=x.min, z=z.min, u=u.min, x.long=x.long, y.long=y.long,
                       M=M, model=model, model.args=model.args, GEM=GEM,
                       concomitant=concomitant, concomitant.args=concomitant.args,
                       model.coef.init=model.coef.init, concomitant.coef.init=concomitant.coef.init,
                       postweight.init=postweight.init, pi.init=pi.init, offset=offset,
                       weights=weights, control=control,control.init=genmix.control(), checks=checks,
                       initialseed=initialseed, #model.initialseed = model.initialseed,
                       cublass=cublass, cub=cub,cure=cure, alpha=alpha, family2=family2,sp=sp, ti=ti, event=event,
                       #c.lambda=c.lambda, penindex=penindex, grpindex=grpindex, lambda=lambda,
                       maxiter1=maxiter1, maxiter2=maxiter2, BS.seed=BS.seed,BS.seedindex=BS.seedindex,
                       method=method, pwi=pwi, nr.seeds=nr.seeds, pwi.method="fix", seed.init=seed.init,
                       parallel=parallel, cores=cores, small.output=small.output, dat=dat,
                       help=help, trace=trace, fn.val.option=fn.val.option)
  #print("start okay")
  #print(date())
  #print(x.min)
  #print(z.min)

  # Devianz-Kriterium
  i <- 1
  selected[i] <- "start" # c("Intercept",rep(NA,nmax-1))
  selected.names[i] <- "start"
  logliks[i] <- start$loglik
  Devs[i] <- -2*logliks[i]
  dfs[i] <- start$df
  aics[i] <- start$AIC
  bics[i] <- start$BIC
  x.fitcalls[[i]] <- as.character(x.min)
  z.fitcalls[[i]] <- as.character(z.min)
  u.fitcalls[[i]] <- as.character(u.min)
  # HIER update von vars oder ganz oben (weil wenn min und max selbe variable beinhaltet...)
  vars <- pos.vars
  print("possible Variables:")
  print(vars)

  # tmp
  step.results <- vector("list", length(vars))
  step.results[[1]] <- "start"
  #tmp vars <- vars[-2]

    bootcorepar <- function(i){
    bootcore(i = i)
  }

  # bootcore
  bootcore <- function(i){
    #require("MRSP")
    #require("VGAM")
    #require("formula.tools")
    #source("genmix-gesamt-3.r")
    #ind <- vars[i]
    #print("used variable")
    #print(vars[i])

    if ("x" %in% unlist(strsplit(names(vars[i]),"")))
    {x.min <- as.character(update(as.formula(x.min), as.formula(paste("~ . +", vars[i]))))
     fitcall$x <- quote(x.min)
    }        # nur abdaten was sich ändert, rest sollte im call stehen
    if ("z" %in% unlist(strsplit(names(vars[i]),"")))
    {z.min <- as.character(update(as.formula(z.min), as.formula(paste("~ . +", vars[i]))))
    fitcall$z <- quote(z.min)
    }
    if ("u" %in% unlist(strsplit(names(vars[i]),"")))
    {u.min <- as.character(update(as.formula(u.min), as.formula(paste("~ . +", vars[i]))))
    fitcall$u <- quote(u.min)
    }

    fit <- try(eval(fitcall),TRUE)
    if (!inherits(fit, 'try-error')){#{print(fit); fit <- NULL}
      if(small.output==T){
        fit$model[[1]]$fit <- NULL
        fit$model[[1]]$mu <- NULL
        fit$model[[1]]$logl <- NULL
        fit$model[[2]]$fit <- NULL
        fit$model[[2]]$mu <- NULL
        fit$model[[2]]$logl <- NULL
        fit$postweight <- NULL}
    }
    fit$vars <- vars[i] # geht das so?! #
    fit$x.fitcall <- as.character(x.min)
    fit$z.fitcall <- as.character(z.min)
    fit$u.fitcall <- as.character(u.min)
    #fit$x.min <- x.min
    #fit$z.min <- z.min
    #fit$u.min <- u.min

    fit
  }

  # Abbruch-Entscheidung vorbereiten
  test.while <- T
  if(!is.null(criteria.threshold)){
    if(criteria=="Deviance" & criteria.threshold > 0.25){ # falls AIC/BIC threshold fuer Deviance Kriterium eingestellt wurde
      warning("alpha-level of LQ-Test was set to larger than 0.25 by criteria.threshold")}
    if(criteria=="Deviance" & criteria.threshold <= 0){
      stop("alpha-level of LQ-Test was set to zero (or smaler) by criteria.threshold. Only values larger than zero are possible.")}
  }
  else{
  if(criteria=="Deviance"){criteria.threshold <- 0.05}
  if(criteria=="AIC"){criteria.threshold <- 0}
  if(criteria=="BIC"){criteria.threshold <- 0}
  }
  #if(criteria=="AIC" | criteria=="BIC" & criteria.threshold < 0)
  #  stop("Difference of AIC/BIC was set to a negative value by criteria.threshold. Only values equal or larger than zero are possible.")

  # Schleife
  #print("tmp")
  #print(test.while)
  #print(max.reach)
  #print(nmax)
  while( test.while==T & i<=max.reach & i<=nmax) # Abbruch der Forward-Selektion
  {
    # hier bezogen auf while Schleife !
    i <- i+1 # !!! (hier hochzählen, sonst i anpassen !!!!; i=1 Start/Intercept-Modell)

    # 1 while-Durchlauf bedeutet eine var dazu -> einer der x.min/z.min/u.min ändert sich jeden while durchlauf
    # für schleife genmix2 kann jetzt auch formula/characters
    fitcall <- call("discmix", y=y, data=data, x=substitute(x.min), z=substitute(z.min), u=substitute(u.min),
                    weights=weights,ti=ti, event=event, cure=cure,
                    model=model, M=M, initialseed=model.initialseed, control=control,
                    #BS.seed=BS.seed, BS.seedindex=substitute(BS.seedindex),
                    c.maxiter=c.maxiter, maxiter1=maxiter1,maxiter2=maxiter2,pwi=pwi,
                    nr.seeds=nr.seeds,pwi.method=pwi.method,seed.init=seed.init,GEM=GEM,parallel=F, help=help)

    B <- length(vars) # j läuft über BS; #i pro selected variable

  # max soviele cores verwenden wie B
  if(B<cores){cores <- B}

  if(parallel){
    cl <- makeCluster(cores)
    clusterEvalQ(cl, {
      library(DiscMix)
    })#V2 #V3
    #plan(multisession, gc = TRUE) # ?!
    clusterExport(cl, c("fitcall","vars","x.min","z.min","u.min","small.output"), envir = environment())
    #clusterExport(cl, ls(envir = sys.frame(sys.nframe())), envir = sys.frame(sys.nframe()))
    bootlist <- parLapply(cl, seq(B), bootcorepar)
    stopCluster(cl)
  }else{
    get(ls(envir = parent.frame()), envir = parent.frame())
    bootlist <- lapply(seq(B), bootcore)
  }

  # Test/abfedern, wenn was nicht geklappt hat?!
  boot_errors <- which(lapply(bootlist,function(x) is.character(x))==TRUE)
  #boot_errors
  if(!length(boot_errors)==0){
    vars_errors <- vars[boot_errors]
    error_messages <- bootlist[c(boot_errors)]
    bootlist[boot_errors] <- bootlist[-c(boot_errors)]
  }
  #unique(error_messages)

  df <- c()
  loglik <- c()
  Dev <- c()
  aic <- c()
  bic <- c()
  test <- c()
  BS.vars <- c()

  BS <- length(bootlist)
  BS.x.fitcall <- vector("list", BS)
  BS.z.fitcall <- vector("list", BS)
  BS.u.fitcall <- vector("list", BS)
  BS.model.coef <- vector("list", BS)
  BS.concomitant.coef <- vector("list", BS)
  print("###########################################")
  cat(paste("step:",i,"\n"))
  #print("BS worked")
  #print(BS)
  #j <- 1
  #print(Devs[i-1])
  #print(dfs[i-1])
  for(j in 1:BS)
  {
    df[j] <- bootlist[[j]]$df
    loglik[j] <- bootlist[[j]]$loglik
    Dev[j] <- -2*loglik[j]
    aic[j] <- bootlist[[j]]$AIC
    bic[j] <- bootlist[[j]]$BIC
    BS.vars[j] <- bootlist[[j]]$vars
    BS.x.fitcall[[j]] <- as.character(bootlist[[j]]$x.fitcall)
    BS.z.fitcall[[j]] <- as.character(bootlist[[j]]$z.fitcall)
    BS.u.fitcall[[j]] <- as.character(bootlist[[j]]$u.fitcall)
    BS.model.coef[[j]] <- bootlist[[j]]$model.coef
    BS.concomitant.coef[[j]] <- bootlist[[j]]$concomitant.coef
    names(BS.vars)[j] <- names(bootlist[[j]]$vars)
    test[j] <- 1 - pchisq(Devs[i-1]-Dev[j], df=df[j]-dfs[i-1]) # checken (Richtung und i+j)
  }
  # temp
  rm(cl) #save memory
  rm(bootlist) #save memory
  #print("results")
  #print(i)
  print("Criterion for all fitted models:")
  if(criteria=="BIC")
  {print(bic)}
  if(criteria=="AIC")
  {print(aic)}
  if(criteria=="Deviance")
  {print(test)}
  #print(bic)
  #print(loglik)
  #print(df)
  #print(test)
  #print(criteria.threshold)
  #print(nmax)
  #print(max.reach)
  #print(BS.vars)
  # sapply(bootlist, function(x){x$loglik}) # ? -> alle LogLik/Deviancen

  step.results[[i]]$df <- df
  step.results[[i]]$loglik <- loglik
  step.results[[i]]$Dev <- Dev
  step.results[[i]]$aic <- aic
  step.results[[i]]$bic <- bic
  step.results[[i]]$test <- test
  step.results[[i]]$vars <- BS.vars
  step.results[[i]]$x.fitcall <- BS.x.fitcall
  step.results[[i]]$z.fitcall <- BS.z.fitcall
  step.results[[i]]$u.fitcall <- BS.u.fitcall
  step.results[[i]]$model.coef <- BS.model.coef
  step.results[[i]]$concomitant.coef <- BS.concomitant.coef

  # beste verbesserung
  if(criteria=="Deviance"){
    best.pos <- which.min(test)
    test.tmp <- round(test,14)
    #print("Deviance_local:")
    #print(best.pos)
    #print(test.tmp)
    #print(sum(test.tmp==0)>1)
    if(sum(test.tmp==0)>1){
    test.nearly.zero <- which(test.tmp==0)
    test.nearly.zero.min <- min(Dev[test.nearly.zero])
    best.pos <- which(Dev==test.nearly.zero.min)
    #print("best.pos nach LQ:")
    #print(best.pos)
    }
  }
  if(criteria=="AIC"){best.pos <- which.min(aic)}
  if(criteria=="BIC"){best.pos <- which.min(bic)}
  #print(best.pos)

  step.results[[i]]$best.pos <- best.pos

  best.var <- BS.vars[best.pos]
  dfs[i] <- df[best.pos]
  logliks[i] <- loglik[best.pos]
  Devs[i] <- Dev[best.pos]
  aics[i] <- aic[best.pos]
  bics[i] <- bic[best.pos]
  tests[i] <- test[best.pos]
  #print(test[best.pos])

  # werte abspeichern (auch letztes nicht-selectierte Var!!!)
  #selected[i] <- index[(best==names(vars))] # selected var. auswählen
  selected[i] <- best.var
  selected.names[i] <- names(best.var)
  #names(selected[i]) <- names(best.var) ?????

  # übrige vars
  # vars <- vars[-which(best==names(vars))]
  # vars <- vars[-best.pos]
  vars <- vars[-which(names(best.var)==names(vars))]

  # Basic-formula # checken mit best -> NAME(x1, etc) nicht variable "marital"! (best statt "names(selected[i])")
  if ("x" %in% unlist(strsplit(names(best.var),"")))
  {x.min <- as.character(update(as.formula(x.min), as.formula(paste("~ . +", selected[i]))))}
  if ("z" %in% unlist(strsplit(names(best.var),"")))
  {z.min <- as.character(update(as.formula(z.min), as.formula(paste("~ . +", selected[i]))))}
  if ("u" %in% unlist(strsplit(names(best.var),"")))
  {u.min <- as.character(update(as.formula(u.min), as.formula(paste("~ . +", selected[i]))))}

  x.fitcalls[[i]] <- as.character(x.min)
  z.fitcalls[[i]] <- as.character(z.min)
  u.fitcalls[[i]] <- as.character(u.min)

  #Abbruch-Entscheidung # idR: test: 0.05, aic/bic=0/1/2
  if(criteria=="Deviance"){if(tests[i] > criteria.threshold) {test.while <- F}}
  if(criteria=="AIC"){if((aics[i-1]-aics[i]) <= abs(criteria.threshold)) {test.while <- F}}
  if(criteria=="BIC"){if((bics[i-1]-bics[i]) <= abs(criteria.threshold)) {test.while <- F}}

  #print("test while")
  #print(test.while)
  #print(bics[i-1]-bics[i])
  if(test.while==T) {
    x.min.res <- x.min
    z.min.res <- z.min
    u.min.res <- u.min
    vars.global[names(vars.global)==names(best.var)] <- 1
  }

  #print(test.while==T)
  #print(i<=max.reach)
  #print(i<=nmax)
  # else x.min.res = x.min.old
  # evtl. noch ausgabe mit cat etc.#
  if(test.while==T){
  print("selected variable:")
  print(best.var)
  print(vars.global)
  }
  #print("iteration finished")
  #print(date())
  gc() # empty memory ?!
  }# while Ende

  names(vars.global) <- c(x.global, z.global, u.global)
  # Reduce output#
  step.results <- Filter(Negate(is.null), step.results)
  selected <- Filter(Negate(is.na), selected)
  selected.names <- Filter(Negate(is.na), selected.names)
  dfs <- Filter(Negate(is.na), dfs)
  logliks <- Filter(Negate(is.na), logliks)
  Devs <- Filter(Negate(is.na), Devs)
  aics <- Filter(Negate(is.na), aics)
  bics <- Filter(Negate(is.na), bics)
  tests <- Filter(Negate(is.na), tests)
  x.fitcalls <- Filter(Negate(is.null), x.fitcalls)
  z.fitcalls <- Filter(Negate(is.null), z.fitcalls)
  u.fitcalls <- Filter(Negate(is.null), u.fitcalls)
  tests[1] <- NA # LQ-Test fängt im Moment 2 Pos an

  # End-Modell fitten (evtl. wieder länger als davor?!) bzw. init rettbar?
  print("Start final fit")
  #print(date())
  #print(y)
  cat("x.formula:",x.min.res,"\n")
  cat("z.formula:",z.min.res,"\n")
  #print(z.min)
  Ende <- discmix(y=y, data=data, x=x.min.res, z=z.min.res, u=u.min.res,
                  weights=weights, ti=ti, event=event, cure=cure,
                  model=model, M=M, initialseed=model.initialseed, control=control,
                  #BS.seed=BS.seed, BS.seedindex=substitute(BS.seedindex),
                  c.maxiter=c.maxiter, maxiter1=maxiter1,maxiter2=maxiter2,pwi=pwi,
                  nr.seeds=nr.seeds,pwi.method=pwi.method,seed.init=seed.init,GEM=GEM,parallel=T,cores=cores, help=help)


  # output: bestes Modell + evaluation, aber nicht alle Modelloutputs!!!
  # vars_errors speichern?!
  #list(fit=Ende, selected=selected, selected.names=selected.names, df=dfs, loglik=logliks, Dev=Devs, AIC=aics, BIC=bics, test=tests, step.results=step.results)

  list(fit=Ende, selected=selected, selected.names=selected.names, vars.global=vars.global, df=dfs, loglik=logliks, Dev=Devs, AIC=aics, BIC=bics, test=tests, step.results=step.results, x.fitcall=x.fitcalls, z.fitcall=z.fitcalls, u.fitcall=u.fitcalls)
}
