# Function of DiscMix to find the optimal tuning-parameter combination
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker

#' Fitting Penalized Discrete Mixtures
#'
#' Function to fit several times penalized discrete finite mixture models and find the best tuning parameter combination according to the selection criterion BIC
#'
#' @param y response
#' @param x formula for the model/preference component
#' @param z formula for the weights
#' @param model choose the kind of Mixture Model to be fitted:
#' \itemize{
#'   \item CUP(c) Model: \code{uniform.cumlogit.mix}
#'   \item CUB Model: \code{uniform.cubbinomial}
#'   \item Cure Model: \code{zero.seqlogitsurv.mix}
#' }
#' @param data data.frame with correct specified covariates (i.e. categorical covariates need to be specified as factors!)
#' @param seeds Seeds
#' @param nrlambda number of tuning parameters (lambda)
#' @param lambdamax largest lambda value
#' @param lambdamin smallest lambda value
#' @param c.nrlambda number of tuning parameters for concomitant/weights
#' @param c.lambdamax largest lambda value for concomitant
#' @param c.lambdamin smallest lambda value for concomitant
#' @param max.iter maximum number of em iterations
#' @param threshold threshold
#' @param rel.tol relative difference in likelihood for convergence
#' @param postweight.init specific postweight initialization
#' @param penalty penalization (usually TRUE)
#' @param penindex vector with numbers specifying for each column of x the corresponding penalty according to MRSP (see ?MRSP.fit); so far need to be specified in advance!
#' \itemize{
#'   \item \code{10}: unpenalized intercepts
#'   \item \code{12}: group lasso for (global) predictors
#'   \item \code{40}: ordinal only: unpenalized intercepts
#'   \item \code{4}:  ordinal only: group lasso for (global) effects (not categorical specific)
#'   \item \code{16}: ride penalty of intercept differences used in the cure model
#' }
#' @param c.penindex vector with numbers specifying for each column of z the corresponding penalty according to MRSP; so far need to be specified in advance; usually:
#' #' \itemize{
#'   \item \code{10}: unpenalized intercepts
#'   \item \code{12}: group lasso for (global) predictors
#' }
#' @param grid pre-specified grid of lambda values
#' @param b.index pre-specified b.index (grid which has been splitted)
#' @param lambdaF tuning parameter i.e. for baseline in the cure model
#' @param ti cure model only: vector with length of number of observations with the entries ti indicating the time an observation has been observed
#' @param event cure mode only: vector with length of number of observations with the entries zero or one indicating if an event as taken pace
#' @param fixlambda dimension which is fixed in grid search: "c.lambda" or "lambda"
#' @param small.output remove some output to save memory
#' @param parallel parallilzed grid search (strongly recommended)
#' @param cores number of cores
#' @param pwi vector with weight initialization
#' @param pwi.method weight initialization: "both": constant weights and sample; "fix": only constant weights; "sample": only sample
#' @param nr.seeds weight initialization: Number of draws for each pwi
#' @param GEM Type of EM-algorithm: \code{GEM=T} Generalized EM-algorithm is used (fewer iterations in one em-step)
#' @param fn.val.option change which likelihood should be used to be optimized (usually do not change)
#' @param bootindex bootstrap only
#' @param weights vector of individual weights different from one (ussually not in use)
#' @param ... further arguments
#'
#' @return Output
#' \item{bestfit.grid}{result of penalized variable selection as discmix object}
#'
#'
#' @author Micha Schneider
#'
#' @references{
#' Schneider, Micha (2019): Dealing with Heterogeneity in Discrete Survival Analysis using the Cure Model. Technical Report 224, Department of Statistics, Ludwig-Maximilians-Universität München.
#'
#' Schneider, Micha, Pößnecker, Wolfgang and Gerhard Tutz (2019): Variable Selection in Mixture Models with an Uncertainty Component. Technical Report 225, Department of Statistics, Ludwig-Maximilians-Universität München.
#' }
#'
#' @examples
#' ## Example penalized discrete Cure Model (~ 5 minutes)
#' # Data
#' library(RcmdrPlugin.survival)
#' data(Rossi)
#' Rossi$educ <- ifelse(Rossi$educ==6,5,Rossi$educ)
#' Rossi$educ <- as.factor(Rossi$educ)
#'
#' # Data Structure
#' ymat <- matrix(NA, nrow=nrow(Rossi), ncol=52)
#' for(i in seq(nrow(ymat))){
#'   yi <- Rossi$week[i]
#'   ymat[i, 1:(yi-1)] <- 0
#'   ymat[i, yi] <- Rossi$arrest[i]*1
#' }
#' head(ymat)
#'
#' xform <- as.formula("~ fin + age + race + wexp + mar + paro + prio + educ")
#' mm <- model.matrix(xform, Rossi)
#' head(mm)
#' ncol(mm)
#'
#' lambdaseq <- c(16,5)
#' grid <- expand.grid(lambdaseq, lambdaseq)
#' colnames(grid) <- c("lambda","c.lambda")
#' grid
#'
#' # Model (max.iter=20, cores=2 not recommended)
#' set.seed(1000)
#' pen <- penmix(y = ymat, x=xform, z=xform, data=Rossi, ti=Rossi$week,
#'        model=zero.seqlogitsurv.mix, grid=grid, penindex=c(16,rep(4,10)),
#'        c.penindex=c(10,rep(12,10)), lambdaF=2, max.iter=20, cores=2)
#'
#' # Output
#' pen$bestfit.grid$model.coef[[2]][[1]][1,]
#' pen$bestfit.grid$concomitant.coef[[1]][2,]
#' mean(pen$bestfit.grid$pi[,2])
#' pen$bestfit.grid$AIC
#' pen$bestfit.grid$BIC
#'
#' @import parallel
#' @export

penmix <- function(y = y,x=x,z=NULL,model=uniform.cubbinomial,data = data, seeds=NULL,nrlambda=2,lambdamax=10,lambdamin=1,
                    c.nrlambda=nrlambda, c.lambdamax=lambdamax, c.lambdamin=lambdamin, max.iter=250, threshold=F, # 10^-6
                    rel.tol=1e-6,postweight.init=NULL, penalty=T, penindex=NULL, c.penindex=NULL, grid=NULL,b.index=NULL, lambdaF =NULL, ti=NULL, event=NULL,
                    fixlambda="c.lambda",small.output=F,parallel=T, cores=detectCores()-1,pwi=c(0.8,0.9),pwi.method="both",nr.seeds=2, GEM=F, fn.val.option="NA",bootindex=NULL,weights=NULL,...){
  if(!is.null(bootindex)){
    print("BOOTINDEX")
    data <- data[bootindex,]

    if(!is.null(weights)){
    weights <- weights[bootindex]}
    }


  if(!is.null(postweight.init)){
    if(!is.list(postweight.init)) {
      postweight.init <- list(postweight.init)
      #warning("postweight.init has to be a list")
    }
  }

  if (is.null(grid)){
  lambdalogseq <- seq(from=log(lambdamin), to=log(lambdamax), length.out=nrlambda)
  lambdaseq <- exp(lambdalogseq)
  lambdaseq <- sort(lambdaseq, decreasing=T)

  if (penalty==T) {
    if (!is.null(z))
    {
      if(is.null(c.nrlambda)){c.lambda <- lambdaseq}
      if(!is.null(c.nrlambda))
      {  c.lambdalogseq <- seq(from=log(c.lambdamin), to=log(c.lambdamax), length.out=c.nrlambda)
         c.lambdaseq <- exp(c.lambdalogseq)
         c.lambdaseq <- sort(c.lambdaseq, decreasing=T)}
    }
  }


  index <- expand.grid(lambdaseq, c.lambdaseq)
  colnames(index) <- c("lambda","c.lambda")
  }
else
{
  index <- grid
  lambdaseq <- sort(unique(index[,"lambda"]), decreasing=T)
  nrlambda <- length(lambdaseq)
  c.lambdaseq <- sort(unique(index[,"c.lambda"]), decreasing=T)
  c.nrlambda <- length(c.lambdaseq)
}

    #if (!is.null(z) & is.null(c.lambda)) {c.lambda <- lambdaseq} # MS: NEU ; alt c.lambda=0.5*lambdaseq

  if(penalty==F) {# langfristig index frueher erstellen, falls NULL fuer tuning parameter gebraucht wird
                  index <- matrix(ncol=2, nrow=1)
                  colnames(index) <- c("lambda","c.lambda")
                  index[1,"lambda"] <- 123456789 # MS
                  xx <- model.matrix(x, data=data) #
                  penindex = rep(10, ncol(xx))

                  if (!is.null(z) & is.null(c.penindex))
                  {zz <- model.matrix(z, data=data)
                   c.penindex <- rep(10, ncol(zz))
                   index[1,"c.lambda"] <- 123456789 # MS
                  }
                  lambdaseq <- 123456789  #
                  nrlambda <- 1}
  if(is.null(b.index))
    {
    print(index)
    index[,1] <- as.factor(index[,1])
    index[,2] <- as.factor(index[,2])
    #index <- cbind(as.factor(index[,1]), as.factor(index[,2]))

    print(index)
    if(fixlambda=="c.lambda"){
      b.index <- rev(split(index, f=index$c.lambda))}
    else{
      b.index <- rev(split(index, f=index$lambda))}
  }
  else{
    b.index <- b.index
  }
  if(cores > length(b.index)) {cores <- length(b.index)}

  print(b.index)
  # fitmodels: uebergebe immer geeignete sub-index Matrix pro bootindex
  #source("fitmodels-2.r")

  fitcall <- call("fitmodels", model=model, y=y, x=x, z=z, penalty=penalty, data=data, lambdaF =lambdaF, ti=ti, event=event,
                 penindex = penindex, c.penindex=c.penindex, index=substitute(index),threshold = threshold,
                 control = genmix.control(max.iter=max.iter,rel.tol=rel.tol),max.iter=max.iter, rel.tol=rel.tol,
                 postweight.init=postweight.init, small.output=small.output,pwi=pwi,pwi.method=pwi.method,nr.seeds=nr.seeds, fn.val.option=fn.val.option,GEM=GEM)

# (paralleler) Aufruf aller "Linien"
  bootcorepar <- function(i){
    bootcore(i = i)
  }

  B <- length(b.index)

  # bootcore
  bootcore <- function(i){
    #require("DiscMix")
    #require("MRSP")
    #require("VGAM") #optional?
    #source("genmix-gesamt-3.r")
    #source("penmix-6.r")
    #source("fitmodels-2.r")
    fitcall$index <- quote(b.index[[i]])

    # bei grid hier statt daten werte aus Grid übernehmen
    #fit <- try(eval(fitcall),TRUE)
    #if (!inherits(fit, 'try-error')){
    #  fit <- NULL
    #  }
    #fit
    #print(fit)
    fit <- try(eval(fitcall)) # eigentlich hier nicht notwendig, bzw. falls greift bedeutet das, dass eine komplette Serie wegfaellt
    fit
  }
  if(parallel){
    cl <- makeCluster(cores)
    clusterEvalQ(cl, {
      library(DiscMix)
    })#V2 #V3
    clusterExport(cl, c("fitcall","b.index"), envir=environment()) #V2
    #clusterExport(cl, c("fitcall"), envir=environment()) #V3
    #clusterExport(cl, ls(envir = sys.frame(sys.nframe())), envir = sys.frame(sys.nframe()))#V1
    #bootlist <- parLapply(cl, b.index, bootcorepar) #V3
    bootlist <- parLapply(cl, seq(length(b.index)), bootcorepar)#V1 #V2
    stopCluster(cl)
  }else{
    cl <- makeCluster(1)
    clusterEvalQ(cl, {
      library(DiscMix)
    })#V2 #V3
    clusterExport(cl, c("fitcall","b.index"), envir=environment()) #V2
    #clusterExport(cl, c("fitcall"), envir=environment()) #V3
    #clusterExport(cl, ls(envir = sys.frame(sys.nframe())), envir = sys.frame(sys.nframe()))#V1
    #bootlist <- parLapply(cl, b.index, bootcorepar) #V3
    bootlist <- parLapply(cl, seq(length(b.index)), bootcorepar)#V1 #V2
    stopCluster(cl)
    #get(ls(envir = parent.frame()), envir = parent.frame())
    #bootlist <- lapply(seq(B), bootcore)
  }

print("penmix sucessful")
#save(bootlist, file="bootlist_tmp.RData")

# alles Zusammenbauen
i <- 1
model.coef <- NULL
concomitant.coef <- NULL
model.coef.stand <- NULL
concomitant.coef.stand <- NULL
index <- NULL
logliks <- NULL
dfs <- NULL
aics <- NULL
bics <- NULL
iter.counts <- NULL
inner.iters <- NULL
loglik.evals <- NULL
loglik.evals2 <- NULL
fn.val.ops <- NULL
fn.val.ops2 <- NULL
comploglik.evals <- NULL
comploglik.evals2 <- NULL
comploglikpen.evals <- NULL
comploglikpen.evals2 <- NULL
postweights <- NULL
pis <- NULL

#print(B)
for(i in 1:B)
  {
  index <- rbind(index,bootlist[[i]]$index)
  dfs <- c(dfs,bootlist[[i]]$dfs)
  logliks <- c(logliks,bootlist[[i]]$logliks)
  aics <- c(aics,bootlist[[i]]$aics)
  bics <- c(bics,bootlist[[i]]$bics)
  iter.counts <- c(iter.counts,bootlist[[i]]$iter.counts)
  inner.iters <- c(inner.iters,bootlist[[i]]$inner.iters)
  model.coef <- rbind(model.coef,bootlist[[i]]$model.coef)
  concomitant.coef <- rbind(concomitant.coef,bootlist[[i]]$concomitant.coef)
  model.coef.stand <- rbind(model.coef.stand,bootlist[[i]]$model.coef.stand)
  concomitant.coef.stand <- rbind(concomitant.coef.stand,bootlist[[i]]$concomitant.coef.stand)
  loglik.evals <- c(loglik.evals,bootlist[[i]]$loglik.evals)
  loglik.evals2 <- c(loglik.evals2,bootlist[[i]]$loglik.evals2)
  fn.val.ops <- c(fn.val.ops,bootlist[[i]]$fn.val.ops)
  fn.val.ops2 <- c(fn.val.ops2,bootlist[[i]]$fn.val.ops2)
  comploglik.evals <- c(comploglik.evals,bootlist[[i]]$comploglik.evals)
  comploglik.evals2 <- c(comploglik.evals2,bootlist[[i]]$comploglik.evals2)
  comploglikpen.evals <- c(comploglikpen.evals,bootlist[[i]]$comploglikpen.evals)
  comploglikpen.evals2 <- c(comploglikpen.evals2,bootlist[[i]]$comploglikpen.evals2)
  postweights <- c(postweights,bootlist[[i]]$postweights)
  pis <- c(pis, bootlist[[i]]$pis)
  }

# Bester Fit
## select the best model according to, e.g., BIC:
bestm <- which(bics == min(bics, na.rm=T), arr.ind = TRUE)
print(bestm)
if (length(bestm)>1) {warning("more than one minimal combination")}

best.lambda <- as.numeric(as.matrix(index[bestm[1],]))
#best.pos <- as.numeric(rownames(index[bestm[1],]))
best.lambda.asc <- which(sort(lambdaseq)==as.numeric(best.lambda[1]))
best.lambda.asc[2] <- which(sort(c.lambdaseq)==as.numeric(best.lambda[2]))
best.lambda.dsc <- which(lambdaseq==as.numeric(best.lambda[1]))
best.lambda.dsc[2] <- which(c.lambdaseq==as.numeric(best.lambda[2]))

if(small.output==F){
  if(fixlambda=="c.lambda") {bestfit.grid <- bootlist[[best.lambda.dsc[2]]]$fit[[best.lambda.dsc[1]]]}
  if(fixlambda=="lambda") {bestfit.grid <- bootlist[[best.lambda.dsc[1]]]$fit[[best.lambda.dsc[2]]]} #? ungetestet
  if(!all(lambdaseq==c.lambdaseq)){warning("bestfit.grid may be not selected correctly")}
  }
else{bestfit.grid <- NULL}

# Langer Durchlauf mit Bestem Modell
# Call
rel.tol2 <- rel.tol/10 #test 13.09
fitcall <- call("penmixfit", parallel=F, model=model, y = y, x=x, z=z, penalty=penalty, data=data,
                 lambda = as.numeric(as.character(index[bestm[1],"lambda"])),
                 c.lambda = as.numeric(as.character(index[bestm[1],"c.lambda"])),
                 penindex = penindex, c.penindex=c.penindex,threshold=threshold,
                 control = genmix.control(max.iter=max.iter,rel.tol=rel.tol2),
                 postweight.init=postweights[[bestm[1]]],small.output=F,
                 #model.coef.init = matrix(model.coef[best.pos,],nrow=9),
                 #concomitant.coef.init = list(matrix(rbind(0,concomitant.coef[best.pos,]),nrow=2)),#5.5.19
                 #concomitant.coef.init = concomitant.coef[best.pos,],
                 pi.init = pis[[bestm[1]]], lambdaF =lambdaF, ti=ti, event=event,
                 pwi.method="none", fn.val.option=fn.val.option,GEM=GEM)

if(is.null(lambdaF)){fitcall$lambdaF <-as.numeric(as.character(index[bestm[1],"lambda"]))} # NEU 23.10.2018
print("selected model:")
bestfit <- try(eval(fitcall)) #try?
best.model.coef <- bestfit$model.coef[[2]][[1]]
best.model.coef.eval <- bestfit$model.coef.eval
best.model.coef.eval2 <- bestfit$model.coef.eval2
best.model.coef.stand <- bestfit$model[[2]]$fit@coef.stand[[1]]
best.model.coef.stand.eval <-  bestfit$model.coef.stand.eval
best.model.coef.stand.eval2 <-  bestfit$model.coef.stand.eval2
best.concomitant.coef <- bestfit$concomitant.coef[[1]][2,]
best.concomitant.coef.eval <- bestfit$concomitant.coef.eval
best.concomitant.coef.eval2 <- bestfit$concomitant.coef.eval2
best.concomitant.coef.stand <- bestfit$concomitant$fit@coef.stand[[1]][2,]
best.concomitant.coef.stand.eval <- bestfit$concomitant.coef.stand.eval
best.concomitant.coef.stand.eval2 <- bestfit$concomitant.coef.stand.eval2
best.postweight.eval <- bestfit$postweight.eval
best.postweight.eval2 <- bestfit$postweight.eval2
best.pi.eval <- bestfit$pi.eval
best.pi.eval2 <- bestfit$pi.eval2
best.pi <-  mean(bestfit$pi[,2])
best.loglik.eval2 <- bestfit$loglik.eval2 # MS das waere von second run
best.loglik.eval <- bestfit$loglik.eval # MS das waere von first run
best.fn.val.op2 <- bestfit$fn.val.op2
best.fn.val.op <- bestfit$fn.val.op
best.comploglik.eval2 <- bestfit$comploglik.eval2
best.comploglikpen.eval2 <- bestfit$comploglikpen.eval2
best.comploglik.eval <- bestfit$comploglik.eval
best.comploglikpen.eval <- bestfit$comploglikpen.eval

# Rueckgabe
list(bestfit.grid=bestfit.grid, bestfit=bestfit, index=index, bestm=bestm, lambdaseq=lambdaseq, c.lambdaseq=c.lambdaseq, best.lambda=best.lambda,
     logliks=logliks, dfs=dfs, aics=aics, bics=bics, pis=pis,
     iter.counts=iter.counts, inner.iters=inner.iters,
     loglik.evals=loglik.evals, loglik.evals2=loglik.evals2,
     fn.val.ops=fn.val.ops, fn.val.ops2=fn.val.ops2,
     comploglik.evals=comploglik.evals, comploglik.evals2=comploglik.evals2,
     comploglikpen.evals=comploglikpen.evals, comploglikpen.evals2=comploglikpen.evals2,
     postweights=postweights,#zur Diagnose; sonst unwichtig
     model.coef=model.coef, concomitant.coef=concomitant.coef,
     model.coef.stand=model.coef.stand, concomitant.coef.stand=concomitant.coef.stand,
     #
     best.model.coef=best.model.coef, best.concomitant.coef=best.concomitant.coef,
     best.model.coef.stand=best.model.coef.stand, best.concomitant.coef.stand=best.concomitant.coef.stand,
     best.lambda.asc=best.lambda.asc, best.lambda.dsc=best.lambda.dsc, best.pi=best.pi,
     best.model.coef.eval=best.model.coef.eval, best.model.coef.stand.eval=best.model.coef.stand.eval,
     best.concomitant.coef.eval=best.concomitant.coef.eval,
     best.concomitant.coef.stand.eval=best.concomitant.coef.stand.eval,
     best.postweight.eval=best.postweight.eval, best.pi.eval=best.pi.eval,
     best.model.coef.eval2=best.model.coef.eval2, best.model.coef.stand.eval2=best.model.coef.stand.eval2,
     best.concomitant.coef.eval2=best.concomitant.coef.eval2,
     best.concomitant.coef.stand.eval2=best.concomitant.coef.stand.eval2,
     best.postweight.eval2=best.postweight.eval2, best.pi.eval2=best.pi.eval2,
     best.loglik.eval2=best.loglik.eval2, best.loglik.eval=best.loglik.eval,
     best.fn.val.op2 = best.fn.val.op2, best.fn.val.op = best.fn.val.op ,
     best.comploglik.eval2=best.comploglik.eval2, best.comploglikpen.eval2=best.comploglikpen.eval,
     best.comploglik.eval=best.comploglik.eval,best.comploglikpen.eval=best.comploglikpen.eval
)
}
