# Function to perform bootstrap standard errors in DiscMix
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker


#' Function to perform bootstrap (BS) standard errors for discmix models
# (mainly covariates)
#'
#' @param BS.seed seed for generating BS.seedindex inside function
#' @param B number of Bootstrap samples
#' @param BS.seedindex vector of BS seeds which is external generated
#' @param parallel parallelized BS if \code{parallel=T} (strongly recommended)
#' @param cores number of cores
#' @param dat data for specific models
#' @param data data for specific models
#' @param y response as in discmix
#' @param x design matrix for the model/preference component as in discmix
#' @param z design matrix for the weights as in discmix
#' @param u design matrix for the shape of the uncertainty component as in discmix
#' @param x.long design matrix for specific survival models as in discmix (usually not in use)
#' @param y.long response matrix for specific survival models as in discmix (usually not in use)
#' @param weights vector of individual weights different from one (ussually not in use)
#' @param M number of models/mixture components (usually 2)
#' @param model Choose the kind of Mixture Model to be fitted. For an overview see discmix
#' @param control control object for em algorithm, i.e. \code{rel.tol} for relative tolerance or \code{max.iter} for maximum number of em iterations
#' @param objectcall objectcall (usually not in use)
#' @param model.initialseed model initialseed
#' @param control.init control information for initialization
#' @param small.output remove some output to save memory
#' @param cublass internal parameter
#' @param cub internal parameter
#' @param survival internal parameter
#' @param alpha alpha value to specify specific beta-binomial distributions
#' @param family2 family argument for specific model components
#' @param sp smoothing for specific model components (in combination with family2)
#' @param intercept.smooth smoothing the intercept in specific cure models
#' @param intercept.lambda tuning parameter for intercept smoothing
#' @param ti cure model only: vector with length of number of observations with the entries ti indicating the time an observation has been observed
#' @param event cure mode only: vector with length of number of observations with the entries zero or one indicating if an event as taken place
#' @param postweight.init postweight initialization (usualy not in use)
#' @param c.maxiter maximum number of iterations in the z/concomitant component
#' @param maxiter1  maximum number of iterations in the first model component
#' @param maxiter2  maximum number of iterations in the second model component
#' @param pwi vector with weight initialization
#' @param nr.seeds weight initialization: Number of draws for each pwi
#' @param pwi.method weight initialization: "both": constant weights and sample; "fix": only constant weights; "sample": only sample
#' @param seed.init initial seed
#' @param GEM Type of EM-algorithm: \code{GEM=T} Generalized EM-algorithm is used (fewer iterations in one em-step)
#' @param help Stabilization of estimation process by preventing weights to be too close to zero or one
#' @param min.size minimum size of one response category in the BS sample
#' @param min.size2 minimum size of one response category in the BS sample
#' @param fn.val.option change which likelihood should be used to be optimized (usually do not change)
#' @param q1 lower quantile for nonparametric bootstrap samples
#' @param q2 upper quantile for nonparametric bootstrap samples
#' @param ... further arguments
#'
#' @return
#' \item{se.model.coef1}{standard error of the estimates of the first component/u (i.e. beta-binomial part in BetaBin model)}
#' \item{q.model.coef1}{quantiles of the estimates of the first component/u (i.e. beta-binomial part in BetaBin model)}
#' \item{se.model.coef2}{standard error of the estimates of the second component/x (i.e. cumulative part in CUP models)}
#' \item{q.model.coef2}{quantiles of the estimates of the first component/x (i.e. cumulative part in CUP models)}
#' \item{se.concomitant.coef}{standard error of the estimates of the concomitant/z}
#' \item{q.concomitant.coef}{quantiles of the estimates of the concomitant/z}
#' \item{se.pi}{standard error of the pi estimates (agregated)}
#' \item{q.pi}{quantiles of the pi estimates (agregated)}
#' \item{BS.seedindex}{used seedindex}
#' \item{BS.seedindex_errors}{seedindex with non-regular behavior of the bootstrap samples}
#' \item{error_messages}{messages of bootstrap samples with non-regular behavior}
#'
#' @author Micha Schneider
#'
#' @examples
#' # Data Generation
#' arthritis <- data.frame(drug=c(rep("new agent", 24+37+21+19+6),
#' rep("active control", 11+51+22+21+7)),
#' assessment=c(rep(1,24), rep(2,37), rep(3,21), rep(4,19), rep(5,6), rep(1,11),
#'              rep(2,51), rep(3,22), rep(4,21), rep(5,7)))
#'
#' # Response matrix y
#' table(arthritis$assessment, arthritis$drug)
#' y <- as.matrix(arthritis$assessment)
#' colnames(y) <- c("assessment")
#' head(y)
#'
#' # Design Matrix x
#' x <- matrix(1, nrow=nrow(arthritis), ncol = 1)
#' x[,1] <- arthritis$drug
#' x[,1] <- x[,1] - 1
#' colnames(x) <- c("drug")
#' head(x)
#'
#' # Bootstrap samples
#' set.seed(1000)
#' BS.seedindex  <- sample(x=seq(1000), 2)
#' # CUP(c) (vgam) (< 1min)
#' boots <- se.discmix(B=2,y=y, x=x, BS.seedindex=BS.seedindex,
#'          model=uniform.cumlogit.mix.vgam, cores=2)
#'
#' # Output
#' boots$se.model.coef2
#' boots$q.model.coef2
#' boots$se.concomitant.coef # no z matrix specified
#' boots$q.concomitant.coef # no z matrix specified
#' boots$se.pi
#' boots$q.pi
#' boots$BS.seedindex_errors # no non-regular behavior
#'
#' # CUB
#' boots <- se.discmix(B=4,y=y, x=x, BS.seedindex=BS.seedindex,
#'          model=uniform.cubbinomial, cores=2)
#' @import parallel
#' @import stats
#'
#' @export

se.discmix <- function (BS.seed=1000, B=2, BS.seedindex=NULL, parallel=T,cores=detectCores()-1, dat=NULL, data=NULL, # BS
                           y, x=NULL, z=NULL, u=NULL, x.long=NULL,y.long=NULL, weights=NULL, M = 2, model=uniform.cumlogit.mix.vgam, objectcall=NULL, # Model/daten
                           model.initialseed=1000,control = genmix.control(rel.tol=1e-6, max.iter=6000), control.init=genmix.control(),small.output=T,
                           cublass=F,cub=F,survival=F,alpha=NULL,family2=NA,sp=NULL,intercept.smooth=NULL,intercept.lambda=NULL,ti=NULL,event=NULL, postweight.init=NULL,
                           c.maxiter=NULL, maxiter1=NULL,maxiter2=NULL,pwi=c(0.6,0.7,0.8,0.9),nr.seeds=2,pwi.method="both",seed.init=1000,GEM=F,help=F,min.size=min(table(y))/2,min.size2=min.size,fn.val.option="NA",
                           q1=0.025, q2=0.975, ...)
{
  boot1 <- bootp.discmix(BS.seed=BS.seed, B=B, BS.seedindex=BS.seedindex, parallel=parallel, cores=cores, dat=dat, data=data, # BS
                                  y=y, x=x, z=z, u=u, x.long=x.long, y.long=y.long, weights=weights, M = M, model=model, objectcall=objectcall, # Model/daten
                                  model.initialseed=model.initialseed, control = control, control.init=control.init, small.output=small.output,
                                  cublass=cublass, cub=cub, survival=survival, alpha=alpha, family2=family2, sp=sp, intercept.smooth=intercept.smooth, intercept.lambda=intercept.lambda, ti=ti, event=event, postweight.init=postweight.init,
                                  c.maxiter=c.maxiter, maxiter1=maxiter1, maxiter2=maxiter2, pwi=pwi, nr.seeds=nr.seeds, pwi.method=pwi.method, seed.init=seed.init, GEM=GEM, help=help, min.size=min.size, min.size2=min.size2, fn.val.option=fn.val.option,...)

# Result summary

  boot_errors <- which(lapply(boot1,function(x) is.character(x))==TRUE)#
  #boot_errors
  if(!length(boot_errors)==0){
    BS.seedindex_errors <- BS.seedindex[boot_errors]
    #boot2_seedindex <- BS.seedindex[-c(boot_errors )]
    error_messages <- boot1[c(boot_errors)]
    boot1 <- boot1[-c(boot_errors)]
  }else{
    BS.seedindex_errors <- NULL
    #boot2_seedindex <- BS.seedindex
    error_messages <- NA
  }
  BS <- length(boot1)
  #unique(error_messages)

  BS.seedindex <- c()
  pi <- c()

  #model.coef2 <- matrix(nrow=BS, ncol=7)
  #colnames(model.coef2) <- names(boot2[[1]]$model.coef[[2]][[1]][1,-1]) # MRSP-Variante

  if(!is.list(model)) model <- evalh(model)

  # first model component
  # BeaBinom Model
  if(model[[1]]=="beta.binom.vglm"){
    model.coef1 <- matrix(nrow=BS, ncol=length(names(boot1[[1]]$model.coef[[1]])))
    colnames(model.coef1) <- names(boot1[[1]]$model.coef[[1]])
    vgam1 <- T
  }else{
    vgam1 <- F
    model.coef1 <- NULL
  }

  # second model component
  # VGAM
  if(model[[2]]=="vgamseqlogit"|model[[2]]=="vgamcumlogit"|model[[2]]=="vgamacatlogit"|model[[2]]=="beta.binom"|model[[2]]=="beta.binom.vglm"){
    model.coef2 <- matrix(nrow=BS, ncol=length(names(boot1[[1]]$model.coef[[2]])))
    colnames(model.coef2) <- names(boot1[[1]]$model.coef[[2]])
  vgam2 <- T
  }

  #MRSP
  if(model[[2]]=="seqlogitsurv"|model[[2]]=="seqlogit"|model[[2]]=="cumlogit"|model[[2]]=="cubbinomiallasso"){
    model.coef2 <- matrix(nrow=BS, ncol=length(colnames(boot1[[1]]$model.coef[[2]][[1]][1,-1,drop=F])))
    colnames(model.coef2) <- colnames(boot1[[1]]$model.coef[[2]][[1]][1,-1,drop=F])
  vgam2 <- F
  }

  # concomitant
  concomitant.coef <- matrix(nrow=BS, ncol=length(names(boot1[[1]]$concomitant.coef[[1]][2,])))
  colnames(concomitant.coef) <- names(boot1[[1]]$concomitant.coef[[1]][2,])

  for(i in 1:BS)
  {
    BS.seedindex[i] <- boot1[[i]]$BS.seedindex
    pi[i] <- mean(boot1[[i]]$pi[,2])
    if(vgam1==T){
     model.coef1[i,] <- boot1[[i]]$model.coef[[1]]
    }else{
     model.coef1 <- NULL
    }

    if(vgam2==T){
      model.coef2[i,] <- boot1[[i]]$model.coef[[2]]
    }else{
      model.coef2[i,] <- boot1[[i]]$model.coef[[2]][[1]][1,-1]
    }
    #print("BS:")
    #print(model.coef2)

    concomitant.coef[i,] <- boot1[[i]]$concomitant.coef[[1]][2,]
  }
  if(!is.null(model.coef1)){
    se.model.coef1 <- apply(X=model.coef1,MARGIN=2,FUN=sd)
    q.model.coef1 <- apply(X=model.coef1,MARGIN=2,FUN=function(x)quantile(x,c(q1,q2)))#q1=0.025, q2=0.975,
  }else{
    se.model.coef1 <- NULL
    q.model.coef1 <- NULL
  }

  se.model.coef2 <- apply(X=model.coef2,MARGIN=2,FUN=sd)
  q.model.coef2 <- apply(X=model.coef2,MARGIN=2,FUN=function(x)quantile(x,c(q1,q2)))#q1=0.025, q2=0.975,

  se.concomitant.coef <- apply(X=concomitant.coef,MARGIN=2,FUN=sd)
  q.concomitant.coef <- apply(X=concomitant.coef,MARGIN=2,FUN=function(x)quantile(x,c(q1,q2)))

  se.pi <- sd(pi)
  q.pi <- quantile(pi,c(q1,q2))

list(se.model.coef1=se.model.coef1, q.model.coef1=q.model.coef1, se.model.coef2=se.model.coef2, q.model.coef2=q.model.coef2, se.concomitant.coef=se.concomitant.coef, q.concomitant.coef=q.concomitant.coef,
     se.pi=se.pi, q.pi=q.pi, BS.seedindex=BS.seedindex, BS.seedindex_errors=BS.seedindex_errors, error_messages=error_messages)
}
