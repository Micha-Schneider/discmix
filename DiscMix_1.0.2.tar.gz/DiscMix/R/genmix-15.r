######################################################################################
#####    An R Package for fitting general finite mixture models; part of DiscMix #####
######################################################################################
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker

## the main fitting function:
## -------------------------------------------------------------------------- ##
## Arguments:
   ## y: a response vector or matrix whose length/nrow determines 'nobs', the
   ##    number of observations.
   ## x: a design matrix with 'nobs' rows to be used for the mixture components.
   ##    if missing, a sole intercept column will be added as x by genmix. then,
   ##    the mixture model reduces to a mixture of densities. if x is supplied,
   ##    but without an intercept column, then such an intercept column is added
   ## z: optional matrix of concomitant variables. if missing, the prior prob-
   ##    abilities are fixed for all observations.
   ## M: number of models/mixture components to be used. this is the order of
   ##    the mixture.
   ## model: a list of length M whose entries are characters which give the name
   ##    of model driver functions to be used for the respective M-step. for an
   ##    example, see "linreg" in genmix-models (line 62ff.)
   ##   Alternatively, model can be a function that constructs such a model
   ##    object (or the quoted name of such a constructor function). for an
   ##    example, see "linregmix" in genmix-models (line 92ff.)
   ## model.args: a list of length M whose elements are themselves lists with
   ##    additional/optional arguments for the M-step driver functions in model.
   ## concomitant: name of a function that implements the M-step for the conco-
   ##    mitant variable model. unless you have specific reasons, it's best to
   ##    leave it at its default.
   ## concomitant.args: list with additional arguments for the function in
   ##    'concomitant'.
   ## model.coef.init: list of length M whose elements are the initial coeffi-
   ##    cient objects for the respective mixture components.
   ## concomitant.coef.init: initial coefficient object for the concomitant
   ##    model function from argument 'concomitant'. for the default function,
   ##    an M x d matrix must be supplied. (with d denoting the coldim of z.)
   ## postweight.init: initial posterior weights to be used. an nobs x M matrix.
   ##    specifying this can be useful when comparing two different mixtures
   ##    with each other since the quality of the solution found by the EM algo-
   ##    rithm for finite mixture models depends heavily on the initialization.
   ## pi.init: a matrix of dim nobs x M specifying the initial prior probabili-
   ##    ties. the rowSums of pi.init must be 1!
   ## offset: an offset vector to be used for the mixture components.
   ## weights: a vector of length nobs assigning differing weights to different
   ##    observations. can be useful for data with repeated measurements.
   ## control: an object of class "genmix.control" which contains control info.
   ##    it has slots 'rel.tol', 'max.iter' and 'trace'.
   ## checks: (quoted or unquoted) name of a function (which has no arguments)
   ##    that implements the checks to be used. some default checks are given in
   ##    the default, which can be found in genmix-helpers (line 94ff.)
   ##    depending on the models you use, you should add customized checks for
   ##    your model class.
   ## initialseed: a number that is used as a little trick to make the results
   ##    of genmix be reproducible across versions of genmix.
   ##    Background: if postweight.init is missing, a starting clustering of
   ##    observations is randomly drawn in function "postweight.initialization".
   ##    if a seed it set before the call to genmix in some data analysis files,
   ##    it might happen that changes in the code of genmix before the call to
   ##    postweight.initialization change the state of the random number
   ##    generator. thus, without this trick, results of genmix could differ
   ##    for different versions of genmix, even if the same set.seed(.) was used
   ##    before the call to genmix and no changes to the actual computations
   ##    took place.
   ## x.long, y.long: Matrices for cure-Models
   ## u: Matrix for beta-binomial-Effekt (not available)
   ## cub: CUB-Modell ? (not available)
   ## cublass: CUB-Lasso? -> inner.iter.count
## -------------------------------------------------------------------------- ##
#' Internal function of the EM-Algorithm
#' @author Wolfgang Pößnecker and Micha Schneider
#' @param y a response vector or matrix whose length/nrow determines 'nobs', the number of observations
#' @param x a design matrix with 'nobs' rows to be used for the mixture components
#' @param z optional matrix of concomitant variables
#' @param hasZ matrix of concomitant variables available?
#' @param pass.coefs should the coefficients be passed (for initialization)?
#' @param nobs number of observations
#' @param trace additional fitting information
#' @param M number of models/mixture components (usually 2)
#' @param model kind of mixture model
#' @param model.args additional model arguments (a list of length M whose elements are themselves lists with additional/optional arguments for the M-step component functions)
#' @param control genmix control object
#' @param concomitant type of concomitant (do not change)
#' @param concomitant.args additional concomitant arguments
#' @param offset offset
#' @param weights a vector of length nobs assigning differing weights to different observationse (ussually not in use)
#' @param cublass internal parameter
#' @param postweight postweight initialization
#' @param model.coef model coefficient initialization
#' @param concomitant.coef concomitant coefficient initialization
#' @param max.iter maximum number of iterations
#' @param min.iter minimum number of iterations
#' @param rel.tol relative tolerance for convergence
#' @param logl loglikelihood based on the initial models
#' @param fn.val used loglikelihhood estimate
#' @param loglik.eval loglikelihood (without postweights, without penalty term)
#' @param fn.val.op loglikelihood (without postweights, with penalty term)
#' @param fn.val.op.w loglikelihood (without postweights, with weighted penalty term)
#' @param comploglik.eval complete loglikelihood (with postweights, without penalty term)
#' @param comploglikpen.eval penalized complete loglikelihood (with postweights, with penalty term )
#' @param comploglikpen.w.eval penalized complete loglikelihood (with postweights, with weighted penalty term)
#' @param d.fn relative difference of two loglikelihoods
#' @param iter.count number of iterations of the em algorithm
#' @param cumulative.inner.iter.count number of iterations in one mode component
#' @param help Stabilization of estimation process by preventing weights to be too close to zero or one
#' @param fn.val.option change which likelihood should be used to be optimized (usually do not change)
# control -> genmix.control
em <- function(y=y, x=x, z=z, hasZ=hasZ, pass.coefs=pass.coefs,nobs=nobs,trace=trace,
               M=M, model=model, model.args=model.args, control=control,
               concomitant=concomitant, concomitant.args=concomitant.args,
               offset=offset, weights=weights, cublass=cublass,
               postweight=postweight, model.coef=model.coef, concomitant.coef=concomitant.coef,
               max.iter = control@max.iter, min.iter = control@min.iter, rel.tol = control@rel.tol,
               logl=logl, fn.val=fn.val, loglik.eval=loglik.eval, fn.val.op=fn.val.op, fn.val.op.w=fn.val.op.w,
               comploglik.eval=comploglik.eval, comploglikpen.eval=comploglikpen.eval, comploglikpen.w.eval=comploglikpen.w.eval,
               d.fn=1, iter.count = 0, cumulative.inner.iter.count = 0, help=help, fn.val.option="complete"){

  trace<- TRUE # temp
  if(trace==T){
  model.coef.eval <- list()
  model.coef.stand.eval <- list()
  concomitant.coef.eval <- list()
  concomitant.coef.stand.eval <- list()
  postweight.eval<- list()
  pi.eval<- list()
  }
  out.eval.full <- as.list(rep(NA,max.iter))
  d.fn.full <- c()
  fn.val.full <- c()
  diverge.full <- rep(NA,max.iter)
  em.diverge <- 0

  not.stop <- F
  fn.val.start <- fn.val
  # Startlikelihoods (position 1):
  #loglik.eval <- fn.val.op
  #fn.val.eval <- fn.val
  #comploglik.eval[1] <- comploglik.eval
  #comploglikpen.eval[1] <- comploglikpen.eval

  ############ begin of the EM algorithm ########################################
  while(d.fn > rel.tol || not.stop || iter.count < min.iter ){ # MS: mind. 2 Iterationen
    iter.count <- iter.count + 1
    if(iter.count > max.iter){
      if(trace){warning(paste("Maximum number of EM iterations reached"))}
      break
    }

    #### M-step:
    ## update the mixture components
    updatedfit <- list(); length(updatedfit) <- M
    for(m in seq_len(M)){
      paralist <- list(y=y, x=x, M=M, coef=NULL, postweight=c(postweight[,m]),
                       offset=offset, weights=weights)
      if(pass.coefs) paralist$coef <- model.coef[[m]]
      updatedfit[[m]] <- eval(as.call(c(as.symbol(model[[m]]), paralist, model.args[[m]])))
    }

    if (cublass==T)
    {
      cumulative.inner.iter.count <- cumulative.inner.iter.count + updatedfit[[2]]$fit@iter.count      ### warnung: die cumulative.inner.iter.count-geschichte klappt nur f?r cublasso.
    }
    else
    {cumulative.inner.iter.count <- NULL}
    ## update the coefs of the concomitant model if necessary:
    if(hasZ){
      paralist <- list(y=postweight, z=z, M=M, coef=NULL, weights=weights)
      if(pass.coefs) paralist$coef <- concomitant.coef
      updatedconcomitant <- eval(as.call(c(as.symbol(concomitant), paralist , concomitant.args)))
    }else{
      updatedconcomitant <- NULL
    }

    ## extract updated component objects:
    logl <- do.call("cbind", lextract(updatedfit, "logl")) # individual loglik contributions
    model.coef <- lextract(updatedfit, "coef")
    model.coef.stand <- lextract(updatedfit, "coef.stand") # MS
    if(hasZ) {concomitant.coef <- updatedconcomitant$coef
              concomitant.coef.stand <- updatedconcomitant$coef.stand}
    else {concomitant.coef <- NULL
          concomitant.coef.stand  <- NULL} # MS 28.10.2014
    # erst da ab second genmix run
    ## update pi:
    if(hasZ){
      pi <- updatedconcomitant$mu
    }else{
      pi <- matrix(colMeans(postweight), nrow = nobs, ncol = M, byrow = T)
    }
    ## compute quantities for convergence checking:
    fn.val.old <- fn.val
    loglik <- mixloglik(logl = logl, pi = pi, weights = weights) # incomplete/mixture loglik negativ
    penalty_weighted <- getpenalty(fit = updatedfit, pi = pi, L = M) +
    ifelse(hasZ, getpenalty(fit = updatedconcomitant, pi = matrix(1, nrow=nobs, ncol=M), L = 1),  0)
    penalty <- getpenalty(fit = updatedfit, pi = matrix(1, nrow=nobs, ncol=M), L = M) +
               ifelse(hasZ, getpenalty(fit = updatedconcomitant, pi = matrix(1, nrow=nobs, ncol=M), L = 1),  0)

    loglikpen <- loglik - penalty # + oder - penalty?
    loglikpen_weighted <- loglik - penalty_weighted
    comploglik <- sum(weights * (postweight * log(pi) + postweight * logl))
    comploglikpen_weighted <- comploglik - # complete data loglik mit  penalty MS NEU
                     getpenalty(fit = updatedfit, pi = postweight, L = M) -
                     ifelse(hasZ, getpenalty(fit = updatedconcomitant, pi = matrix(1, nrow=nobs, ncol=M), L = 1),  0)
    comploglikpen <- comploglik - # complete data loglik mit  penalty MS NEU
      getpenalty(fit = updatedfit, pi = matrix(1, nrow=nobs, ncol=M), L = M) -
      ifelse(hasZ, getpenalty(fit = updatedconcomitant, pi = matrix(1, nrow=nobs, ncol=M), L = 1),  0)

    loglik.eval[iter.count+1] <- loglik
    #fn.val.op[iter.count+1] <- loglik
    fn.val.op[iter.count+1] <- loglikpen
    fn.val.op.w[iter.count+1] <- loglikpen_weighted
    comploglik.eval[iter.count+1] <- sum(weights * (postweight * log(pi) + postweight * logl))   # complete data loglik ohne penalty MS NEU
    comploglikpen.eval[iter.count+1] <- comploglikpen  # complete data loglik mit  penalty MS NEU
    comploglikpen.w.eval[iter.count+1] <- comploglikpen_weighted
    if(fn.val.option=="complete")#fn.val muss immer positiv sein
    {
      fn.val <- -comploglikpen
    }
    else {fn.val <- -loglikpen}

    if(fn.val > fn.val.old+0.5e-1){ # old -4
      #warning(paste("The mixture loglikelihood has worsened in EM iteration",iter.count, sep = " "))
      diverge.full[iter.count] <- 1
      em.diverge <- em.diverge + 1
      # eigentlich irgendwas am algo tunen -> d.h. next, iter.count zuruecksetzen, und halbe schrittl?nge oder so
      # fista.control ?!; postweight = y in multinomial-MRSP?
      }
    else {diverge.full[iter.count] <- 0}
    print(paste("updated loglikpen in iteration ",iter.count,": ",fn.val.op[iter.count+1], sep="")) #MS 12.07 mit penalty
    #print(paste("updated loglikpen.w in iteration ",iter.count,": ",fn.val.op.w[iter.count+1], sep="")) #MS 12.07 mit penalty
    #print(paste("updated loglik in iteration ",iter.count,": ",loglik.eval[iter.count+1], sep="")) #MS 12.07. ohne pen (devor andersrum!!!) fn.val.eval=loglik.eval
    #print(paste("updated comploglikpen in iteration ",iter.count,": ",comploglikpen.eval[iter.count+1], sep="")) #MS
    #print(paste("updated comploglikpen.w in iteration ",iter.count,": ",comploglikpen.w.eval[iter.count+1], sep="")) #MS
    #print(paste("updated comploglik in iteration ",iter.count,": ",comploglik.eval[iter.count+1], sep="")) #MS

    if(trace==T){
      model.coef.eval[[iter.count+1]] <- model.coef
      model.coef.stand.eval[[iter.count+1]] <- model.coef.stand
      concomitant.coef.eval[[iter.count+1]] <- concomitant.coef
      concomitant.coef.stand.eval[[iter.count+1]] <- concomitant.coef.stand
      postweight.eval[[iter.count+1]]<- postweight
      pi.eval[[iter.count+1]]<- pi
    }

    #d.fn.old <- d.fn   # d.fn.old is currently unused # hier egal ob fn.val positiv oder negativ
    d.fn <- abs((fn.val - fn.val.old)/(rel.tol/10 + abs(fn.val)))
    if(diverge.full[iter.count] == 1 && iter.count > 1) ## MS diverge nicht in erster iteration
    {
      print(paste("The mixture loglikelihood has worsened in EM iteration (iter.count =",iter.count, ")"))
    } # MS: NEU

    #### E-step:
    postweight <- update.postweight(logl = logl, pi = pi)

    if(help==T) # welchen Schwellenwert einstellen? eigentlich e-8, aber teilweise e-5 notwendig
    {
      postweight <- ifelse(postweight<1e-6,1e-6,postweight)             # 1e-2 fuer afd 1e-6   1e-8 umgestellt 22.02.2018
      postweight <- ifelse(postweight>0.999999,0.999999,postweight)       # 0.999999 0.99999999
    }
    # Hier letzten 10 Durchlaeufe abspeichern und danach immer ueberschreiben/wegwerfen; max.iter beschraenkt laenge
    # wenn zwei hintereinander schlechter bzw. in so und sovielen Schriiten keine Besserung, dann zurueckspringen und break
    # NEU: evtl. Reihenfolge von Tests aendern!!!
    out.eval.full[[iter.count]] <- list(weights=weights, postweight=postweight, pi=pi, logl=logl, updatedfit= updatedfit,
                                   updatedconcomitant=updatedconcomitant, loglik=loglik, comploglik=comploglik, loglikpen=loglikpen, comploglikpen=comploglikpen,
                                   loglikpen_weighted =loglikpen_weighted, comploglikpen_weighted =comploglikpen_weighted, penalty=penalty,
                                   model.coef.stand=model.coef.stand, model.coef=model.coef,
                                   concomitant.coef.stand=concomitant.coef.stand, concomitant.coef=concomitant.coef,
                                   iter.count = iter.count, cumulative.inner.iter.count = cumulative.inner.iter.count,
                                   loglik.eval=loglik.eval,fn.val.op=fn.val.op,fn.val.op.w=fn.val.op.w,comploglik.eval=comploglik.eval,
                                   comploglikpen.eval=comploglikpen.eval,comploglikpen.w.eval=comploglikpen.w.eval, diverge.full=diverge.full, em.diverge=em.diverge,
                                   model.coef.eval=model.coef.eval, model.coef.stand.eval=model.coef.stand.eval,
                                   concomitant.coef.eval=concomitant.coef.eval, concomitant.coef.stand.eval=concomitant.coef.stand.eval,
                                   postweight.eval=postweight.eval, pi.eval=pi.eval, fn.val=fn.val, fn.val.start=fn.val.start
    )
    d.fn.full[iter.count] <- d.fn
    fn.val.full[iter.count] <- fn.val
    if(iter.count > 10) {
      diverge <- diverge.full
      diverge.full[iter.count-10] <- NA
      out.eval.full[iter.count-10]<-NA
      d.fn.full[iter.count-10]<-NA
      fn.val.full[iter.count-10]<-NA
    } # v.a. Speicherersparung
    out.eval <- out.eval.full[which(is.na(out.eval.full)==F)]# nur letzten x/10-Durchlaeufe abgespeichertNegate(is.na)
    evall <- length(out.eval)

    d.fn.eval <- Filter(Negate(is.na), d.fn.full)
    fn.val.eval <- Filter(Negate(is.na), fn.val.full)
    diverge.eval <- Filter(Negate(is.na), diverge.full)

    # Verschlechterung abfedern:
    #print("Test convergence")
    #print(fn.val.eval)
    if(evall>5){ # bei x/4-mal verschlechterung im Vgl. zu "besten" gefundenen Likelihood Abbrechen -> d.h. wenn ueber Huegel ruebergesprungen
      if(round(fn.val.eval[[evall-5]],3) <= round(fn.val.eval[[evall-4]],3) & round(fn.val.eval[[evall-5]],3) <= round(fn.val.eval[[evall-3]],3) & round(fn.val.eval[[evall-5]],3) <= round(fn.val.eval[[evall-2]],3) & round(fn.val.eval[[evall-5]],3) <= round(fn.val.eval[[evall-1]],3) & round(fn.val.eval[[evall-5]],3) <= round(fn.val.eval[[evall]],3)){
      print("Exit: No substantial improvement of the likelihood during 5 iterations")
        #save(out.eval,file = "out_eval_full.RData")
        return(out.eval[[evall-5]])
        break
      }
    }
    #if(evall==1){if(diverge.eval[evall]>0){not.stop <- T}} #keine Bestrafung, wenn nach init etwas schlechter
    if(evall==2){if(sum(c(diverge.eval[evall]))>0){not.stop <- T}}#diverge.eval[evall-1]
    if(evall==3){if(sum(c(diverge.eval[evall],diverge.eval[evall-1]))>0){not.stop <- T}}
    if(evall==4){if(sum(c(diverge.eval[evall],diverge.eval[evall-1],diverge.eval[evall-2]))>0){not.stop <- T}}
    if(evall==5){if(sum(c(diverge.eval[evall],diverge.eval[evall-1],diverge.eval[evall-2],diverge.eval[evall-3]))>0){not.stop <- T}}
    if(evall==6){if(sum(c(diverge.eval[evall],diverge.eval[evall-1],diverge.eval[evall-2],diverge.eval[evall-3],diverge.eval[evall-4]))>0){not.stop <- T}} # 13.7. neu ,diverge.eval[evall-4]
    if(evall>6){ if(sum(c(diverge.eval[evall],diverge.eval[evall-1],diverge.eval[evall-2],diverge.eval[evall-3],diverge.eval[evall-4],diverge.eval[evall-5]))>0){not.stop <- T}
        else{not.stop <- F}
    }
    #print(not.stop)
    ## Instabile abfedern: d.h. viele diverges; alternativ: NA zurueckgeben ?
    # if(iter.count>20)
    #  {
    #  if(sum(diverge.eval[!is.na(diverge.eval)])>7) # bei 8/20 diverges d.h.40%
    #    {
    #    warning(paste("Results instable. The best founded estimates are returned"))
    #    return(out.eval.full[[which.min(abs(fn.val.eval))]])
    #    break
    #    }
    #  }
    ## Abfedern wenn Plato d.h. ewig kaum Likelihood-Aenderung, aber nicht genug, um Algo abzubrechen -> kein so grosses Problem, solange nicht diverge, federt das max.iter ab
    ## if(evall>19){
    ##  if(sum(abs(d.fn.eval)) < rel.tol*evall/x)
    ##  {
    ##  return(out.eval.full[[which.min(abs(fn.val.eval))]])
    ##  break
    ##  }
    ##}
  } ### end while(d.fn > rel.tol...        ### i.e. end of EM
  # Problem, was, wenn in erstem Schritt starke Verschlechterung, da Postweights schon zu nahe am wahren Wert dran sind und dann nur noch divergier, init-fit wir derzeit nicht zurueckgegeben...
  #fn.val.test <- c(fn.val.start,fn.val.eval)
  #print(d.fn > rel.tol || iter.count < min.iter || not.stop)

  # #EM output
  print("converged")
  out <- list(out.eval=out.eval, weights=weights, postweight=postweight, pi=pi, logl=logl, updatedfit= updatedfit,
              updatedconcomitant=updatedconcomitant, loglik=loglik, comploglik=comploglik, loglikpen=loglikpen, comploglikpen=comploglikpen,
              loglikpen_weighted =loglikpen_weighted, comploglikpen_weighted =comploglikpen_weighted, penalty=penalty,
              model.coef.stand=model.coef.stand, model.coef=model.coef,
              concomitant.coef.stand=concomitant.coef.stand, concomitant.coef=concomitant.coef,
              iter.count = iter.count, cumulative.inner.iter.count = cumulative.inner.iter.count,
              loglik.eval=loglik.eval,fn.val.op=fn.val.op,fn.val.op.w=fn.val.op.w,comploglik.eval=comploglik.eval,
              comploglikpen.eval=comploglikpen.eval,comploglikpen.w.eval=comploglikpen.w.eval, diverge.full=diverge.full, em.diverge=em.diverge,
              model.coef.eval=model.coef.eval, model.coef.stand.eval=model.coef.stand.eval,
              concomitant.coef.eval=concomitant.coef.eval, concomitant.coef.stand.eval=concomitant.coef.stand.eval,
              postweight.eval=postweight.eval, pi.eval=pi.eval, fn.val=fn.val, fn.val.start=fn.val.start
              )
}

#' Internal function for fitting finite mixtures
#' @author Micha Schneider and Wolfgang Pößnecker
#' @param y a response vector or matrix whose length/nrow determines 'nobs', the number of observations
#' @param x a design matrix with 'nobs' rows to be used for the mixture components
#' @param z optional matrix of concomitant variables
#' @param x.long design matrix for specific survival models in long format
#' @param y.long response matrix for specific survival models in long format
#' @param u design matrix for the shape of the uncertainty component
#' @param xv design matrix for categoric specific cavariables
#' @param model kind of mixture model
#' @param M number of models/mixture components (usually 2)
#' @param model.args additional model arguments (a list of length M whose elements are themselves lists with additional/optional arguments for the M-step component functions)
#' @param GEM Type of EM-algorithm: \code{GEM=T} Generalized EM-algorithm is used
#' @param concomitant type of concomitant (do not change)
#' @param concomitant.args additional concomitant arguments
#' @param model.coef.init specific model coefficient initialization
#' @param concomitant.coef.init specific concomitant coefficient initialization
#' @param postweight.init specific postweight initialization
#' @param pi.init specific pi initialization
#' @param offset offset
#' @param weights a vector of length nobs assigning differing weights to different observationse (ussually not in use)
#' @param control an object of class "genmix.control" with informations such as \code{rel.tol} for relative tolerance or \code{max.iter} for maximum number of em iterations
#' @param checks internal checks
#' @param initialseed initial seed
#' @param cublass internal parameter
#' @param cub internal parameter
#' @param survival internal parameter
#' @param cure internal parameter
#' @param alpha alpha value to specify specific beta-binomial distributions
#' @param family2 family argument for specific model components
#' @param intercept.smooth smoothing the intercept in specific cure models
#' @param intercept.lambda tuning parameter for intercept smoothing
#' @param sp smoothing for specific model components (in combination with family2)
#' @param ti cure model only: vector with length of number of observations with the entries ti indicating the time an observation has been observed
#' @param event cure mode only: vector with length of number of observations with the entries zero or one indicating if an event as taken place
#' @param c.lambda penalization only: tuning parameter for concomitant
#' @param penindex penalization only: vector with numbers specifying for each column of x the corresponding penalty according to MRSP
#' @param grpindex group index indicating which matrix columns belong to the same variable
#' @param lambda penalization only: tuning parameter for model component
#' @param lambdaF Fusion tuning parameter
#' @param ishape1 value to specify specific beta-binomial distributions
#' @param ishape2 value to specify specific beta-binomial distributions
#' @param c.maxiter maximum number of iterations in the z/concomitant component
#' @param maxiter1  maximum number of iterations in the first model component
#' @param maxiter2  maximum number of iterations in the second model component
#' @param BS.seed Bootstrap seed
#' @param BS.seedindex vector of Bootstrap seeds
#' @param help Stabilization of estimation process by preventing weights to be too close to zero or one
#' @param trace additional fitting information
#' @param fn.val.option change which likelihood should be used to be optimized (usually do not change)
#' @param ... further arguments
genmix <- cmpfun(function(y, x = NULL, z = NULL, x.long=NULL,y.long=NULL,u=NULL, xv=NULL,
                          M = 2, model, model.args = NULL,GEM=F,
                   concomitant = "concomitant.default", concomitant.args = NULL,
                   model.coef.init = NULL, concomitant.coef.init = NULL,
                   postweight.init = NULL, pi.init = NULL, offset = NULL,
                   weights = NULL, control = genmix.control(),
                   checks = checks.default, initialseed = sample(1000, size=1),
                   cublass=F,cub=F,survival=F,cure=F,alpha=NULL,family2=NA,intercept.smooth=NULL,intercept.lambda=NULL, sp=NULL,ti=NULL,event=NULL,
                   c.lambda=NULL, penindex=NULL, grpindex=NULL, lambda=123456789,
                   lambdaF=123456789, ishape1=1, ishape2=NULL, c.maxiter=NULL,
                   maxiter1=NULL,maxiter2=NULL, BS.seed=NULL,BS.seedindex=NULL,help=F,trace=F,
                   fn.val.option="NA",...)
                   #model.control=MRSP.control(),...)
  {# neu family2 da sonst probleme mit anderen/nicht ?bergebenen families
  for(m in seq(M)) { # model.args-Argumente ?berschreiben einzelnen Aufruf
    if (!is.null(model.args[[m]]$penindex)) {penindex <- model.args[[m]]$penindex}
    if (!is.null(model.args[[m]]$grpindex)) {grpindex <- model.args[[m]]$grpindex}
    if (!is.null(model.args[[m]]$lambda)) {lambda <- model.args[[m]]$lambda}
    if (!is.null(model.args[[m]]$lambdaF)) {lambdaF <- model.args[[m]]$lambdaF}
  }

  mycall <- match.call()
 if(control@expandcall){
  excl <- c(1, which(names(mycall) %in% c("y", "x", "z","u")))
  mycall[-excl] <- mget(names(mycall[-excl]), envir = as.environment(-1))
 }

 ## extract control information:
 #max.iter <- control@max.iter
 #min.iter <- control@min.iter
 #rel.tol <- control@rel.tol
 # M.max <- control@M.max  ## not needed here/yet.
 trace <- control@trace
 pass.coefs <- control@pass.coefs

 ## create or initialize some objects
 loglik.eval <- c() # MS speichert entwichlung der loglikelihood in jedem EM-Schritt
 fn.val.op <- c()
 fn.val.op.w <- c()
 comploglik.eval <- c()
 comploglikpen.eval <- c()
 comploglikpen.w.eval <- c()

 hasX <- !is.null(x)
 hasXV <- !is.null(xv)
 hasZ <- !is.null(z)
 hasU <- !is.null(u)
 hasY <- !is.null(y)

 if(hasY){
 if(is.vector(y)) y <- as.matrix(y)
 nobs <- nrow(y)
 K <- ncol(y) # stimmt nicht immer; wird z.T. spaeter ueberschrieben
 if(is.null(colnames(y))) colnames(y) <- paste0("Category", seq(K))             ## note: the names must contain no spaces!
 y.names <- colnames(y)
 }

 if(missing(offset) | is.null(offset)) offset <- rep(0, nobs)
 if(missing(weights) | is.null(weights)) weights <- rep(1, nobs)
 #if(missing(c.weights) | is.null(c.weights)) c.weights <- rep(1, nobs)


 if(!hasX) {
   x <- matrix(1, nrow = nobs, ncol = 1)
   x.names <- 1 } # MS
 if(hasX){ # MS
  which.intercept <- which(apply(x, 2, function(u) diff(range(u)) < .Machine$double.eps ^ 0.5))
  if(length(which.intercept) > 1) stop("too many intercept columns supplied; or multicollinearity is present in the dataset x")
  has.intercept <- length(which.intercept == 1)
  if(has.intercept && which.intercept != 1) x[,c(1,which.intercept)] <- x[,c(which.intercept,1)]
  if(!has.intercept){
   x <- cbind(1, x)
   has.intercept <- T
  }
 if(is.null(colnames(x))) colnames(x) <- paste0("Var", seq(ncol(x)))            ## note: the names must contain no spaces!
 x.names <- colnames(x) # MS; siehe penmix problem mit categorical matrices!!!!
}

if(hasU){ # MS
  which.intercept <- which(apply(u, 2, function(u) diff(range(u)) < .Machine$double.eps ^ 0.5))
  if(length(which.intercept) > 1) stop("too many intercept columns supplied; or multicollinearity is present in the dataset u")
  has.intercept <- length(which.intercept == 1)
  if(has.intercept && which.intercept != 1) u[,c(1,which.intercept)] <- u[,c(which.intercept,1)]
  if(!has.intercept){
    u <- cbind(1, u)
    has.intercept <- T
  }
  if(is.null(colnames(u))) colnames(u) <- paste0("Var", seq(ncol(u)))            ## note: the names must contain no spaces!
  u.names <- colnames(u) # MS; siehe penmix problem mit categorical matrices!!!!
}
else
{u.names <- NULL}

 if(hasXV){ # MS XV is list; here test ob alles passt...
   #which.intercept <- which(apply(xv, 2, function(xv) diff(range(xv)) < .Machine$double.eps ^ 0.5))
   #if(length(which.intercept) > 1) stop("too many intercept columns supplied; or multicollinearity is present in the dataset xv")
   #has.intercept <- length(which.intercept == 1)
   #if(has.intercept && which.intercept != 1) u[,c(1,which.intercept)] <- u[,c(which.intercept,1)]
   #if(!has.intercept){
   #   u <- cbind(1, u)
   #   has.intercept <- T
   # }
   #if(is.null(colnames(xv[[1]]))) colnames(xv[[1]]) <- paste0("Var", seq(ncol(xv[[1]])))            ## note: the names must contain no spaces!
   #xv.names <- colnames(xv[[1]]) # MS; siehe penmix problem mit categorical matrices!!!!
   if(is.null(colnames(xv[[1]]))) xv.names <- paste0("Var", seq(ncol(xv[[1]])))
   }
 else
 {xv.names <- NULL}

  # Note: if x and z shall be the same, say an object called 'data.matrix', use
  # x = data.matrix, z = data.matrix in the call of genmix.
 if(hasZ){
  which.intercept <- which(apply(z, 2, function(u) diff(range(u)) < .Machine$double.eps ^ 0.5))
  if(length(which.intercept) > 1) stop("too many intercept columns supplied; or multicollinearity is present in the dataset y")
  has.intercept <- length(which.intercept == 1)
  if(has.intercept && which.intercept != 1) z[,c(1,which.intercept)] <- z[,c(which.intercept,1)]
  if(!has.intercept){
   z <- cbind(1, z)
   has.intercept <- T
  }
  if(is.null(colnames(z))) colnames(z) <- paste0("Var", seq(ncol(z)))           ## note: the names must contain no spaces!
  z.names <- colnames(z)
 }


 ## if model is nost supplied directly as a list, call the model constructor
 ## function, e.g. 'linregmix'
 if(!is.list(model)) model <- evalh(model)
                     # evalh is a helper function that evaluates a function in the
                     # place and environment where it is called, in this case in the
                     # environment of "genmix". the purpose is to make the code more
                     # readable. (I have written functions where, for example, the
                     # code for error checking took over 100 lines...)

 if(missing(model.args) | is.null(model.args)){
  model.args <- list(); length(model.args) <- M
 }

#### MS ####
for(m in seq(M)) {model.args[[m]]$family2 <- family2}            # -> glm, gam, (theoretisch vgam)
 for(m in seq(M)) {model.args[[m]]$intercept.smooth <- intercept.smooth}
 for(m in seq(M)) {model.args[[m]]$intercept.lambda <- intercept.lambda}
for(m in seq(M)) {model.args[[m]]$cublass <- cublass}

if (survival==T)
{
  #if(is.null(cens)) {cens <- matrix(1,nrow=nobs,ncol=1); warning("cens not specified. It is assumed that there are no censored observations")}
  #if(!all(x)==1){datshort <- cbind(y,cens,x);colnames(datshort) <- c(y.names,"cens",x.names)}
  #else {datshort <- cbind(y,cens);colnames(datshort) <- c(y.names,"cens")}
  #datalong <- data.long(data=datshort, time=y.names, cens="cens")
  #x.names <- names(datalong$x.long)

  #for(m in seq(M)) model.args[[m]]$obj <- datalong$obj               # obj/ID
  #for(m in seq(M)) model.args[[m]]$y.long <- y.long                   # all models
  #for(m in 2:M) model.args[[m]]$x.long <- x.long                      # only from 2nd position on
  #for(m in 2:M) model.args[[m]]$sp <- sp
  #for(m in seq(M)) model.args[[m]]$ti <- ti
  #for(m in 2:M) model.args[[m]]$first.ref <- first.ref

  #if(is.null(colnames(y.long))) colnames(y.long) <- paste0("Category", 1:ncol(y.long))             ## note: the names must contain no spaces!
  #else {y.names <- colnames(y.long)}
  #x.names <- colnames(x.long)
}
 if (sum(model=="gamcompsurv")>0) # survival mit gam
 {
   for(m in seq(M)) model.args[[m]]$y.long <- y.long                   # all models
   for(m in 2:M) model.args[[m]]$x.long <- x.long                      # only from 2nd position on

   if(is.null(colnames(y.long))) colnames(y.long) <- paste0("Category", 1:ncol(y.long))             ## note: the names must contain no spaces!
   else {y.names <- colnames(y.long)}
   x.names <- colnames(x.long)
 }

 if (sum(model=="seqlogitsurv")>0) # ymat for sequential-survival model 11.03.19
 {
   y.mrsp <- FALSE
   if(is.null(ti) && !hasY) {stop("Both y and ti are missing.")}
   if(hasY){ # falls y=ymat (ohne ti+event) #is.null(ti) &&
     ti1 <- apply(y,1,function(x){sum(!is.na(x))}) # 0,1,NA MRSP-matrix
     event1 <- apply(y,1,function(x){sum(x, na.rm=T)})
     if(all(ti1)==1 && sum(event1>1)>1){
        ti <- as.integer(y)                          # 10,5,... (wie cumulativ)
        if(is.null(event)){stop("You need to provide an 0-1-event-vector")}
     }
     else{
      ti <- ti1
      event <- event1
      y.mrsp <- TRUE
     }
   }

   if(y.mrsp==FALSE){
   #if(!hasY){ # falls kein y, sondern nur ti -> nobs; geht nicht mehr durch genmix2
   #   y<-ti
   #   if(is.vector(y)) {y <- as.matrix(y)}
   #   nobs <- nrow(y)
   # }
   ytimes <- ti
   censorind <- event   # 1 = beobachtet, 0 = zensiert
   ## test ob alle kategorien nicht-zensierte beboachtungen enthalten:
   #sonst keine events in jeder transition -> schaetzer infinit
   if(!all(sort(unique(ytimes*censorind))  ==  0:(max(ytimes)))){
     warning("There is not at least one event at each time point")
   }
   K <- max(ytimes)
   #print(censorind)
   ymat <- matrix(NA, nrow=nobs, ncol=K)
   for(i in seq(nrow(ymat))){
     yi <- ytimes[i]
     ymat[i, 1:(yi-1)] <- 0
     ymat[i, yi] <- censorind[i]*1                                                  ## = 0 falls zensiert!
   }

   if(is.null(colnames(ymat))) colnames(ymat) <- paste0("Category", seq(K))             ## note: the names must contain no spaces!
   y.names <- colnames(ymat)

   y <- ymat
   }
 }

 for(m in 2:M) model.args[[m]]$sp <- sp      # splines (v.a. survival, aber theoretisch immer)
 for(m in seq(M)) model.args[[m]]$ti <- ti   # fuer survival unverzichtbar!

# position 1: uncertainty/ hazard = 0/... # only 1rst position
# position 2 or later: model component -> [-1]
 for(m in seq(M)) model.args[[m]]$y.names <- y.names
 for(m in 1:M) model.args[[m]]$x.names <- x.names # achtung: neu: jetzt 1:M wegen beta-binom!
 for(m in 1:M) model.args[[m]]$alpha <- alpha
 for(m in 1:M) model.args[[m]]$BS.seedindex <- BS.seedindex
 for(m in seq(M)) model.args[[m]]$u<- u           # matrix f?r Unsicherheit/betabinomial
 for(m in seq(M)) model.args[[m]]$u.names <- u.names
 for(m in seq(M)) model.args[[m]]$xv <- xv   # 19
 for(m in seq(M)) model.args[[m]]$xv.names <- xv.names # 19

for(m in seq(M)) {model.args[[m]]$penindex <- penindex}
for(m in seq(M)) {model.args[[m]]$grpindex <- grpindex}
for(m in seq(M)) {model.args[[m]]$lambda <- lambda}
for(m in seq(M)) {model.args[[m]]$lambdaF <- lambdaF}

for(m in seq(M)) model.args[[m]]$ishape1 <- ishape1
for(m in seq(M)) model.args[[m]]$ishape2 <- ishape2
for(m in seq(M)) model.args[[m]]$c.maxiter <- c.maxiter
model.args[[1]]$maxiter1 <- maxiter1
model.args[[2]]$maxiter2 <- maxiter2

if (sum(model=="cumlogit")>0|sum(model=="vgamcumlogit")>0) # ymat for cumulative model
{
  #print(unique(y))
  if (max(y)>1)
  {
    if(min(y)==0 ){y <- y+1}
    # Vorbereitung der Daten f?r MRSP (so ?bergeben!): y not 1,2,3,.., but 1-0-Matrix with 1-1,2-1,3-1-colums,...
    ymat <- matrix(0, nrow=nrow(y), ncol = (max(y)-1)) # k = 4, q = 3 -> 3 ?berg?nge zwischen Kategorien
    for(i in 1:nrow(y)){
      for(j in 1:(max(y)-1)){
        if(y[i] == j) {ymat[i,j] <- 1}
      }
    }
  if (length(unique(y))!=(ncol(ymat)+1)){stop("y data not appropriate (internal: ymat has wrong dimensions)")}
  #print(head(ymat))
  }
 #y <- ymat
 for(m in 1:M) {model.args[[m]]$ymat <- ymat}
}


if(hasZ){
  if(missing(concomitant.args) | is.null(concomitant.args)) concomitant.args <- list()
  concomitant.args$z.names <- z.names
  if (!is.null(c.lambda)) {concomitant.args$lambda <- c.lambda}
 }

 if(missing(model.coef.init) | is.null(model.coef.init)){
  model.coef <- list(); length(model.coef) <- M
  #for(m in seq_len(M)){
  # model.coef[[m]] <- matrix(0, nrow = K, ncol = ncol(x))
  # model.coef[[m]][,1] <- sample(seq(from=-3, to=3, by=min(0.25, 6/(M-1))), size = K, replace = F)
  #}
 ## a little note: it usually is better to leave the coef initialization to the
 ## M-step fitting functions since they can use an initialization that takes the
 ## respective model class / data type into account. note that for this reason,
 ## all M-step drivers in 'genmix-models' must use 'NULL' as the default for
 ## their 'coef'-argument!
 }else{
  model.coef <- model.coef.init
 }

 if(missing(concomitant.coef.init) | is.null(concomitant.coef.init)){
  if(!hasZ){
   concomitant.coef <- NULL
  }else{
   concomitant.coef <- matrix(0, nrow = M, ncol = ncol(z))
   concomitant.intercepts <- rep(1/M, M) + rnorm(M, sd = 1e-2)
   concomitant.coef[,1] <- concomitant.intercepts / sum(concomitant.intercepts)
  }
 }else{
  concomitant.coef <- concomitant.coef.init
 }


 if(!hasZ){
  if(missing(pi.init) | is.null(pi.init)){
   pi <- rep(1/M, M)
  }else{
   pi <- pi.init
  }
  pi <- matrix(pi, nrow = nobs, ncol = M, byrow = T)
 }else{
   if(is.matrix(pi.init))
    {if(nrow(pi.init) == nobs & ncol(pi.init)==M & all(is.na(pi.init)==FALSE))
      {pi <- pi.init} # NEU 6.7.2017
   }
   else{# alte version
  if(is.list(concomitant.coef)){
   if(length(concomitant.coef) > 1){
    stop("concomitant.coef was supplied as a list of wrong length")
   }else{
    concomitant.coef <- concomitant.coef[[1]]
   }
  }
  c.eta <- tcrossprod(z, concomitant.coef) # eta for the concomitant model
  pi <- mn.invlink(c.eta)
 }}

set.seed(initialseed)
if(missing(postweight.init) | is.null(postweight.init)){
  postweight <- postweight.initialization(y, M)
}else{
  postweight <- postweight.init
}

 ## perform checks (for checks.default, see "genmix-helpers", line 94ff):
 evalh(checks)
 ##### prepare for EM:
 ## first compute the model resulting from the initial coefs/objects:
 initialfit <- list(); length(initialfit) <- M
 for(m in seq_len(M)){
  paralist <- list(y=y, x=x, M=M, coef=NULL, postweight=c(postweight[,m]),
                   offset=offset, weights=weights)
  if(pass.coefs) paralist$coef <- model.coef[[m]]
  #print(model[[m]])
  initialfit[[m]] <- eval(as.call(c(as.symbol(model[[m]]), paralist, model.args[[m]])))
  #print(m)
 }

 if(hasZ){
  paralist <- list(y=postweight, z=z, M=M, coef=NULL, weights=weights)
  if(pass.coefs) paralist$coef <- concomitant.coef
  initialconcomitant <- eval(as.call(c(as.symbol(concomitant), paralist , concomitant.args)))
 }else{
  initialconcomitant <- NULL
 }

 ## compute the negative mixture loglikelihood based on the initial models
 logl <- do.call("cbind", lextract(initialfit, "logl"))
 ## if penalized models are used, getpenalty extracts the respective penalties from the models.
 ## if no penalties are used, getpenalty returns 0.
 ## note that all driver functions for penalized models must return the value of
 ## the penalty term via an argument called 'penalty'!

 loglik.eval[1] <- mixloglik(logl = logl, pi = pi, weights = weights)
 fn.val.op[1] <- mixloglik(logl = logl, pi = pi, weights = weights) -
   getpenalty(fit = initialfit, pi = matrix(1, nrow=nobs, ncol=M), L = M) -
   ifelse(hasZ, getpenalty(fit = initialconcomitant, pi = matrix(1, nrow=nobs, ncol=M), L = 1),  0)

 fn.val.op.w[1] <- mixloglik(logl = logl, pi = pi, weights = weights) -
                        getpenalty(fit = initialfit, pi = pi, L = M) -
                        ifelse(hasZ, getpenalty(fit = initialconcomitant, pi = matrix(1, nrow=nobs, ncol=M), L = 1),  0)

 comploglik.eval[1] <- sum(weights * (postweight * (log(pi) + logl)))
 comploglikpen.eval[1] <- sum(weights * (postweight * log(pi) + postweight * logl
                                                    - getpenalty(fit = initialfit, pi = matrix(1, nrow=nobs, ncol=M), L = M)
                                                    - ifelse(hasZ, getpenalty(fit = initialconcomitant, pi = matrix(1, nrow=nobs, ncol=M), L = 1),  0)))
 comploglikpen.w.eval[1] <- sum(weights * (postweight * log(pi) + postweight * logl
                                         - getpenalty(fit = initialfit, pi = postweight, L = M)
                                         - ifelse(hasZ, getpenalty(fit = initialconcomitant, pi = matrix(1, nrow=nobs, ncol=M), L = 1),  0)))

 if(fn.val.option=="complete")#fn.val muss immer positiv sein -> d.h. kleiner werden
 {
   fn.val <- fn.val.old <- -comploglikpen.eval[1]
 }
 else {fn.val <- fn.val.old <- -fn.val.op[1]}

 #fn.val <- fn.val.old <- -mixloglik(logl = logl, pi = pi, weights = weights) +
 #                        getpenalty(fit = initialfit, pi = pi, L = M) +
 #                        ifelse(hasZ, getpenalty(fit = initialconcomitant, pi = matrix(1, nrow=nobs, ncol=M), L = 1),  0)
 #fn.val <- fn.val.old <- -mixloglik(logl = logl, pi = pi, weights = weights)
 #print(paste("starting loglikpen: ",fn.val.op, sep="")) # MS
 #print(paste("starting loglikpen.w: ",fn.val.op.w, sep="")) # MS
 #print(paste("starting loglik: ",loglik.eval[1], sep="")) # MS <- hiernach Abbruchkriterium!!!
 #print(paste("starting comploglikpen: ",comploglikpen.eval, sep=""))
 #print(paste("starting comploglikpen.w: ",comploglikpen.w.eval, sep=""))
 #print(paste("starting comploglik: ",comploglik.eval, sep="")) # MS}

 #loglik.eval[1] <- -fn.val
 ## more stuff for EM
 #d.fn <- 1
 #iter.count <- 0
 #cumulative.inner.iter.count <- 0
# hier em oder schon vor initialisierung?
### warnung: die cumulative.inner.iter.count-geschichte klappt nur f?r cublasso.
em_fit <- em(y=y, x=x, z=z, hasZ=hasZ, pass.coefs=pass.coefs, nobs=nobs,trace=trace,
               M=M, model=model, model.args=model.args,
               concomitant=concomitant, concomitant.args=concomitant.args,
               offset=offset, weights=weights, cublass=cublass,
               postweight=postweight, model.coef=model.coef, concomitant.coef=concomitant.coef,
               max.iter = control@max.iter, min.iter = control@min.iter, rel.tol = control@rel.tol,
               logl=logl, fn.val=fn.val, loglik.eval=loglik.eval, fn.val.op=fn.val.op, fn.val.op.w=fn.val.op.w,
               comploglik.eval=comploglik.eval, comploglikpen.eval=comploglikpen.eval, comploglikpen.w.eval=comploglikpen.w.eval,
               d.fn=1, iter.count = 0, cumulative.inner.iter.count = 0, help=help, fn.val.option=fn.val.option)

#print(em_fit$em.diverge)
#if(em_fit$em.diverge>0){warning(paste("The mixture loglikelihood hasn't converged monotonically in all iterations"))} # neu 13.05.2019 anstatt einzelne warnings

 ## prepare for the output:
 #comploglik <- sum(em_fit$weights * (em_fit$postweight * (log(em_fit$pi) + em_fit$logl)))   # complete data loglikohne penalty MS NEU
 #comploglik <- sum(em_fit$weights * (em_fit$postweight * (log(em_fit$pi) + em_fit$logl)))   # complete data loglikohne penalty MS NEU
 classifyloglik <- sum(em_fit$weights * (log(em_fit$pi) + em_fit$logl)[cbind(seq_len(nobs), max.col(em_fit$postweight))])  # classification loglik
 df <- df.model <- sum(Reduce("c", lextract(em_fit$updatedfit, "df")))   # degrees of freedom, summed up over components
       # sidenote: the last line implicitly forces all model driver functions to return a slot 'df',
       # even if the actual fitting function does not provide it for whatever reason!
if(hasZ){
  df.concomitant <- em_fit$updatedconcomitant$df
  df <- df + df.concomitant
 }else{
  df.concomitant <- M - 1   # M pi values, - 1 because the pi's have to sum to 1
  df <- df + df.concomitant
 }
#print(df)
 AIC <- -2 * em_fit$loglik + 2 * df
 BIC <- -2 * em_fit$loglik + log(sum(em_fit$weights)) * df         # note: if weights unequal to 1 are used, the effective
 ICL <- -2 * em_fit$classifyloglik + log(sum(em_fit$weights)) * df # number of observations is sum(weights).
                                                     # if weights is left unspecified, this corresponds to nobs.

 out <- list(model = em_fit$updatedfit,  # note: other model output can be stored and accessed here
             model.coef = em_fit$model.coef,
             model.coef.stand = em_fit$model.coef.stand, # MS 28.10.2014
             concomitant = em_fit$updatedconcomitant,
             concomitant.coef = em_fit$concomitant.coef,
             concomitant.coef.stand = em_fit$concomitant.coef.stand,  # MS 28.10.2014
             postweight = em_fit$postweight,
             pi = em_fit$pi,
             M = M,
             loglik = em_fit$loglik,
             loglikpen=em_fit$loglikpen,
             comploglikpen=em_fit$comploglikpen,
             loglikpen_weighted=em_fit$loglikpen_weighted,
             comploglikpen_weighted=em_fit$comploglikpen_weighted,
             comploglik = em_fit$comploglik,
             classifyloglik = classifyloglik,
             penalty = em_fit$penalty,
             df = df,
             df.model = df.model,
             df.concomitant = df.concomitant,
             AIC = AIC,
             BIC = BIC,
             ICL = ICL,
             call = mycall,
             weights = em_fit$weights,
             control = control,
             iter.count = em_fit$iter.count,
             cumulative.inner.iter.count = em_fit$cumulative.inner.iter.count,
             diverge=em_fit$diverge,
             BS.seed=BS.seed,
             BS.seedindex=BS.seedindex,
             model.coef.eval=em_fit$model.coef.eval,
             model.coef.stand.eval=em_fit$model.coef.stand.eval,
             concomitant.coef.eval=em_fit$concomitant.coef.eval,
             concomitant.coef.stand.eval=em_fit$concomitant.coef.stand.eval,
             postweight.eval=em_fit$postweight.eval, pi.eval=em_fit$pi.eval,
             loglik.eval=em_fit$loglik.eval,
             fn.val.op=em_fit$fn.val.op,
             fn.val.op.w=em_fit$fn.val.op.w,
             comploglik.eval=em_fit$comploglik.eval,
             comploglikpen.eval=em_fit$comploglikpen.eval,
             comploglikpen.w.eval=em_fit$comploglikpen.w.eval,
             diverge.full=em_fit$diverge.full,
             em.diverge=em_fit$em.diverge,
             fn.val=em_fit$fn.val,
             fn.val.start=em_fit$fn.val.start
             )                           ### warnung: die cumulative.inner.iter.count-geschichte klappt nur f?r cublasso.

 return(out)
})
