################################################################################
#####    Helper functions for genmix; part of DiscMix                      #####
################################################################################
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker


## Internal function for computing the memory usage
## @author Wolfgang Pößnecker
## @param sort internal parameter
## @param decreasing internal parameter
## @param limit internal parameter
## @param envir internal parameter
#showMemoryUse <- function(sort="size", decreasing=FALSE, limit, envir) {
#  if(missing(envir)) envir <- parent.frame()
#  objectList <- ls(envir)
#  oneKB <- 1024
#  oneMB <- 1048576
#  oneGB <- 1073741824
#  memoryUse <- sapply(objectList, function(x) as.numeric(object.size(eval(parse(text=x)))))
#  memListing <- sapply(memoryUse, function(size) {
#        if (size >= oneGB) return(paste(round(size/oneGB,2), "GB"))
#        else if (size >= oneMB) return(paste(round(size/oneMB,2), "MB"))
#        else if (size >= oneKB) return(paste(round(size/oneKB,2), "kB"))
#        else return(paste(size, "bytes"))
#      })
#  memListing <- data.frame(objectName=names(memListing),memorySize=memListing,row.names=NULL)
#  if (sort=="alphabetical") memListing <- memListing[order(memListing$objectName,decreasing=decreasing),]
#  else memListing <- memListing[order(memoryUse,decreasing=decreasing),] #will run if sort not specified or "size"
#  if(!missing(limit)) memListing <- memListing[1:limit,]
#  print(memListing, row.names=FALSE)
#  return(invisible(memListing))
#}


#' Internal function for a vectorized version of all.equal
#' @author Wolfgang Pößnecker
#' @param x x
#' @param y y
#' @param tolerance tolerance between x and y
v.allequal <- function(x, y, tolerance = .Machine$double.eps ^ 0.5){
 if(length(x) != length(y) && !(length(x) == 1 | length(y) == 1))
  stop("length of x and y in v.allequal do not match")
 x > y - tolerance & x < y + tolerance
}


#' Internal response function for multinomial logit models
#' @author Wolfgang Pößnecker
#' @param eta internal parameter
mn.invlink <- multinomlogit()@invlink


#' Internal function for evaluating rowsums of logarithms
#' @author Wolfgang Pößnecker
#' @param m matrix m of "log'd" values
## in a numerically more stable way
## Input: matrix m of "log'd" values
log_row_sums <- function(m) {
  M <- maxRow(m)                 # maxRow is a function provided by package MLSP
  M + log(rowSums(exp(m - M)))
}

#' Internal function for computation of log(1 + exp(x))
#' @author Wolfgang Pößnecker
#' @param x data
## a function for a numerically stable computation of log(1 + exp(x)), according
## to Maechler (2012)
log1pexp <- cmpfun(function(x){
 ind1 <- which(x <= 18)
 ind2 <- which(x > 18 && x <= 33.3)
 #ind3 <- which(x > 33.3)
 out <- x
 out[ind1] <- log1p(exp(x[ind1]))
 out[ind2] <- x[ind2] + exp(-x[ind2])
 #out[ind3] <- x[ind3]
 out
})

#' Internal function for evaluate a function
#' @author Wolfgang Pößnecker
#' @param fun function
#' @param funargs function arguments
## evalh: evaluate a function "fun" in the environment where evalh is used, with the
## value of the function arguments as found in the current environment (if available)
evalh <- function(fun, funargs = NULL){
 if(is.character(fun)) fun <- get(fun)
 if(!is.function(fun)) stop("fun is not a function or a valid function name in evalh")
 environment(fun) <- parent.frame()
 if(is.null(formals(fun))){
  fun()
 }else{
  if(is.null(funargs)) funargs <- mget(names(formals(fun)), envir = parent.frame())
  eval(as.call(c(fun, funargs)))
 }
}

#' Internal function for initializing the postweights
#' @author Micha Schneider and Wolfgang Pößnecker
#' @param y response
#' @param M number of mixture components
#' @param pwi value of weight
#' @param seed seed
#' @param sample Should a sample of weights be drawn?
postweight.initialization <- cmpfun(function(y, M, pwi=0.9,seed=NULL, sample=TRUE){
 if(M==2){postw <- matrix(1-pwi, nrow = nrow(y), ncol = M)}
 else {postw <- matrix(0.1, nrow = nrow(y), ncol = M)}
 if(!is.null(seed)){set.seed(seed)}
 if (sample==T){
 for(i in 1:nrow(y)){
  m <- sample(M, size = 1)
  postw[i, m] <- pwi
  }
 }
 if(sample==F && M==2){
   for(i in 1:nrow(y)){
     postw[i, 2] <- pwi
   }
 }
 postw <- postw/rowSums(postw)
 return(postw)
})


#' Internal function for performing checks
#' @author Wolfgang Pößnecker and Micha Schneider
#' @param M number of mixture components
#' @param model kind of mixture model
#' @param model.args additional model arguments
#' @param model.coef model coefficients
#' @param y response
#' @param pi mixture weights (a priori)
#' @param nobs number of observations
#' @param x x covariates for model component
#' @param postweight postweight
## default function for performing checks:
 # you should extend this function to check whatever is necessary for the models
 # you want to fit. #M,model,model.args,model.coef,y,pi,nobs, M,x,postweight
checks.default <- function(M,model,model.args,model.coef,y,pi,nobs,x,postweight){
 if(M < 2)
   stop("M must be 2 or greater")

 if(length(model) != M)
   stop("number of specified component models doesn't match M")

 if(length(model.args) > 0 && length(model.args) != length(model))
   stop("model and model.args don't match")

 if(length(model.coef) != length(model))
   stop("model and model.coef don't match")

 if(!is.matrix(y))
   stop("y must be passed as a matrix (possibly with only one column)")

 if(!all.equal(dim(pi), c(nobs, M)))
   stop("pi must be a matrix of dim nobs x M (or be left unspecified)")

 if(length(which(apply(x, 2, function(u) diff(range(u)) < .Machine$double.eps ^ 0.5))) != 1)         ### changed by WP on 3-3-14
   stop("if x is specified, its first column must contain only 1's. (intercept column)")

 if(nrow(postweight) != nobs || ncol(postweight) != M)
   stop("postweight must be a matrix of dim nobs x M")

 # add additional, customized checks here!
 #...
}

#' Internal function for computing the mixture loglikelihood
#' @author Wolfgang Pößnecker
#' @param logl matrix of loglik values for the mixture components
#' @param pi matrix of mixture weights
#' @param weights weight vector (optional)
#' @param ... further arguments
## a function for computing the mixture loglikelihood given a matrix logl of
## loglik values for the mixture components and a matrix pi for the priors and
## an optional weight vector. logl and pi must have dim nobs x M
mixloglik <- function(logl, pi, weights, ...){
 pi[which(pi <= 1e-6)] <- 1e-8
 mixlogl <- logl + log(pi)
 mixlogl <- weights * mixlogl
 sum(log_row_sums(mixlogl))
}

#' Internal function for extracting an element from a list
#' @author Wolfgang Pößnecker
#' @param object Object
#' @param name quoted name of the element to extract
#' @param simplify simplify?
#' @param recursive recursive?
## a function to extract an element from a list. name must be the quoted (!)
## name of the element to extract.
lextract <- function(object, name, simplify=F, recursive=F){
 out <- lapply(object, "[[", as.character(name))
 if(simplify) out <- unlist(out, recursive=recursive)
 out
}


#' Internal function for updating the posterior weights
#' @author Wolfgang Pößnecker
#' @param logl nobs x M matrix containing the loglikelihood values for each observation and each mixture component
#' @param pi nobs x M matrix containing the mixture weights (a priori)
#' @import methods
#'
## a function to update the posterior weights, given two objects "logl" and "pi",
## with "logl" being an nobs x M matrix containing the loglikelihood values for
## each observation and each mixture component; "pi" being an nobs x M matrix
## containing the prior probabilities.
update.postweight <- function(logl, pi){
 pi[which(pi <= 1e-6)] <- 1e-8
 pws <- logl + log(pi)
 pws <- exp(pws - log_row_sums(pws))
 pws
}

#' Internal function  that computes penalty terms
#' @author Micha Schneider and Wolfgang Pößnecker
#' @param fit list of model fits
#' @param pi nobs x M matrix containing the mixture weights (a priori)
#' @param L length of fit
#' @param ... further arguments
## a function that computes penalty terms given a list of model fits, called
## "fit" and an nobs x M matrix "pi" that contains the a priori probabilities.
## note that all driver functions for penalized models must return the value of
## the penalty term via an argument called 'penalty'!
getpenalty <- cmpfun(function(fit, pi, L, ...){                                 ## L is the length of fit; this is M for the model components and 1 for concomitant
 if(!is.list(fit)) stop("argument 'fit' must be a list in function 'getpenalty'")
 if(!is.matrix(pi)) stop("argument 'pi' must be a matrix in function 'getpenalty'")

 if(L > 1 && ncol(pi) != L) stop("argument 'pi' in function 'getpenalty' has wrong dimension")
 pi <- colMeans(pi)
 penalty <- 0

 if(L > 1){                                                                     ## this is for the mixture components
  for(m in seq_len(L)){
   if(exists("fit[[m]]$penalty")) penalty <- penalty + pi[m]*fit[[m]]$penalty
   if(exists("fit[[m]]@penalty")) penalty <- penalty + pi[m]*fit[[m]]@penalty
  }
 }else if(L == 1){                                                              ## this is for the concomitant model
  if(exists("fit$penalty")) penalty <- penalty + fit$penalty
  if(exists("fit@penalty")) penalty <- penalty + fit@penalty
 }

 penalty
})

