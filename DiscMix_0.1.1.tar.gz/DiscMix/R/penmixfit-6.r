################################################################################
#####    Penalization for mixture models, part of DiscMix                  #####
################################################################################
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker

## a convenience function that facilitates the fitting of CUB models with lasso
## penalties using the packages MLSP and genmix.
## -------------------------------------------------------------------------- ##
## Mandatory Arguments:
   ## y: the response. either a vector that consists of integers from 1 to k,
   ##    where k = max(y), or a character string giving the name of the response
   ##    variable to be found in 'data'.
   ## x: a RHS formula or the design matrix for the mixture components/binomial
   ##    models.
   ## data: a data frame containing the variables specified in y, x and possibly
   ##    z. factor variables with more than one dummy will automatically get
   ##    penalized jointly if you leave the construction of argument grpindex to
   ##    cublasso
   ## lambda: the tuning parameter for the lasso penalty that is applied to
   ##    regression coefficients within the mixture components. it must be a
   ##    single numeric number.
## Optional Arguments:
   ## z: a RHS formula or the design matrix for the concomitant model, i.e. the
   ##    multinomial logit model that tries to explain the probabilities/mixing
   ##    proportions of the overall model with the variables found in z. if left
   ##    unspecified, constant mixing probabilities are used.
   ## c.lambda: lambda for the lasso penalty on the regression parameters of the
   ##    concomitant model.
   ## M: number of mixture components to use. one component is always reserverd
   ##    for the discrete uniform distribution. additionally, M-1 binomial
   ##    models are used. if you leave this at its default of M=2, cublasso
   ##    uses CUB models in the traditional sense of Iannario & Piccolo.
   ## penalty: the default penalty to use for all true predictors (ie excluding
   ##    the intercept). if T, a lasso penalty is used. if F, no penalization
   ##    is used. if a numeric value other than 10 or 12, the corresponding
   ##    penalty is used. the number must be part of the current MLSP version!
   ##    do not use those other numbers for cub models, however, as the corres-
   ##    ponding penalties wouldnt make sense in a cub model.
   ## penindex: a vector of length ncol(x) that specifies how each predictor in
   ##    x shall be penalized. the number 10 means the corresponding predictor
   ##    is not penalized, 12 stands for a lasso penalty, 13 for ridge. do not
   ##    use 1, 11 or 14 with cublasso, the corresponding penalties wouldnt make
   ##    sense in the CUB context. if left unspecified, all true covariates are
   ##    subject to a lasso penalty and the intercept is left unpenalized.
   ## grpindex: a vector of length ncol(x) that contains integer numbers in
   ##    ascending order, starting from 1. columns of x that share the same
   ##    number in grpindex are treated as a group whose parameters are pena-
   ##    lized jointly via a group lasso penalty. it is best to leave this argu-
   ##    ment unspecified. for factor variables, the corresponding dummies
   ##    should always be treated as such a group. this is achieved by supplying
   ##    the factor variable as a column of type 'factor' within x. cublasso
   ##    then appropriately constructs dummy variables and adjust penindex and
   ##    grpindex.
   ## weights: a vector of observation weights.
   ## offset: an offset vector.
   ## lambdaR: the lambda for ridge penalties. use this is you want to use a mix
   ##    of lasso and ridge penalties and want them to use different tuning
   ##    parameters. if ridge is the only penalty you want to use, you can just
   ##    use the lambda argument instead.
   ## adaptive: should adaptive weights be used for the lasso penalties on the
   ##    component model parameters? set 'adaptive = "ML" ' if you want to use
   ##    it. for both conceptual and computational reasons, I discourage it at
   ##    the moment. never ever set 'adaptive=T', you wouldnt like the outcome.
   ## refit: if true, refitting is used. like adaptive weights, this can improve
   ##    the variable selection performed by the lasso, but it is very time con-
   ##    suming in the mixture context that we have here.
   ## penweights: an object that can be used to supply different, user-specified
   ##    weights for the penalty of different predictors by hand. ask Wolfgang
   ##    Poessnecker for details if you want to use this.
   ## lambdaF, fusion, mlfit: included for compatibility reasons, but you should
   ##    never use them.
   ## concomitant: name of a genmix driver function for the concomitant model.
   ##    do not change this.
   ## c.penindex, c.grpindex, c.offset and so on: same arguments as above, but
   ##    this time referring to the concomitant model and thus the z variables.
   ## model.coef.init, concomitant.coef.init: you can start cublasso at specific
   ##    values of the model.coef and concomitant.coef using these arguments.
   ## postweight.init, pi.init: two matrices of dimension length(y) x M that
   ##    contain initial values of the prior and posterior weights of the model.
   ## standardize: if true, all predictor variables are centered and standard-
   ##    ized by cublasso before the penalized fit is computed internally via
   ##    MLSP. it is strongly recommended to leave this standardization on.
   ## control: the control object for the mixture model/the EM algorithm facili-
   ##    tated by genmix.
   ## model.control, concomitant.control: control objects of class MLSP.control
   ##    for the component and concomitant models, respectively. DO NOT CHANGE!
   ## checks.default: a check function for genmix. you might want to include
   ##    some additional checks into it.
   ## initialseed: used as a little trick to make results independent from
   ##    random initializations across different versions of cublasso. see the
   ##    comments above 'genmix' for details.
   ## model: Mixture models as uniform.seqlogit.mix, uniform.cumlogit.mix, uniform.cubbinomial,
## -------------------------------------------------------------------------- ##
## Achtung: derzeit 10 + 16 fuer Intercept -> "nicht-penalisiert" (falls 16 mal bei Kovariablen muss neu ueberlegt werden!)
# x.long, y.long, alpha=NULL,family2=NA
penmixfit <- cmpfun(function(y, x, z = NULL, x.long=NULL,y.long=NULL,u=NULL, xv=NULL, GEM=F,
                          data, M = 2, penalty = T, penindex = NULL, grpindex = NULL,                          ### EDITME
                            weights = rep(1, nrow(x)), offset = NULL,#rep(1, nrow(x)); rep(0, nrow(x))
                            lambda, lambdaR = lambda, lambdaF = lambda,
                            adaptive = F, refit = F, threshold = F, fusion = "adja",          ## if you want to use adaptive weights, I strongly recommend 'adaptive = "ML"' instead of 'adaptive = T'
                            penweights = NULL, mlfit = NULL,                             # however, I strongly recommend not to use adaptive weights in mixtures at all at the moment, due to
                            concomitant = "concomitant.default",                         # technical reasons.
                            c.penindex = NULL, c.grpindex = NULL,                        ## repeat the same arguments for the concomitant model
                            c.offset = offset, c.lambda = NULL, c.lambdaR = NULL,
                            c.lambdaF = NULL, c.adaptive = adaptive,
                            c.refit = refit, c.penweights = NULL, c.mlfit = NULL,
                            c.threshold = threshold, c.fusion = fusion,
                            model.coef.init = NULL, concomitant.coef.init = NULL,
                            postweight.init = NULL, pi.init = NULL,
                            standardize = T, control = genmix.control(),                ## control is the control object for genmix, aka the EM algorithm.
                            model.control = MRSP.control(standardize=F, expandcall=F,   ## modelcontrol is the control object for the calls to MLSP.
                            ridgestabil=T, keepdat=F), concomitant.control = NULL,      ## this is the control object for the concomitant model.
                            checks = checks.default,
                            initialseed = sample(1000,size=1),#model.initialseed=NULL,
                            model=uniform.cubbinomial,
                            cublass=T, cub=F, survival=F,
                            alpha=NULL,family2=NA,intercept.smooth=NULL,sp=NULL,ti=NULL,event=NULL, ishape1=1, ishape2=NULL,
                            c.maxiter=NULL, maxiter1=NULL,maxiter2=NULL, BS.seed=NULL,BS.seedindex=NULL,
                            method=1,pwi=c(0.7,0.9),nr.seeds=2,pwi.method="sample", seed.init=1000, #allgemeiner bzw. falls kein z: method=1,pwi=c(0.6,0.7,0.8,0.9),nr.seeds=2,pwi.method="both", seed.init=1000,
                            parallel=T, cores=length(pwi)*nr.seeds+length(postweight.init),small.output=T,dat=NULL,
                            help=F,trace=F,fn.val.option="NA", ...)# cub=F, survival=F, time=NULL, event=NULL,...)
                 ## checks must be adjusted to cublasso! # cores=detectCores()-1
{
 #if(is.na(lambdaF) | is.null(lambdaF) | missing(lambdaF)){lambdaF <- as.numeric(lambda)}
 #if(lambdaF==123456789){lambdaF <- as.numeric(lambda)}
 #if(is.null(lambdaF)){lambdaF <- 123456789} # genmix 123456789 - schlechte fits; lamdaF auch sonst "aktiv"?
 #save(lambda, lambdaF, file="Z:\\Forschung\\lambdas_tmp.RData")

 if(!is.null(postweight.init)){
  if(!is.list(postweight.init)){
    if(cores>(length(pwi)*nr.seeds+1)){
      cores <- length(pwi)*nr.seeds+1
      }
    }
   }
 mycall <- match.call()
 excl <- c(1, which(names(mycall) %in% c("y", "x", "z", "data")))
 mycall[-excl] <- mget(names(mycall[-excl]), envir = as.environment(-1))

 if(!is.list(model)) model.test <- evalh(model)
 if(sum(model.test=="seqlogitsurv")>0 & penindex[1]==40){#Test 19
   warning("Don't use penindex 40 for the intercept (penindex[1]) in the model with seqlogitsurv component; For unpenalized intercepts use 10 and for penalization of the difference of the intercepts use 16")}
 #if(missing(lambda) && penalty == F) lambda <- 123456789
 #if(missing(c.lambda) && penalty == F) c.lambda <- 123456789

 ## in the following, create the response vector y, a design matrix called x and,
 ## possibly, a design matrix called z from data.
 #### for(j in seq_along(ncol(data))){ if(is.factor(data[,j])){ levels(data[,j]) <- sapply(levels(data[,j]), function(u)paste0(".",u)) } }  # <- not needed anymore
 ## now get the model matrices
 if(is.character(y)) y <- get(y, data)
 if(!is.matrix(x) | is.numeric(x)){                                             # noteforself: it would be nicer to have something
  xform <- as.formula(x)
  # like "if(!is.formula | !is.character...", but
  #if(length(grep("[.]", all.vars(xform))) > 0)                                  # 'is.formula' does not exist in R.
  #  stop("variable names supplied to cublasso must not contain '.' (dots)!")
  #if (survival==T){ x <- model.matrix(xform, data=data.long)}
  x <- model.matrix(xform, data=data)
  #print(colnames(x))
  #print(head(x))
  #print(all.vars(xform))
 }else{stop("please supply 'x' as a formula or character string")}

 nobs <- nrow(x)

 hasXV <- !is.null(xv)
 if(hasXV){
 if(!is.matrix(xv) | is.numeric(xv)){                                             # noteforself: it would be nicer to have something
   xvform <- as.formula(xv)
   # like "if(!is.formula | !is.character...", but
   #if(length(grep("[.]", all.vars(xform))) > 0)                                  # 'is.formula' does not exist in R.
   #  stop("variable names supplied to cublasso must not contain '.' (dots)!")
   #if (survival==T){ x <- model.matrix(xform, data=data.long)}
   xv <- model.matrix(xvform, data=data)
   #print(colnames(x))
   #print(head(x))
   #print(all.vars(xform))
 }else{stop("please supply 'xv' as a formula or character string")}
 }

 hasZ <- !is.null(z)
 if(hasZ){
  if(!is.matrix(z) | is.numeric(z)){
   zform <- as.formula(z)
   #if(length(grep("[.]", all.vars(zform))) > 0)
   #  stop("variable names supplied to cublasso must not contain '.' (dots)!")
   z <- model.matrix(zform, data=data)
  }else{stop("please supply 'z' as a formula or character string")}
 }

 ## objects containing all the actual variables that are used:
 #xvars <- colnames(x)    # functioniert nicht mit kat. variablen
 xvars <- all.vars(xform) # MS funktioniert nicht mit . attr(terms(xform, rhs=1), "term.labels") from MRSP
 if(hasXV) {xvvars <- all.vars(xvform)}
 if(hasZ) {zvars <- all.vars(zform)}
 #if(hasZ) zvars <- colnames(z)

 ## check that formulas do not contain 'I(...)' since cublasso cant't handle it:
 for(j in seq_along(all.vars(xform))){
  if(any(sapply(strsplit(colnames(x), all.vars(xform)[j]), function(u) u[1] == "I(")))
    stop("cublasso currently does not support the use of variable transformations ",                                          ### EDITME
         "via 'I(...)'-constructs in the x-formula")
 }
 if(hasZ){
  for(j in seq_along(all.vars(zform))){
   if(any(sapply(strsplit(colnames(z), all.vars(zform)[j]), function(u) u[1] == "I(")))
     stop("cublasso currently does not support the use of variable transformations ",                                         ### EDITME
          "via 'I(...)'-constructs in the z-formula")
  }
 }

 ## handle concomitant.control object
 if(hasZ && concomitant == "concomitant.default"){
  if(is.null(concomitant.control) && class(model.control) == "MRSP.control"){
   concomitant.control <- model.control
  }else if(is.null(concomitant.control) && class(model.control) != "MRSP.control"){
   concomitant.control <- MRSP.control(standardize=F, expandcall=F)
  }
 }else if(hasZ && concomitant != "concomitant.default"){
  stop("at the moment, 'concomitant.default' is the only supported driver for ",
       "the concomitant model")
 }

 if(!is.numeric(y)) y <- as.numeric(y) # this makes y a numeric vector in case it was a supplied as a factor
 if(is.vector(y)) y <- as.matrix(y)    # for technical reasons, y must be a numeric matrix with one column
                                       # note that this whole concept only works if you have loaded the 'genmix'-files before.
                                       # (the line  " `[` <- function(..., drop=FALSE) base::`[`(...,drop=drop) "  is key!)
 #!!!!!!!
 #if(ncol(y) != 1) stop("y must be a one column matrix")} # MS raus wegen seq.mix; evtl. andere Abfrage einbauen

 ##### now comes the section in which we prepare the penindex, grpindex and data
 ##### for the model components, i.e. the 'x-part'.
 ## if the first column of x is no intercept column, add it
 which.intercept <- which(apply(x, 2, function(u) diff(range(u)) < .Machine$double.eps ^ 0.5))
 if(length(which.intercept) > 1) stop("too many intercept columns supplied; or multicollinearity is present in the dataset")
 has.intercept <- length(which.intercept == 1)
 if(has.intercept && which.intercept != 1) x[,c(1,which.intercept)] <- x[,c(which.intercept,1)]
 if(!has.intercept){
  x <- cbind(1, x)
  colnames(x)[1] <- "(Intercept)"
  has.intercept <- T
 }

 if(missing(lambda) | is.null(lambda) | lambda < 0)
   stop("you must use a nonnegative real number for argument 'lambda'")
 if(length(lambda) > 1)
   stop("currently, cublasso only supports one lambda at a time")                                                                        ### EDITME

 ## create the penindex object, which specifies how different predictors are
 ## penalized by MLSP.
 if(missing(penindex) | is.null(penindex)){
  penindex <- numeric()
  penindex[1] <- 10       # penindex = 10 means unpenalized
  for(j in seq(2,ncol(x))){
   if(penalty == T | penalty == 12){
    penindex[j] <- 12       # penindex = 12 means lasso penalty (ohne alles)
   }else if(penalty == F | penalty == 10){
    penindex[j] <- 10
   }else if(is.numeric(penalty)){
    penindex[j] <- penalty
   }else stop("penalty has an unusable value")
  }
 }
 ## check if the user-supplied penindex has the correct length
 #print(ncol(x))
 print("penindex:")
 print(penindex)
 print(ncol(x))
 #print(has.intercept)
 # Test: MS eigentlich sinnvoll, aeber penix hat unterschiedliche Dimensionen, wieso auch immer..
 # !!!!!!!!!!!
 #if(!(length(penindex[[1]]) == ncol(x)))# bei cumlogit # MS mit oder ohne [[1]] ??? 19.5.2017 mit [[1]]
 #  stop("the length of the specified penindex does not match the column number of the model matrix")
 #if(!(length(penindex) == ncol(x))){ # bei cubbinomial 20.06.2017 wieder zurueck
 #   print(length(penindex))
 #  print(ncol(x))
 #   stop("the length of the specified penindex does not match the column number of the model matrix")}
 ## now, create the grpindex object that specifies which predictors are penalized
 ## as a joint group. grpindex is a vector whose length is the same as the number
 ## of columns in the design matrix. it contains integer values in ascending order.
 ## each number denotes one parameter group that is penalized jointly. columns that
 ## share the same number form one group. an example:
 ## grpindex = c(1,2,3,3,4,4,4) means that variables 1 and 2 form their own group.
 ## variables 3 and 4  as well as variables 5, 6 and 7 form groups.
 ## the following code creates grpindex and adjusts x and penindex for factor or
 ## ordered predictors.
 if(missing(grpindex) | is.null(grpindex)){
  grpindex <- numeric()
  grpindex[1] <- 1       # the intercept should always form its own group
  #grpindex <- 1:(ncol(x)+1) # MS
  if(ncol(x) > 1){
   ## create a matrix that indicates which actual variables are involved in the
   ## creation of which columns of the design matrix x:
   varind <- matrix(F, nrow=length(xvars), ncol=ncol(x))
   for(i in seq(nrow(varind))){
    for(j in seq(ncol(varind))){
     ivarname <- xvars[i]
     ivar <- data[,which(colnames(data) == ivarname)]
     if(is.factor(ivar)){
      ilevels <- levels(ivar)[-1]
      for(l in seq(ilevels)){
       ilevelname <- paste0(ivarname, ilevels[l])
       if(ilevelname == colnames(x)[j] |
          length(grep(paste0(ilevelname, ":"), colnames(x)[j])) > 0 |
          length(grep(paste0(":", ilevelname), colnames(x)[j])) > 0)
       { varind[i,j] <- T }
      }
     }else{
      if(ivarname == colnames(x)[j] |
         length(grep(paste0(ivarname, ":"), colnames(x)[j])) > 0 |
         length(grep(paste0(":", ivarname), colnames(x)[j])) > 0)
      { varind[i,j] <- T }
     }
    }
   }

   for(j in seq(2,ncol(x))){
    if(!all(varind[,j] == varind[,j-1])){
     grpindex[j] <- grpindex[j-1] + 1
    }else{
     grpindex[j] <- grpindex[j-1]
     #if(j < ncol(x) & length(penindex) < ncol(x)){
     # penindex <- c(penindex[seq(1,j-1)], penindex[j-1], penindex[seq(j+1,ncol(x))])
     #else if(j == ncol(x) & length(penindex) < ncol(x)){
     # penindex <- c(penindex[seq(1,j-1)], penindex[j-1])
     #}
    }
   }
  }
 }

 ## for technical reasons, penindex, penweights and grpindex must be lists of length 1 in MLSP
 if(!is.list(penindex)) penindex <- list(penindex)
 if(!is.list(grpindex)) grpindex <- list(grpindex)
 if(!is.null(penweights) && !is.list(penweights)) penweights <- list(penweights)

 ######################################################################################
 ##### code for the standardization of x-predictors. do not change the following  #####
 ##### code section unless you REALLY know what you're doing, just copy-paste it! #####
 ######################################################################################
 pen.which.x <- which(! penindex[[1]] %in% c(10,16,40)) # new 13.05.2019
 notpen.which.x <- which(penindex[[1]] %in% c(10,16,40))
 grpindex.pen.x <- grpindex[[1]][pen.which.x]
 dict.pen.x <- sort(unique(grpindex.pen.x))
 wnobs <- sum(weights)      # typically, wnobs = nobs

 warnold <- options("warn")
 if(warnold < 2)
  options(warn = 1)
 if(!has.intercept & standardize){
  warning()
  cat("Standardization of predictors was requested while no x-intercept column could be found.",'\n',
  "For this case, backtransformation of coefficients to the original scale is not possible, so that output for the standardized predictors is returned instead. Be careful!")
 }
 if(warnold < 2)
  options(warn = as.numeric(warnold))

 ## orthonormalization of observations
 x.original <- x

 if(standardize){
  sweights <- weights / sum(weights)
  x.centered <- x
  mean.x <- apply(x[,,drop=F], 2, function(u) weighted.mean(u, weights))
  if(has.intercept){
   x.centered[,-1] <- sweep(x[,-1, drop=F], 2, mean.x[-1])
  }else{x.centered <- sweep(x[,, drop=F], 2, mean.x)}

  xw <- x.centered
  scale.pen.x <- list()
  scale.notpen.x <- NULL
  ## the following lines are necessary to handle the backtransformation of
  ## standardized coefficients during the ml fit via MLSP in the final step of
  ## this script.
  scale.notpen.ML <- NULL
  if(has.intercept){
   scale.notpen.ML <- sqrt(drop(sweights %*% (x.centered[, -1]^2)))
  }else{
   scale.notpen.ML <- sqrt(drop(sweights %*% (x.centered^2)))
  }

  ## if there are no unpenalized groups, skip the following:
  if(length(notpen.which.x) > 0){
   if(has.intercept){
    scale.notpen.x <- sqrt(drop(sweights %*% (x.centered[, notpen.which.x[-1]]^2)))
    xw[,notpen.which.x[-1]] <- scale(x.centered[, notpen.which.x[-1]], FALSE, scale.notpen.x)
   }else{
    scale.notpen.x <- sqrt(drop(sweights %*% (x.centered[, notpen.which.x]^2)))
    xw[,notpen.which.x] <- scale(x.centered[, notpen.which.x], FALSE, scale.notpen.x)
   }
  }
#print("scale.nonpen.x")
#print(scale.notpen.x)

  for(j in dict.pen.x){# hier intercept von +1 zu -1 !!!
   j.which <- which(grpindex[[1]] == j)
   decomp.x <- qr(sqrt(weights) * x.centered[, j.which])
   if(decomp.x$rank < length(j.which)) ## warn if block doesnt have full rank
     stop("Block belonging to columns ", paste(j.which), "does not have full rank!")
   scale.pen.x[[j]] <- qr.R(decomp.x) * 1/sqrt(wnobs)
   xw[, j.which] <- qr.Q(decomp.x) * sqrt(wnobs)
  }
  x <- xw
  x[,1] <- round(x[,1],14) #abs NEU MS TEST
 }

 ##### end of x-standardization #######################################################

 ## create a list of arguments to pass on to MLSP. (via genmix and the genmix
 ## driver function...)
 arglist <- list(adaptive = adaptive,
                 refit = refit,
                 mlfit = mlfit,
                 penweights = penweights,
                 threshold = threshold,
                 penindex = penindex,
                 grpindex = grpindex,
                 fusion = fusion,
                 lambda = lambda,
                 lambdar = lambdaR,            # noteforself: the 'r' in 'lambdaR' is not capitalized in MLSP, but it actually should be...
                 lambdaF = lambdaF,
                 control = model.control,
                 psi = 1)

 if(standardize){
  arglist$notpen.which.x <- notpen.which.x
  arglist$scale.notpen.x <- scale.notpen.x
  arglist$scale.notpen.ML <- scale.notpen.ML
  arglist$dict.pen.x <- dict.pen.x
  arglist$scale.pen.x <- scale.pen.x
  arglist$mean.x <- mean.x
  arglist$control@standardize <- F
  arglist$control@backtransf <- T
 }
 ##### ... end of the x-preperation part.                                       ############################################################
# if (survival==T) # long-Format with stand. matrices
#{
#  dat <- cbind(y,x[])
#  dat_long <- dat.long(data=dat,time=time,cens=event)
#  y_long <- dat_long[,"y"]
#  x_long <- dat_long[,-c("obj",time,event,"y")]
#}


 ##### now comes the section in which we prepare the c.penindex, c.grpindex and data
 ##### for the concomitant model, i.e. the 'z-part'.
 concomitant.args <- NULL
 if(hasZ){
  ## if the first column of z is no intercept column, add it
  c.which.intercept <- which(apply(z, 2, function(u) diff(range(u)) < .Machine$double.eps ^ 0.5))
  if(length(c.which.intercept) > 1) stop("too many intercept columns supplied; or multicollinearity is present in the dataset")
  c.has.intercept <- length(c.which.intercept == 1)
  if(c.has.intercept && c.which.intercept != 1) z[,c(1,c.which.intercept)] <- z[,c(c.which.intercept,1)]
  if(!c.has.intercept){
   z <- cbind(1, z)
   colnames(z)[1] <- "(Intercept)"
   c.has.intercept <- T
  }

  if(missing(c.lambda) | is.null(c.lambda)) c.lambda <- lambda
  if(missing(c.lambdaR) | is.null(c.lambdaR)) c.lambdaR <- lambdaR
  if(missing(c.lambdaF) | is.null(c.lambdaF)) c.lambdaF <- lambdaF

  if(c.lambda < 0)
    stop("you must use a nonnegative real number for argument 'c.lambda'")
  if(length(c.lambda) > 1)
    stop("currently, cublasso only supports one c.lambda at a time")                                                                    ### EDITME

  ## create the penindex object, which specifies how different predictors are
  ## penalized by MLSP.
  if(missing(c.penindex) | is.null(c.penindex)){
   c.penindex <- numeric()
   c.penindex[1] <- 10       # penindex = 10 means unpenalized
  for(j in seq(2,ncol(z))){
   if(penalty == T | penalty == 12){
    c.penindex[j] <- 12       # penindex = 12 means lasso penalty
   }else if(penalty == F | penalty == 10){
    c.penindex[j] <- 10
   }else if(is.numeric(penalty)){
    c.penindex[j] <- penalty
   }else stop("penalty has an unusable value")
  }
 }

  ## check if the user-supplied penindex has the correct length
  print("c.penindex:")
  print(c.penindex)
  print(ncol(z))
  # MS: eigentlich sinnvoll aber Dimensions-Probleme !!!!!!!!!!!!!!!!
  #if(!(length(c.penindex) == ncol(z)))
  #  stop("the length of the specified penindex does not match the column number of the z model matrix")

  ## now, create the grpindex object that specifies which predictors are penalized
  ## as a joint group. same prodecure as during the x-part.
  if(missing(c.grpindex) | is.null(c.grpindex)){
   c.grpindex <- numeric()
   c.grpindex[1] <- 1       # the intercept should always form its own group

   if(ncol(z) > 1){
    ## create a matrix that indicates which actual variables are involved in the
    ## creation of which columns of the design matrix z:
    varind <- matrix(F, nrow=length(zvars), ncol=ncol(z))
    for(i in seq(nrow(varind))){
     for(j in seq(ncol(varind))){
      ivarname <- zvars[i]
      ivar <- data[,which(colnames(data) == ivarname)]
      if(is.factor(ivar)){
       ilevels <- levels(ivar)[-1]
       for(l in seq(ilevels)){
        ilevelname <- paste0(ivarname, ilevels[l])
        if(ilevelname == colnames(z)[j] |
           length(grep(paste0(ilevelname, ":"), colnames(z)[j])) > 0 |
           length(grep(paste0(":", ilevelname), colnames(z)[j])) > 0)
        { varind[i,j] <- T }
       }
      }else{
       if(ivarname == colnames(z)[j] |
          length(grep(paste0(ivarname, ":"), colnames(z)[j])) > 0 |
          length(grep(paste0(":", ivarname), colnames(z)[j])) > 0)
       { varind[i,j] <- T }
      }
     }
    }

    for(j in seq(2,ncol(z))){
     if(!all(varind[,j] == varind[,j-1])){
      c.grpindex[j] <- c.grpindex[j-1] + 1
     }else{
      c.grpindex[j] <- c.grpindex[j-1]
      #if(j < ncol(z) & length(c.penindex) < ncol(z)){
      # c.penindex <- c(c.penindex[seq(1,j-1)], c.penindex[j-1], c.penindex[seq(j+1,ncol(z))])
      #else if(j == ncol(z) & length(c.penindex) < ncol(z)){
      # c.penindex <- c(c.penindex[seq(1,j-1)], c.penindex[j-1])
      #}
     }
    }
   }
  }

  ## for technical reasons, penindex, penweights and grpindex must be lists of length 1 in MLSP
  if(!is.list(c.penindex)) c.penindex <- list(c.penindex)
  if(!is.list(c.grpindex)) c.grpindex <- list(c.grpindex)
  if(!is.null(c.penweights) && !is.list(c.penweights)) c.penweights <- list(c.penweights)

  ######################################################################################
  ##### code for the standardization of z-predictors. do not change the following  #####
  ##### code section unless you REALLY know what you're doing, just copy-paste it! #####
  ######################################################################################
  pen.which.z <- which(c.penindex[[1]] != 10)
  notpen.which.z <- which(c.penindex[[1]] == 10)
  grpindex.pen.z <- c.grpindex[[1]][pen.which.z]
  dict.pen.z <- sort(unique(grpindex.pen.z))


  warnold <- options("warn")
  if(warnold < 2)
   options(warn = 1)
  if(!c.has.intercept & standardize){
   warning()
   cat("Standardization of predictors was requested while no z-intercept column could be found.",'\n',
   "For this case, backtransformation of coefficients to the original scale is not possible, so that output for the standardized predictors is returned instead. Be careful!")
  }
  if(warnold < 2)
   options(warn = as.numeric(warnold))

  ## orthonormalization of observations
  z.original <- z

  if(standardize){
   sweights <- weights / sum(weights)
   z.centered <- z
   mean.z <- apply(z[,,drop=F], 2, function(u) weighted.mean(u, weights))
   if(c.has.intercept){
    z.centered[,-1] <- sweep(z[,-1, drop=F], 2, mean.z[-1])
   }else{z.centered <- sweep(z[,, drop=F], 2, mean.z)}

   zw <- z.centered
   scale.pen.z <- list()
   scale.notpen.z <- NULL
   ## the following lines are necessary to handle the backtransformation of
   ## standardized coefficients during the ml fit via MLSP in the final step of
   ## this script.
   c.scale.notpen.ML <- NULL
   if(c.has.intercept){
    c.scale.notpen.ML <- sqrt(drop(sweights %*% (z.centered[, -1]^2)))
   }else{
    c.scale.notpen.ML <- sqrt(drop(sweights %*% (z.centered^2)))
   }

   ## if there are no unpenalized groups, skip the following:
   if(length(notpen.which.z) > 0){
    if(c.has.intercept){
     scale.notpen.z <- sqrt(drop(sweights %*% (z.centered[, notpen.which.z[-1]]^2)))
     zw[,notpen.which.z[-1]] <- scale(z.centered[, notpen.which.z[-1]], FALSE, scale.notpen.z)
    }else{
     scale.notpen.z <- sqrt(drop(sweights %*% (z.centered[, notpen.which.z]^2)))
     zw[,notpen.which.z] <- scale(z.centered[, notpen.which.z], FALSE, scale.notpen.z)
    }
   }

   #print("scale.nonpen.z")
   #print(scale.notpen.z)

   for(j in dict.pen.z){
    j.which <- which(c.grpindex[[1]] == j)
    decomp.z <- qr(sqrt(weights) * z.centered[, j.which])
    if(decomp.z$rank < length(j.which)) ## warn if block doesnt have full rank
      stop("Block belonging to columns ", paste(j.which), "does not have full rank!")
    scale.pen.z[[j]] <- qr.R(decomp.z) * 1/sqrt(wnobs)
    zw[, j.which] <- qr.Q(decomp.z) * sqrt(wnobs)
   }

   z <- zw
  }
  ##### end of z-standardization #######################################################

  ## create a list of arguments to pass on to MLSP. (via genmix and the genmix
  ## driver function...)
  concomitant.args <- list(adaptive = c.adaptive, # F
                           refit = c.refit, #F
                           mlfit = c.mlfit, #NULL
                           threshold = c.threshold, # F bzw 10-6 ?!
                           penindex = c.penindex,
                           grpindex = c.grpindex,
                           fusion = c.fusion,
                           lambda = c.lambda,
                           lambdar = c.lambdaR,            # noteforself: the 'r' in 'lambdaR' is not capitalized in MLSP, but it actually should be...
                           lambdaF = c.lambdaF,
                           control = concomitant.control,
                           psi = 1,
                           offset = c.offset,
                           constr = 1)

  if(standardize){
   concomitant.args$notpen.which.x <- notpen.which.z                            ## note that in MLSP, all the stuff is called 'x'
   concomitant.args$scale.notpen.x <- scale.notpen.z
   concomitant.args$scale.notpen.ML <- c.scale.notpen.ML
   concomitant.args$dict.pen.x <- dict.pen.z
   concomitant.args$scale.pen.x <- scale.pen.z
   concomitant.args$mean.x <- mean.z
   concomitant.args$control@standardize <- F
   concomitant.args$control@backtransf <- T
  }
 } ## end of the z-preparation part.                                            #######################################################################

 ## to save computing time, only compute the mlfit and the penweights in MLSP if
 ## they are required in every iteration. otherwise, fit the CUB model without them
 ## and compute the true DF in a postprocessing step. (at the end of this function...)
 if(adaptive == F){
  arglist$control@doMLfit <- F
  arglist$control@computeDF <- F
 }
 if(hasZ && c.adaptive == F){
  concomitant.args$control@doMLfit <- F
  concomitant.args$control@computeDF <- F
 }

 ## do not evaluate the call entries during the ordinary fitting to save memory
 arglist$control@expandcall <- F
 if(hasZ) concomitant.args$control@expandcall <- F

 ## create the model object for the call to genmix:
 #model <- list(); length(model) <- M
 #model[[1]] <- "discr.uniform"                                                                                                             ### EDITME
 #for(m in 2:M){                                                                                                                            ### EDITME
#  model[[m]] <- "cubbinomiallasso"      ## 'cubbinomiallasso' is the driver function that handles the calls from genmix to MLSP            ### EDITME
# }                                      ## for its definition, see file genmix-models, lines 379 ff.

 ## ... and now prepare the model.args object for the call to genmix:
 model.args <- list(); length(model.args) <- M
 for(m in 1:M){                                                                                                                            ### EDITME
  model.args[[m]] <- arglist
 }
###
#print(head(x))
#print(ncol(x))
#print(head(z))
#print(head(y))

 ## now the actual call to genmix:
#print("penmix!!!") # ok
#print(model.args[[2]]$penindex)
#print("penmix")
#print(arglist$penindex)
#print(concomitant.args$penindex)
#print(arglist$grpindex)
#print(concomitant.args$grpindex)
 # genmix2:
 # method=1,pwi=c(0.6,0.7,0.8,0.9),nr.seeds=2,pwi.method="both", seed.init=1000, parallel=T, cores=detectCores()-1,small.output=T,dat=NULL)
 #tmp!!!:
 #save(x,z,file="xztmp.Rdata")
 print("Initialisation")
 # Achtung: if standardize==T: x und z standardisiert; u nicht !!!! -> genmix:standardize=F (da hier schon standardisiert)
 set.seed(initialseed) # genmix2 aufrufen??!! MS
 suppressWarnings(
 fit <- discmix(y=y, x=x, z=z, x.long=x.long, y.long=y.long,u=u, xv=xv,
               M=M, model=model, model.args=model.args, GEM=GEM,
               concomitant=concomitant, concomitant.args=concomitant.args,
               model.coef.init=model.coef.init, concomitant.coef.init=concomitant.coef.init,
               postweight.init=postweight.init, pi.init=pi.init, offset=offset,
               weights=weights, control=control,control.init=genmix.control(), checks=checks,
               initialseed=initialseed, #model.initialseed = model.initialseed,
               cublass=cublass, cub=cub, alpha=alpha, family2=family2,intercept.smooth=intercept.smooth,
               sp=sp, ti=ti, event=event,
               c.lambda=c.lambda, penindex=penindex, grpindex=grpindex, lambda=lambda,
               maxiter1=maxiter1, maxiter2=maxiter2, BS.seed=BS.seed,BS.seedindex=BS.seedindex,
               method=method, pwi=pwi, nr.seeds=nr.seeds, pwi.method=pwi.method, seed.init=seed.init,
               parallel=parallel, cores=cores, small.output=small.output, dat=dat,
               help=help, trace=trace, fn.val.option=fn.val.option, survival=survival,
               ishape1=ishape1, ishape2=ishape2, c.maxiter=c.maxiter, # neu 23.1018
               ...)) # MS neu genmix5 -> cublass=T für inner.iter.count lambdaF=lambdaF ja oder nein? # suspressWarnings for df computation.... 13.05.2019

 iter.count <- fit$iter.count
 loglik.eval <- fit$loglik.eval
 fn.val.op <- fit$fn.val.op
 comploglik.eval <- fit$comploglik.eval
 comploglikpen.eval <- fit$comploglikpen.eval
 cumulative.inner.iter.count <- fit$cumulative.inner.iter.count
 model.coef.eval <- fit$model.coef.eval
 model.coef.stand.eval <- fit$model.coef.stand.eval
 concomitant.coef.eval <- fit$concomitant.coef.eval
 concomitant.coef.stand.eval <- fit$concomitant.coef.stand.eval
 postweight.eval <- fit$postweight.eval
 pi.eval <- fit$pi.eval

 #print(penindex)
 ## compute the correct DF and evaluate/expand all call entries:
 arglist$control@doMLfit <- T
 arglist$control@computeDF <- T

 if(hasZ){
  concomitant.args$control@doMLfit <- T
  concomitant.args$control@computeDF <- T
 }

 if(control@expandcall){
  arglist$control@expandcall <- T
  if(hasZ) concomitant.args$control@expandcall <- T
 }
 arglist$mlfit <- NULL
 for(m in 1:M)  model.args[[m]] <- arglist  ### EDITME # 14.5.2018: 1:M -> wenn nicht uniform 1.Komponente
 ## note that this call to genmix takes place at parameter values for which
 ## the EM algorithm has already converged. thus, only one iteration is
 ## required, afterwards, the correct df values are collected.
 #### sidenote: if you wonder what this fuzz is all about: computing the
 #### effective degrees of freedom of a lasso estimator requires knowledge # MS neu genmix5 -> cublass=T für inner.iter.count
 #### of the ML estimator of the corresponding model. (for general grpindex...)
 #### since the observation weights and thus the ML estimator change in every
 #### EM iteration, the df-value would change with every EM iteration as well.
 #### thus, we save a lot of computing time by not computing the unneeded ML
 #### estimator and df in every iteration of the EM algorithm. if adaptive weights
 #### are used, however, the adaptive weights themselves (based on the ML fit)
 #### change in every EM iteration anyway.

  print("Model second time") #MS i.d.R. extrem kurz; eigentl. nur fuer berechnung der df+ruecktransformation notwendig; endoutput
  #print("lambda")
  #print(lambda)
  #print("c.lambda")
  #print(c.lambda)
  #print("lambdaF")
  #print(lambdaF)
  fit <- genmix(y=y, x=x, z=z, u=u, x.long=x.long, y.long=y.long, xv=xv,
  M=M, model=model, model.args=model.args,GEM=GEM,
  concomitant = concomitant, concomitant.args = concomitant.args,
  model.coef.init = fit$model.coef, concomitant.coef.init = fit$concomitant.coef,
  postweight.init = fit$postweight, pi.init = fit$pi, offset = offset,
  weights = weights, control = control, initialseed = initialseed,
  #model.initialseed = model.initialseed,
  checks = checks.default,
  cublass=cublass,cub=cub,survival=survival,alpha=alpha,family2=family2,intercept.smooth=intercept.smooth,
  sp=sp,ti=ti,event=event,
  c.lambda=c.lambda, penindex=penindex, grpindex=grpindex, lambda=lambda,
  lambdaF=lambdaF, ishape1=ishape1, ishape2=ishape2, c.maxiter=c.maxiter,
  maxiter1=maxiter1,maxiter2=maxiter2, BS.seed=BS.seed,BS.seedindex=BS.seedindex, help=help, trace=trace,
  fn.val.option=fn.val.option)

 ## now prepare the final output. note that fit at this moment is the result of
 ## a call to genmix, see there for the existing elements. we add some additional
 ## return values:
 fit$penindex <- penindex
 fit$grpindex <- grpindex
 fit$lambda <- lambda
 fit$lambdaR <- lambdaR
 fit$lambdaF <- lambdaF

 if(hasZ){
  fit$c.penindex <- c.penindex
  fit$c.grpindex <- c.grpindex
  fit$c.lambda <- c.lambda
  fit$c.lambdaR <- c.lambdaR
  fit$c.lambdaF <- c.lambdaF
 }

 fit$model.control <- model.control
 fit$concomitant.control <- concomitant.control

 fit$topcall <- mycall   # this is the call to cublasso. fit$call is the call to
                         # genmix after argument replacement and rearrangement
                         # has been performed by cublasso.

 ## MS Ruecktransformation der Koeffs
 #aus grplasso:
 ### Transform the coefficients back to the original scale if the design
 ### matrix was standardized
 #if(standardize){
#   if(any.notpen)
#     coef.m[inotpen.which,] <- (1 / scale.notpen) * coef.m[inotpen.which,]
#   ## For df > 1 we have to use a matrix inversion to go back to the
#   ## original scale
#   for(j in 1:length(ipen.which)){
#     ind <- ipen.which[[j]]
#     coef.m[ind,] <- solve(scale.pen[[j]], coef.m[ind,,drop = FALSE])
#   }
# }
#
# ## Need to adjust intercept if we have performed centering
# if(center){
#   coef.m[intercept.which,] <- coef.m[intercept.which,] -
#     apply(coef.m[-intercept.which,,drop = FALSE] * mu.x, 2, sum)
# }

 if(standardize){               # comment out this line and the following ones
  fit$x <- x.original           # if you have a huge dataset and run into
  if(hasZ) fit$z <- z.original  # memory issues...
 }else{
  fit$x <- x
  if(hasZ) fit$z <- z
 }
 fit$y <- y

 fit$iter.count2 <- fit$iter.count
 fit$iter.count <- iter.count
 fit$cumulative.inner.iter.count <- cumulative.inner.iter.count
 fit$loglik.eval2 <- fit$loglik.eval # MS das waere von second run
 fit$loglik.eval <- loglik.eval # MS das waere von first run
 fit$fn.val.op2 <- fit$fn.val.op
 fit$fn.val.op <- fn.val.op
 fit$comploglik.eval2 <- fit$comploglik.eval
 fit$comploglikpen.eval2 <- fit$comploglikpen.eval
 fit$comploglik.eval <- comploglik.eval
 fit$comploglikpen.eval <- comploglikpen.eval
 fit$model.coef.eval2 <- fit$model.coef.eval
 fit$model.coef.eval <- model.coef.eval
 fit$model.coef.stand.eval2 <- fit$model.coef.stand.eval
 fit$model.coef.stand.eval <- model.coef.stand.eval
 fit$concomitant.coef.eval2 <- fit$concomitant.coef.eval
 fit$concomitant.coef.eval <- concomitant.coef.eval
 fit$concomitant.coef.stand.eval2 <- fit$concomitant.coef.stand.eval
 fit$concomitant.coef.stand.eval <- concomitant.coef.stand.eval
 fit$postweight.eval2 <- fit$postweight.eval
 fit$postweight.eval <- postweight.eval
 fit$pi.eval2 <- fit$pi.eval
 fit$pi.eval <- pi.eval
 return(fit)
})




## a function predicting new observations based on an 'object' returned by genmix:
predict.cublasso <- cmpfun(function(object, type = c("mixture", "posterior", "classify"), newdata = NULL){  # note that something like "type = link/terms" wouldnt make
 type <- match.arg(type)                                                                                    # sense in mixture models...
 M <- length(object$fit)

 ## get the postweight, pi and mu objects for prediction
 if(missing(newdata) | is.null(newdata)){
  postweight <- object$postweight
  pi <- object$pi
  mu <- lextract(object$model, "mu")
 }else{
  if(!is.list(newdata) | !("x" %in% names(newdata)))
    stop("newdata must be supplied as a names list with names 'x' and, potentially, 'z'!")
  if(!is.null(object$concomitant.coef) && !("z" %in% names(newdata)))
    stop("newdata must be supplied as a names list with names 'x' and 'z'!")

  hasZ <- !is.null(newdata$z)

  ## compute mu for the new data. for the MLSP-components, we use the MLSP predict method
  mu <- list(); length(mu) <- M
  mu[[1]] <- object$model[[1]]$mu      # this is the uniform component...
  mu <- lapply(seq(2,M), function(i){predict(object = object$model[[i]]$fit, newdata = newdata, type = "response")})

  ## compute the prior weights. if no concomitant model was used, simply recycle
  ## the estimated prior probabilities from the fitted mixture model.
  ## in case of a concomitant variable model, use the MLSP predict method to
  ## compute the predicted prior probabilities based on the new 'z'-variables.
  ## NOTE: this only works if the concomitant model was fit by a driver function
  ## based on MLSP, like for example concomitant.default!
  ## if another driver function was used for the concomitant fit, the required
  ## syntax might change slightly.
  if(hasZ){
   pi <- predict(object$concomitant, newdata = list(x = newdata$z), type = "response")
  }else{
   pi <- matrix(object$pi[1,], nrow = nrow(newdata$x), ncol = M, byrow = T)
  }

  ## note that posterior weights can only be computed if y-values belonging to
  ## x- and z-values are observed. this is never the case in the prediction for
  ## new data!
  if(type %in% c("posterior", "classify")){
   type <- "mixture"
   warning(paste("type 'mixture' is the only available sort of prediction for new data"))
  }
 }

 ## now the actual prediction
 pred <- switch(type,
                "mixture" = Reduce('+', sapply(seq_len(M), function(i){mu[[i]] * pi[,i]})),
                "posterior" = Reduce('+', sapply(seq_len(M), function(i){mu[[i]] * postweight[,i]})),
                "classify" = Reduce('+', sapply(seq_len(M), function(i){mu[[i]][cbind(seq_len(nrow(postweight)), max.col(postweight))]})) )

 return(pred)
})








