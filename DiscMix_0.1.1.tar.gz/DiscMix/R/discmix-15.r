# Function for initialization of the Mixture Model, part of DiscMix
# Function without initialization in genmix
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker

#' discmix
#'
#'Function to fit several discrete finite mixture models, such as CUP, CUB, BetaBin model and discrete cure models
#'with initializations.
#'
#' @param y response matrix
#' @param x design matrix for the model/preference component
#' @param z design matrix for the weights
#' @param x.long design matrix for specific survival models (usually not in use)
#' @param y.long response matrix for specific survival models (usually not in use)
#' @param u design matrix for the shape of the uncertainty component
#' @param xv design matrix for categoric specific cavariables (usually not in use)
#' @param M number of models/mixture components (usually 2)
#' @param model Choose the kind of Mixture Model to be fitted. Note that the models require different data structures and provide different outputs.
#' \itemize{
#'   \item CUP(c) Model (vgam): \code{uniform.cumlogit.mix.vgam}
#'   \item CUP(a) Model (vgam): \code{uniform.acatlogit.mix.vgam}
#'   \item CUP(c) Model (mrsp): \code{uniform.cumlogit.mix}
#'   \item CUB Model: \code{uniform.cubbinomial}
#'   \item BetaBin Model: \code{betabinom.vglm.cumlogit.mix.vgam}
#'   \item Cure Model (mrsp): \code{zero.seqlogitsurv.mix}
#' }
#' @param GEM Type of EM-algorithm: \code{GEM=T} Generalized EM-algorithm is used
#' @param control control informations, i.e. \code{rel.tol} for relative tolerance or \code{max.iter} for maximum number of em iterations
#' @param pwi Weight initialization: weight value
#' @param nr.seeds Weight initialization: Number of draws for each pwi
#' @param pwi.method Weight initialization: "both": constant weights and sample; "fix": only constant weights; "sample": only sample
#' @param parallel Weight initialization: Prallelized initialization
#' @param cores Weight initialization: number of cores (for \code{parallel=T})
#' @param small.output Reduction of size of the output object
#' @param help Stabilization of estimation process by preventing weights to be too close to zero or one
#'
#'
#' @return Estimates a finite mixture
#'   \item{pi}{matrix with \code{M}=2 columns of mixture weights; First column refers to first component of \code{model}, that is in the
#'   CUP model the uniform distribution, in the BetaBin model the beta-binomial distribution and in the Cure Model the Long-term survivors}
#'   \item{model.coef}{List with estimated Coefficients of the mixture components in order of \code{model} components}
#'   \item{model.coef.stand}{List with estimated Coefficients for standardized covariates of the mixture components in order of \code{model} components (if applicable)}
#'   \item{concomitant.coef[[1]]}{Estimated Coefficients for the mixture weight}
#'   \item{concomitant.coef.stand}{List with estimated Coefficients for standardized covariates for the mixture weight (if applicable)}
#'   \item{df}{Degrees of freedom}
#'   \item{AIC}{AIC}
#'   \item{BIC}{BIC}
#'   \item{loglik}{Loglikelihood}
#'
#' @references{
#' Tutz, Gerhard, Micha Schneider, Maria Iannario and Domenico Piccolo (2017): Mixture models for ordinal responses to account for uncertainty of choice. Advances in Data Analysis and Classification 11(2), 281--305.
#'
#' Tutz, Gerhard, and Micha Schneider (2019): Flexible uncertainty in mixture models for ordinal responses. Journal of Applied Statistics, 46(9), 1582--1601.
#'
#' Mauerer, Ingrid and Micha Schneider (2019): Perceived party placements and uncertainty on immigration in the 2017 German election. In Debus, M., M. Tepe and J. Sauermann (Eds.), Jahrbuch f\"ur Handlungs- und Entscheidungstheorie: Band 11, pp. 117--143. Wiesbaden: Springer.
#' }
#'
#' @examples
#' # Data Generation
#' arthritis <- data.frame(drug=c(rep("new agent", 24+37+21+19+6),
#' rep("active control", 11+51+22+21+7)),
#' assessment=c(rep(1,24), rep(2,37), rep(3,21), rep(4,19), rep(5,6), rep(1,11),
#'              rep(2,51), rep(3,22), rep(4,21), rep(5,7)))
#'
#' # Response matrix y
#' table(arthritis$assessment, arthritis$drug)
#' y <- as.matrix(arthritis$assessment)
#' colnames(y) <- c("assessment")
#' head(y)
#'
#' # Design Matrix x
#' x <- matrix(1, nrow=nrow(arthritis), ncol = 1)
#' x[,1] <- arthritis$drug
#' x[,1] <- x[,1] - 1
#' colnames(x) <- c("drug")
#' head(x)
#'
#' # Fit CUP Model (Version vgam):
#' set.seed(200)
#' CUP <- discmix(y = y, x=x, model = uniform.cumlogit.mix.vgam)
#'
#' # Model output
#' unique(CUP$pi) # Weights (pi)
#' round(CUP$model.coef[[2]], 3) # Model coefficients
#' CUP$loglik
#'
#' # Fit CUP Model (Version mrsp):
#' set.seed(200)
#' CUPm <- discmix(y = y, x=x, model = uniform.cumlogit.mix)
#'
#' # Model output
#' unique(CUPm$pi) # Weights (pi)
#' round(CUPm$model.coef[[2]][[1]], 3)
#'
#' #' # Fit CUB Model):
#' set.seed(200)
#' CUB <- discmix(y = y, x=x, model = uniform.cubbinomial)
#'
#' # Model output
#' unique(CUB$pi) # Weights (pi)
#' round(CUB$model.coef[[2]][[1]], 3)
#'
discmix <- cmpfun(function(y, x = NULL, z = NULL, x.long=NULL,y.long=NULL,u=NULL, xv=NULL,
                              M = 2, model, model.args = NULL,GEM=F,
                              concomitant = "concomitant.default", concomitant.args = NULL,
                              model.coef.init = NULL, concomitant.coef.init = NULL,
                              postweight.init = NULL, pi.init = NULL, offset = NULL,
                              #refit = F, mlfit = NULL, c.refit = refit, c.mlfit = NULL, standardize = T,
                              #threshold = F, c.threshold = threshold,
                              #model.control = MRSP.control(), concomitant.control = NULL,  #standardize=F, expandcall=F,ridgestabil=T, keepdat=F
                              weights = NULL, control = genmix.control(), control.init=genmix.control(),
                              checks = checks.default, initialseed = sample(1000, size=1),model.initialseed=NULL,intercept.lambda=NULL,
                              cublass=F,cub=F,survival=F,alpha=NULL,family2=NA,sp=NULL,intercept.smooth=NULL,ti=NULL,event=NULL,
                              c.lambda=NULL, penindex=NULL, grpindex=NULL, lambda=123456789,
                              lambdaF=123456789, ishape1=1, ishape2=NULL, c.maxiter=NULL,
                              maxiter1=NULL,maxiter2=NULL, BS.seed=NULL,BS.seedindex=NULL,
                              method=1,pwi=c(0.6,0.7,0.8,0.9),nr.seeds=2,pwi.method="both", seed.init=1000, parallel=T, cores=detectCores()-1,small.output=T,dat=NULL,help=F,trace=F, data=NULL,
                              fn.val.option="NA",...)
{
  if(class(x)=="formula"|class(z)=="formula"|class(u)=="formula"|class(xv)=="formula") {require(formula.tools)}
  require(MRSP)

  hasY <- !is.null(y)
  if(hasY){
    if(is.character(y)){
      yform <- y
      if(is.null(data)){stop("If you provide y as character you need to specify the data argument")}#; otherwise provide an matrix for y")}
      y <- as.matrix(get(y, data))
      colnames(y)[1] <- yform}
    else{yform <- colnames(y)[1]}

  }

  hasX <- !is.null(x)
  hasZ <- !is.null(z)
  hasU <- !is.null(u)
  hasXV <- !is.null(xv)

  if(!is.list(model)) model.test <- evalh(model)
  if(!hasY & (sum(model.test=="seqlogitsurv")==0)){stop("Y is missing")} # only case where y can be missing
  if(!hasY & (sum(model.test=="seqlogitsurv")>0)){y<-ti; if(is.vector(y)) {y <- as.matrix(y)}}
  if(sum(model.test=="seqlogitsurv")==0 & any(is.na(y))){warning("function may handle only complete data in y at the moment")} #- bei seq normal #13.05.2019

  if(hasX){
    if(class(x)=="formula") {x <- as.character(x)}
    if(is.character(x)){  #|class(x)=="formula"
      xform <- as.formula(paste(x,"-",yform)) # evtl auch mit update moeglich dann character-Umwandlung sparen?-yform for ~. -> y never part of explanatory variables!
      x <- model.matrix(xform, data=data)
    }
  if(any(is.na(x))){warning("function may handle only complete data in x at the moment")}
  }

  if(hasZ){
    if(class(z)=="formula") {z <- as.character(z)}
    if(is.character(z)){
      zform <- as.formula(paste(z,"-",yform)) # evtl. in forward_selection auslagern bzw. stimmt das immer/notwendig?
      #z2form <- update(z2, as.formula(paste("~ . - ", yform))) # klappt irgendwie nicht bei "~." deshalb umwandlung mit character
      z <- model.matrix(zform, data=data)
    }
  if(any(is.na(z))){warning("function may handle only complete data in z at the moment")}
  }

  if(hasU){
    if(class(u)=="formula") {u <- as.character(u)}
    if(is.character(u)){
      uform <- as.formula(paste(u,"-",yform))
      u <- model.matrix(uform, data=data)
    }
  if(any(is.na(u))){warning("function may handle only complete data in u at the moment")}
  }

  #if(hasXV){ # XV list...
  #  if(class(xv)=="formula") {xv <- as.character(xv)}
  #  if(is.character(xv)){
  #    xvform <- as.formula(paste(xv,"-",yform))
  #    xv <- model.matrix(xvform, data=data)
  #  }
  #  if(any(is.na(xv))){warning("function may handle only complete data in xv at the moment")}
  #}

  # alt if matrices
  #if(any(is.na(y))){warning("function may handle only complete data in y at the moment")}
  #if(!is.null(x)){if(any(is.na(x))){warning("function may handle only complete data in x at the moment")}}
  #if(!is.null(z)){if(any(is.na(z))){warning("function may handle only complete data in z at the moment")}}
  # dat braucht man eigentlich nicht, aber in vglm noetig und sonst parallelisierung in samplep.genmix schwieriger
  if (GEM==T)
  {# gute werte: 10, 2, 10 oder 30,3,30, 40,2,40?
    if(control@max.iter==500){control@max.iter <- 2500}
    if(is.null(c.maxiter)) {c.maxiter <- 20} # default max 500 frueher 30, 3, 3
    if(is.null(maxiter1)) {maxiter1 <- 2} # default max 30
    if(is.null(maxiter2)) {maxiter2 <- 2} # MRSP: 10; VGAM: 2
  }
  if(!hasZ){pwi.method <- "fix"}

  if(!is.null(postweight.init)){
    if(!is.list(postweight.init)) {
      postweight.init <- list(postweight.init)
      #warning("postweight.init has to be a list")
      }
  }

  if(!is.null(postweight.init)) # falls NAs im postweight,init -> postweights nicht verwenden, sondern generieren
      {if(!all(is.na(postweight.init)==FALSE))
        {postweight.init <- NULL
        }
      }

  if(!is.null(postweight.init) & pwi.method=="none"){
    #postweight.init <- postweight.init}# nur uebergebne postweight.init; kein pwi-generierung
  }else{
    if(pwi.method=="none"){
    pwi.method <- "both"
    warning("pwi.method was set to both")
    }
    postweight.init1 <- postweight.init
  if(pwi.method=="sample")
  {
  index <- expand.grid(1:nr.seeds, pwi,TRUE)
  }
  if(pwi.method=="fix") # v.a. sinn, wenn is.null(z)==T
  {
    index <- expand.grid(1, pwi,FALSE)
  }
  if(pwi.method=="both")
  {
    index1 <- expand.grid(1:nr.seeds, pwi, TRUE)
    index2 <- expand.grid(1, pwi,FALSE)
    index <- rbind(index1, index2)
  }
colnames(index) <- c("nr.seeds","pwi","sample")
#print("Initialization methods:")
print(index)
postweight.init <- vector("list", nrow(index))
set.seed(seed.init)
seeds <- sample(-10000:10000,nr.seeds)
seeds2 <- sample(-10000:10000,50) # index[1,2]
postweight.init[[1]] <- postweight.initialization(y=y, M=M, pwi=index[1,2], seed=seeds[index[1,1]],sample=index[1,3])
 for (i in 2:nrow(index))
 {
 postweight.init[[i]] <- postweight.initialization(y=y, M=M, pwi=index[i,2], seed=seeds[index[i,1]],sample=index[i,3])
 test <- sum((postweight.init[[i-1]]-postweight.init[[i]])^2)
 j <- 1
 if(index[i,3]==T)
 {
 while (test < 0.1*nrow(y)) # test, wenn differenz zwischen inits zu klein
  {
  postweight.init[[i]] <- postweight.initialization(y=y, M=M, pwi=index[i,2], seed=seeds2[j],sample=index[i,3])
  test <- sum((postweight.init[[i-1]]-postweight.init[[i]])^2)
  if (j==length(seeds2)) {break}
  j <- j+1
  }
 }

 }

postweight.init <- c(postweight.init1,postweight.init)
print(length(postweight.init))
}
if(control.init@rel.tol<1e-2){control.init@rel.tol <- 0.01} # 0.01 #13.09.
if(control.init@max.iter>60){control.init@max.iter <- 60}

  #####
# aehnlich wie bei penmix; problem funktioniert nur bei MRSP und nicht bei vgam-Komponenten
# da nur fuer zeitersparnis relevant wieder auskommentiert
#   if(is.null(concomitant.args) && concomitant == "concomitant.default"){
#     concomitant.args <- list(control = MRSP.control())
#     concomitant.args.default <- F
#     concomitant.args$control@doMLfit <- F     # braue ich das fuer loglikpen zum Vegleich
#     concomitant.args$control@computeDF <- F    # braue ich das fuer loglikpen zum Vegleich?
#     concomitant.args$control@expandcall <- F
#     }
#   else{concomitant.args.default <- T}
#
#   if(is.null(model.args)){
#     arglist <- list(control = MRSP.control())
#     arglist.default <- F
#   arglist$control@doMLfit <- F
#   arglist$control@computeDF <- F
#   arglist$control@expandcall <- F
#
#   for(m in 1:M){                                                                                                                            ### EDITME
#     model.args[[m]] <- arglist
#     }
#   }
#   else{
#     arglist.default <- T}
#
#   print(model.args)
#   print(concomitant.args)
#
# ###

fitcall <- call("genmix",
                  y=y, x=x, z=z, u=u, x.long=x.long, y.long=y.long, xv=xv,
                  M=M, model=model, model.args=model.args,GEM=GEM,
                  concomitant = "concomitant.default", concomitant.args = concomitant.args,
                  model.coef.init = model.coef.init, concomitant.coef.init = concomitant.coef.init,
                  postweight.init = substitute(postweight.init), pi.init = pi.init, offset = offset,
                  weights = weights, control = control.init,
                  checks = checks.default, initialseed = initialseed,
                  cublass=cublass,cub=cub,survival=survival,alpha=alpha,family2=family2,intercept.smooth=intercept.smooth,intercept.lambda=intercept.lambda,
                  sp=sp,ti=ti,event=event,
                  c.lambda=c.lambda, penindex=penindex, grpindex=grpindex, lambda=lambda,
                  lambdaF=lambdaF, ishape1=ishape1, ishape2=ishape2, c.maxiter=c.maxiter,
                  maxiter1=maxiter1,maxiter2=maxiter2, BS.seed=BS.seed,BS.seedindex=BS.seedindex, help=help, trace=trace,
                  fn.val.option=fn.val.option)

indexcorepar <- function(i){
  indexcore(i = i)
}

# bootcore
indexcore <- function(i){
  #require("MRSP")
  #require("VGAM")
  #require("mgcv")
  #require("DiscMix") #V1
  #source("genmix-gesamt-3.r")
  fitcall$postweight.init <- quote(i) #V3
  #fitcall$postweight.init <- quote(postweight.init[[i]]) #V1 #V2

  # bei grid hier statt daten werte aus Grid Ã¼bernehmen
  fit <- try(eval(fitcall),TRUE)
  if (!inherits(fit, 'try-error')){#{fit <- NULL}
    if(small.output==T){
      fit$weights <- NULL
      fit$model[[1]]$fit <- NULL
      fit$model[[1]]$mu <- NULL
      fit$model[[1]]$logl <- NULL
      fit$model[[2]]$fit <- NULL
      fit$model[[2]]$mu <- NULL
      fit$model[[2]]$logl <- NULL}
  }
  fit
}

if(parallel){
  cl <- makeCluster(cores)#cores outfile
  clusterEvalQ(cl, {
    library(DiscMix)
    })#V2 #V3
  #clusterExport(cl, c("fitcall","small.output","postweight.init"), envir=environment()) #V2
  clusterExport(cl, c("fitcall","small.output"), envir=environment()) #V3
  #clusterExport(cl, ls(envir = sys.frame(sys.nframe())), envir = sys.frame(sys.nframe()))#V1
  initlist <- parLapply(cl, postweight.init, indexcorepar) #V3
  #initlist <- parLapply(cl, seq(length(postweight.init)), indexcorepar)#V1 #V2
  stopCluster(cl)
}else{
  cl <- makeCluster(1)#cores outfile
  clusterEvalQ(cl, {
    library(DiscMix)
  })#V2 #V3
  #clusterExport(cl, c("fitcall","small.output","postweight.init"), envir=environment()) #V2
  clusterExport(cl, c("fitcall","small.output"), envir=environment()) #V3
  #clusterExport(cl, ls(envir = sys.frame(sys.nframe())), envir = sys.frame(sys.nframe()))#V1
  initlist <- parLapply(cl, postweight.init, indexcorepar) #V3
  #initlist <- parLapply(cl, seq(length(postweight.init)), indexcorepar)#V1 #V2
  stopCluster(cl)
  #get(ls(envir = parent.frame()), envir = parent.frame())
  #initlist <- lapply(seq(length(postweight.init)), indexcore)
}

#save(initlist, file="initlist.Rdata")
# Test, welcher fit am besten, likelihoods vergleichen
print("Likelihood(s) of Initialization (small EM):")
print_l <- try(print(lextract(initlist,"loglikpen")),TRUE)
if (inherits(print_l, 'try-error')){print(initlist[[1]])}

fn.opt <- rep("NA",length(initlist))
converge <- F
# sortieren der initlist von gross nach klein
initlist <- initlist[order(sapply(lextract(initlist,"loglikpen"),function(X){X}),decreasing = T)]
j <- 1
max.reach <- 0

while(converge==F)
{
  print(initlist[[j]]$loglikpen)
####


  # ## compute the correct DF and evaluate/expand all call entries:
  # if(concomitant.args.default==F)
  #   {
  #   if(hasZ){ # brauche ich hasZ?
  #     concomitant.args$control@doMLfit <- T
  #     concomitant.args$control@computeDF <- T
  #     concomitant.args$control@expandcall <- T
  #   }
  # }
  #
  # if(arglist.default==F)
  #   {
  #   arglist$control@doMLfit <- T
  #   arglist$control@computeDF <- T
  #   arglist$control@expandcall <- T
  #   arglist$mlfit <- NULL
  #
  #   for(m in 1:M)  model.args[[m]] <- arglist
  # }

###
fitcall2 <- call("genmix",
                y=y, x=x, z=z, u=u, x.long=x.long, y.long=y.long, xv=xv,
                M=M, model=model, model.args=model.args,GEM=GEM,
                concomitant = "concomitant.default", concomitant.args = concomitant.args,
                model.coef.init = initlist[[j]]$model.coef, concomitant.coef.init = initlist[[j]]$concomitant.coef,
                postweight.init = initlist[[j]]$postweight, pi.init = initlist[[j]]$pi, offset = offset,
                weights = weights, control = control,
                checks = checks.default, initialseed = initialseed,
                cublass=cublass,cub=cub,survival=survival,alpha=alpha,family2=family2,intercept.smooth=intercept.smooth,
                sp=sp,ti=ti, event=event, intercept.lambda=intercept.lambda,
                c.lambda=c.lambda, penindex=penindex, grpindex=grpindex, lambda=lambda,
                lambdaF=lambdaF, ishape1=ishape1, ishape2=ishape2, c.maxiter=c.maxiter,
                maxiter1=maxiter1,maxiter2=maxiter2, BS.seed=BS.seed,BS.seedindex=BS.seedindex, help=help, trace=trace,
                fn.val.option=fn.val.option)
fit <- eval(fitcall2)

if(max.reach==1|length(initlist)==1){return(fit)}
if(fit$fn.val.start+1<fit$fn.val)
{
  print("other starting values are selected")
  print(fit$fn.val.start)
  print(fit$fn.val)
  #print(fit$fn.val.op[length(fit$fn.val.op)])
  #fn.opt[j] <- fit$fn.val.op[length(fit$fn.val.op)]
  fn.opt[j] <- fit$fn.val
  j <- j+1
}
else{converge <- T}
if(j>length(initlist) & converge==F) # falls jeder init schlechter wird, nehme die beste von den schlechtesten/ Alternative setze auf NA
{
  #fit <- NA
  j <- which.min(fn.opt) # fn.val positiv, loglik negativ
  max.reach <- 1
  }
}# end while
if(fit$em.diverge>0){warning("The mixture loglikelihood hasn't converged monotonically in all iterations")} # neu 13.05.2019 anstatt einzelne warnings

return(fit)
})
