MRSPwelcomemessage <- function(){
  cat("-----------------------------",
      "This is DiscMix version 0.1.1",
      #"-----------------------------",
      "Authors: Micha Schneider \n Wolfgang Poessnecker",
      "-----------------------------",
      sep = "\n")   }

.onAttach <- function(libname, pkgname){
  packageStartupMessage(MRSPwelcomemessage())
  #if(!("MRSP" %in% loadedNamespaces())){ library(MRSP) }
  #%multinomlogitmodel <- multinomlogit()
  #%sequentiallogitmodel <- sequentiallogit()
  #%cumulativelogitmodel <- cumulativelogit()
  #%cubbinomialmodel <- CUBbinomiallogit()
}
