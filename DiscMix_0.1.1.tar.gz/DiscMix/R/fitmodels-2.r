# help/wrap around function for grid search; part of DiscMix
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker

fitmodels <- function(model=model, y=y, x=x, z=z, penalty=penalty, data=data, control = genmix.control(max.iter=max.iter,rel.tol=rel.tol),
                      penindex = penindex, c.penindex=c.penindex, index=index, rel.tol=rel.tol, max.iter=max.iter, threshold=threshold,lambdaF =lambdaF, ti=ti, event=event,
                      postweight.init=postweight.init, small.output=T,pwi=pwi,pwi.method=pwi.method,nr.seeds=nr.seeds, fn.val.option=fn.val.option, GEM=GEM){

  nrlambda <- length(unique(index[,"lambda"]))
  c.nrlambda <- length(unique(index[,"c.lambda"]))
  lambdaseq <- sort(unique(index[,"lambda"]), decreasing=T)
  c.lambdaseq <- sort(unique(index[,"c.lambda"]), decreasing=T)


  # Init von Matrizen etc
  fit <- vector("list", nrow(index)) # Modell-fit

  # Diagnose
  postweights <- vector("list", nrow(index))
  pis <- vector("list", nrow(index))
  loglik.evals <- vector("list", nrow(index))
  loglik.evals2 <- vector("list", nrow(index))
  fn.val.ops <- vector("list", nrow(index))
  fn.val.ops2 <- vector("list", nrow(index))
  comploglik.evals2 <- vector("list", nrow(index))
  comploglikpen.evals2 <- vector("list", nrow(index))
  comploglik.evals <- vector("list", nrow(index))
  comploglikpen.evals <- vector("list", nrow(index))
  iter.counts <- vector(mode="numeric", length=nrow(index))
  inner.iters <- vector(mode="numeric", length=nrow(index))

  # Ergebnisse
  logliks <- vector(mode="numeric", length=nrow(index))
  dfs <- vector(mode="numeric", length=nrow(index))
  aics <- vector(mode="numeric", length=nrow(index))
  bics <- vector(mode="numeric", length=nrow(index))

  # Call
  #print(rel.tol)
  fitcall2 <- call("penmixfit",parallel=F, model=model, y = y, x=x, z=z, penalty=penalty, data=data,
                   lambda = index[1,"lambda"], c.lambda = index[1,"c.lambda"],lambdaF =lambdaF, ti=ti, event=event,
                   penindex = penindex,c.penindex=c.penindex, threshold=threshold,
                   control = genmix.control(max.iter=max.iter,rel.tol=rel.tol),postweight.init=postweight.init,pwi=pwi,pwi.method=pwi.method,nr.seeds=nr.seeds, fn.val.option=fn.val.option)

  # -> Vorteil schneller als single-core + vorherige Ergebnisse als init verwendbar
  for (j in seq(1,nrow(index))){
    fitcall2$lambda <- as.numeric(as.character(index[j,"lambda"]))
    fitcall2$c.lambda <- as.numeric(as.character(index[j,"c.lambda"]))
    if(is.null(lambdaF)){fitcall2$lambdaF <- as.numeric(as.character(index[j,"lambda"]))} # NEU 23.10.2018
    if(j==1 & is.null(postweight.init)){
      if(length(fitcall2$pwi)<3)
        {fitcall2$pwi <- c(0.6,0.7,0.8,0.9)}
    }
    if(j==2){fitcall2$pwi <- pwi}
    if(j > 1) # Init von vorherigem übergeben; evtl. mit noch mehr, aber dann penmix umschreiben...
    {
      fitcall2$postweight.init <- fit[[j-1]]$postweight
    }
    fit[[j]] <- try(eval(fitcall2),TRUE) # (init innerhalb von genmix2)

    if (inherits(fit[[j]], 'try-error')){
      print(fit[[j]])
      fit[[j]] <- list(error=fit[[j]],loglik=NA,df=NA,AIC=NA,BIC=NA,
                       index=index[j,],
                       postweight=NA,pi=NA,
                       loglik.eval=NA, loglik.eval2=NA,
                       fn.val.op=NA, fn.val.op2=NA,
                       comploglik.eval=NA, comploglik.eval2=NA,
                       comploglikpen.eval=NA, comploglikpen.eval2=NA,
                       iter.count=NA, cumulative.inner.iter.count=NA,
                       model.coef=list(NA,list(matrix(NA))), model.coef.stand=list(NA,list(matrix(NA))),
                       concomitant.coef=list(matrix(c(NA,NA),nrow=2),NA),
                       concomitant.coef.stand=list(matrix(c(NA,NA),nrow=2),NA)
                       )# mit coef/concomitant dimensions passt noch was nicht -> dim(fit[[j]]$model.coef[[2]][[1]])[1]>1 gibts noch ein problem test mit !vor inherits
    }

    # Matrizen befüllen
    logliks[j] <- fit[[j]]$loglik
    dfs[j] <- fit[[j]]$df
    aics[j] <- fit[[j]]$AIC
    bics[j] <- fit[[j]]$BIC
    postweights[[j]] <- fit[[j]]$postweight
    pis[[j]] <- fit[[j]]$pi
    loglik.evals[[j]] <- fit[[j]]$loglik.eval
    loglik.evals2[[j]] <- fit[[j]]$loglik.eval2
    fn.val.ops[[j]] <- fit[[j]]$fn.val.op
    fn.val.ops2[[j]] <- fit[[j]]$fn.val.op2
    comploglik.evals[[j]] <- fit[[j]]$comploglik.eval
    comploglik.evals2[[j]] <- fit[[j]]$comploglik.eval2
    comploglikpen.evals[[j]] <- fit[[j]]$comploglikpen.eval
    comploglikpen.evals2[[j]] <- fit[[j]]$comploglikpen.eval2
    iter.counts[j] <- fit[[j]]$iter.count
    inner.iters[j] <- fit[[j]]$cumulative.inner.iter.count

    #print(fit[[j]]$model.coef)
    if (j==1) # before you do not know the number of coefficients necessary; if there only once
    {model.coef <- matrix(nrow=nrow(index),ncol=length(fit[[j]]$model.coef[[2]][[1]]))
    #print(fit[[j]]$model.coef)
    if (dim(fit[[j]]$model.coef[[2]][[1]])[1]>1)
    {
      colnames(model.coef) <- paste(rep(colnames(fit[[j]]$model.coef[[2]][[1]]),each=nrow(fit[[j]]$model.coef[[2]][[1]])),1:nrow(fit[[j]]$model.coef[[2]][[1]]),sep=":")
    }
    else{
      colnames(model.coef) <- colnames(fit[[j]]$model.coef[[2]][[1]])}

    model.coef.stand <- model.coef
    concomitant.coef <- matrix(nrow=nrow(index),ncol=length(fit[[j]]$concomitant.coef[[1]][2,]))
    colnames(concomitant.coef) <- colnames(fit[[j]]$concomitant.coef[[1]])
    concomitant.coef.stand <- concomitant.coef
    }

    model.coef[j,] <- as.vector(fit[[j]]$model.coef[[2]][[1]])
    concomitant.coef[j,] <- fit[[j]]$concomitant.coef[[1]][2,]
    if(all(is.na(model.coef[j,])==FALSE)){
    model.coef.stand[j,] <- as.vector(fit[[j]]$model[[2]]$fit@coef.stand[[1]])}
    if(all(is.na(concomitant.coef[j,])==FALSE)){
    concomitant.coef.stand[j,] <- fit[[j]]$concomitant$fit@coef.stand[[1]][2,]}
    postweights[[j]] <- fit[[j]]$postweight

    if(j>=2 & small.output==T) {fit[[j-1]]<- NA}
  } # lambda ende
  if(small.output==T){fit <- NA}
  print(length(fit))
  return(list(fit=fit,logliks=logliks, dfs=dfs, aics=aics, bics=bics, index=index, pis=pis,
              iter.counts=iter.counts, inner.iters=inner.iters,
              loglik.evals=loglik.evals, loglik.evals2=loglik.evals2, postweights=postweights,
              fn.val.ops=fn.val.ops, fn.val.ops2=fn.val.ops2,
              comploglik.evals=comploglik.evals, comploglik.evals2=comploglik.evals2,
              comploglikpen.evals=comploglikpen.evals, comploglikpen.evals2=comploglikpen.evals2,
              model.coef=model.coef, concomitant.coef=concomitant.coef,
              model.coef.stand=model.coef.stand, concomitant.coef.stand=concomitant.coef.stand))
}
