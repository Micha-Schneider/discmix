################################################################################
#####    Setting up the main classes of genmix; part of DiscMix            #####
################################################################################
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker

## control class   # note: this could be extended by a lot at a later point...
setClass("genmix.control",
         representation = representation(
           max.iter     = "numeric",
           min.iter     = "numeric",
           rel.tol      = "numeric",
           M.max        = "numeric",
           trace        = "logical",
           pass.coefs   = "logical",
           keepdata     = "logical",
           expandcall   = "logical"),

         prototype = list(
           max.iter     = 500,
           min.iter     = 2,
           rel.tol      = 1e-6,
           M.max        = 20,
           trace        = FALSE,
           pass.coefs   = TRUE,
           keepdata     = F,
           expandcall   = T),

         validity = function(object){

           if(ceiling(object@max.iter) != floor(object@max.iter) |
              object@max.iter <= 0)
             return("max.iter must be a positive integer!")

           if(object@rel.tol <= 0)
             return("rel.tol has to be positive")

           return(TRUE)
         }
)

genmix.control <- function(max.iter = 500, min.iter=2, rel.tol = 1e-6, M.max = 20, trace = F,
                           pass.coefs = T, keepdata = F, expandcall = T){

  ## Purpose: Options for the genmix function
  ## ---------------------------------------------------------------------------
  ## Arguments:
  ## max.iter:    maximal number of iterations of the EM algorithm.
  ## rel.tol:     convergence relative tolerance for EM; the smaller the more
  ##              precise. note that you must supply tolerance levels for the
  ##              M-step drivers in model.args if you don't want the defaults.
  ## M.max:       maximum number of models to use if M is chosen via BIC.
  ##              currently not used.
  ## trace:       should certain convergence messages and stuff like that be
  ##              printed? only concerns the EM algorithm, not the fitting
  ##              inside the M-steps!
  ## pass.coefs:  should the coefficient objects from the previous EM iteration
  ##              be passed as starting values for the fitting functions in the
  ##              current EM iteration?
  ## keepdata:    should the data arguments be stored in the genmix output?
  ## expandcall:  should the entries of the modell call be evaluated?
  ## ---------------------------------------------------------------------------

  RET <- new("genmix.control",
             max.iter     = max.iter,
             min.iter     = min.iter,
             rel.tol      = rel.tol,
             M.max        = M.max,
             trace        = trace,
             pass.coefs   = pass.coefs,
             keepdata     = keepdata,
             expandcall   = expandcall)
  RET
}
