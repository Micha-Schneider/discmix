# Function to perform bootstrap samples in DiscMix
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker

#' bootp.discmix
#'
#' Function to perform bootstrap (BS) samples of discmix models.
#'
#' @param BS.seed Seed for generating BS.seedindex inside function
#' @param B Number of Bootstrap samples
#' @param BS.seedindex vector of BS seeds which are external generated
#' @param parallel Parallelized BS if \code{parallel=T} (strongly recommended)
#' @param cores Number of cores
#' @param dat Data for specific models (ussually not in use)
#' @param data Data for specific models (ussually not in use)
#' @param y response as in discmix
#' @param x design matrix for the model/preference component as in discmix
#' @param z design matrix for the weights as in discmix
#' @param u design matrix for the shape of the uncertainty component as in discmix
#' @param x.long design matrix for specific survival models as in discmix (usually not in use)
#' @param y.long response matrix for specific survival models as in discmix (usually not in use)
#' @param weights vector of individual weights different from one (ussually not in use)
#' @param M number of models/mixture components (usually 2)
#' @param model Choose the kind of Mixture Model to be fitted. For an overview see discmix
#' @param control control informations, i.e. \code{rel.tol} for relative tolerance or \code{max.iter} for maximum number of em iterations

#' @return List of length B (number of BS Samples); each element is one discmix output
#'
#' @author Micha Schneider
#'
#' @examples
#' # Data Generation
#' arthritis <- data.frame(drug=c(rep("new agent", 24+37+21+19+6),
#' rep("active control", 11+51+22+21+7)),
#' assessment=c(rep(1,24), rep(2,37), rep(3,21), rep(4,19), rep(5,6), rep(1,11),
#'              rep(2,51), rep(3,22), rep(4,21), rep(5,7)))
#'
#' # Response matrix y
#' table(arthritis$assessment, arthritis$drug)
#' y <- as.matrix(arthritis$assessment)
#' colnames(y) <- c("assessment")
#' head(y)
#'
#' # Design Matrix x
#' x <- matrix(1, nrow=nrow(arthritis), ncol = 1)
#' x[,1] <- arthritis$drug
#' x[,1] <- x[,1] - 1
#' colnames(x) <- c("drug")
#' head(x)
#'
#' # Bootstrap samples
#' set.seed(1000)
#' BS.seedindex  <- sample(x=seq(1000), 2)
#' boots <- bootp.discmix(B=2,y=y, x=x, BS.seedindex=BS.seedindex, model=uniform.cumlogit.mix.vgam, parallel=F)


bootp.discmix <- function (BS.seed=1000, B=2, BS.seedindex=NULL, parallel=T,cores=detectCores()-1, dat=NULL, data=NULL, # BS
                          y, x=NULL, z=NULL, u=NULL, x.long=NULL,y.long=NULL, weights=NULL, M = 2, model=uniform.cumlogit.mix.vgam, objectcall=NULL, # Model/daten
                          model.initialseed=1000,control = genmix.control(rel.tol=1e-6, max.iter=6000), control.init=genmix.control(),small.output=T,
                          cublass=F,cub=F,survival=F,alpha=NULL,family2=NA,sp=NULL,intercept.smooth=NULL,intercept.lambda=NULL,ti=NULL,event=NULL, postweight.init=NULL,
                          c.maxiter=NULL, maxiter1=NULL,maxiter2=NULL,pwi=c(0.6,0.7,0.8,0.9),nr.seeds=2,pwi.method="both",seed.init=1000,GEM=F,help=F,min.size=min(table(y))/2,min.size2=min.size,fn.val.option="NA",...)
{
  if(!is.null(objectcall)){

  if(is.expression(objectcall$model)){
    objectcall$model <- eval(objectcall$model)
  }}

  if(!is.null(weights))
    {
    if(length(weights) != NROW(y)){
      stop("weights and number of observations (in y) doesn't match")
      }
    }

  # BS-Index
  m <- length(unique(y))
  if(!is.null(ti)){m <- length(unique(ti))}
  n <- nrow(x)

  set.seed(BS.seed)
    bootindex <- vector("list", B)
    if (is.null(BS.seedindex)){
    for(i in seq(B)){
      sane.ind <- 0
      while(sane.ind < 1){
        bootindex[[i]] <- sample(seq(n), replace = T, size = n, prob=weights)
        # Test auf mehrere Intercept-Spalten (-> wenn bei einer Variable nur eine AusprÃ¤gung vorkommt)
        if(length(which(apply(x[bootindex[[i]], ], 2,
                              function(u) diff(range(u)) < .Machine$double.eps ^ 0.5))) == 1){
          # Test, ob in y alle Kategorien besetzt
          #if(all(colSums(dat$y[bootinds[[i]], ], na.rm=TRUE) >= 1)){ # Test bei 0-1 matrix
          if(length(unique(y[bootindex[[i]], ], na.rm=TRUE)) == m)
          {
            if(!is.null(z))
            {
              if(length(which(apply(z[bootindex[[i]], ], 2,
                                    function(u) diff(range(u)) < .Machine$double.eps ^ 0.5))) == 1)
              {
                sane.ind <- 1
              }
            }else{
              sane.ind <- 1
            }
          }
        }
      }
    }
  }else{
    tab0 <- table(y) # works only for vgam with 1,2,3,4,5,6,...
      if(!is.null(ti)){
        ti0 <- ti
        event_test0 <- event
        events0 <- ti0*event_test0
        tab0 <- table(events0)
      }
      n.fix <- 0
      for(k in 1:length(tab0)){
        if(tab0[k]<min.size2){
          n.fix <- c(n.fix,which(events0==as.numeric(names(tab0[k]))))}
        }
    for(i in seq(length(BS.seedindex))){
      if(length(n.fix)==1){
        set.seed(BS.seedindex[i])
        bootindex[[i]] <- sample(seq(n), replace = T, size = n, prob=weights)}else{
        set.seed(BS.seedindex[i])
        bootindex[[i]] <- c(n.fix[-1], sample(seq(n), replace = T, size = n-(length(n.fix)-1), prob=weights))
        #bootindex[[i]] <- c(n.fix, sample(seq(n)[-n.fix[-1]], replace = T, size = n-(length(n.fix)-1), prob=weights[-n.fix[-1]]))
      }
      check <- 0
      s <- 10
      bs.count <- 0
      BS.seedindex2 <- BS.seedindex[i]
      while(check < 1)
      {
        if(bs.count==300)
        {
         print(min.size.obs)
         warning("Restrictions on minimum number of observations are not in place")}
      y_test <- y[bootindex[[i]],]
      tab <- table(y_test) # works only for vgam with 1,2,3,4,5,6,...
      if(!is.null(ti)){
        ti_test <- ti[bootindex[[i]]]
        event_test <- event[bootindex[[i]]]
        tab <- table(ti_test*event_test)
        }
      if(min(tab) < min.size)
        {
        BS.seedindex2 <- BS.seedindex[i] + s
        while(BS.seedindex2%in%BS.seedindex)
          {
          BS.seedindex2 <- BS.seedindex2 + 10
          }
        set.seed(BS.seedindex2)
        bootindex[[i]] <- c(n.fix, sample(seq(n)[-n.fix], replace = T, size = n-(length(n.fix)-1), prob=weights[-n.fix]))
        # bootindex[[i]] <- sample(seq(n), replace = T, size = n, prob=weights)
        min.size.obs <- min(tab)
        s <- s + 10
        bs.count <- bs.count + 1
      }else{
        check <- 1
      }
      }
      BS.seedindex[i] <- BS.seedindex2
    }
  }
  print("BS.seedindex:")
  print(BS.seedindex)

  fitcall <- call("discmix", y=substitute(y), x=substitute(x), z=substitute(z), u=substitute(u),
                  x.long=substitute(x.long),y.long=substitute(y.long), ti=substitute(ti),event=substitute(event),
                  weights=substitute(weights), postweight.init=substitute(postweight.init),
                  model=model, M=M, initialseed=model.initialseed, control=control,
                  BS.seed=BS.seed, BS.seedindex=substitute(BS.seedindex),
                  c.maxiter=c.maxiter, maxiter1=maxiter1,maxiter2=maxiter2,pwi=pwi,
                  alpha=alpha,family2=family2,sp=sp,intercept.smooth=intercept.smooth,intercept.lambda=intercept.lambda,
                  nr.seeds=nr.seeds,pwi.method=pwi.method,seed.init=seed.init,GEM=GEM,parallel=F, help=help)

  bootcorepar <- function(i){
    bootcore(i = i)
  }

  # bootcore
  bootcore <- function(i){
    #require("MRSP")
    #require("VGAM")
    #require("DiscMix")
    ind <- bootindex[[i]]

      y <- y[ind,,drop=F]
    if(!is.null(x)){
      x <- x[ind,,drop=F] }
    if(!is.null(z)){
      z <- z[ind,,drop=F] }
    if(!is.null(u)){
      u <- u[ind,,drop=F] }
    if(!is.null(weights)){
      weights <- weights[ind] }
    if(!is.null(x.long)){
      x.long <- x.long[ind,] }
    if(!is.null(y.long)){
      y.long <- y.long[ind,] }
    if(!is.null(ti)){
      ti <- ti[ind] }
    if(!is.null(postweight.init)){
      postweight.init <- postweight.init[ind,] }
    if(!is.null(event)){
      event <- event[ind] }

    fitcall$y <- quote(y)
    fitcall$x <- quote(x)
    fitcall$z <- quote(z)
    fitcall$u <- quote(u)
    fitcall$x.long <- quote(x.long)
    fitcall$y.long <- quote(y.long)
    fitcall$ti <- quote(ti)
    fitcall$postweight.init <- quote(postweight.init)
    fitcall$event <- quote(event)
    fitcall$weights <- quote(weights)
    fitcall$BS.seedindex <- quote(BS.seedindex[i])

    fit <- try(eval(fitcall),TRUE)
    #print(!inherits(fit, 'try-error'))
    if (!inherits(fit, 'try-error')){#{print(fit); fit <- NULL}
    if(small.output==T){
    fit$weights <- NULL
    fit$model[[1]]$fit <- NULL
    fit$model[[1]]$mu <- NULL
    fit$model[[1]]$logl <- NULL
    fit$model[[2]]$fit <- NULL
    fit$model[[2]]$mu <- NULL
    fit$model[[2]]$logl <- NULL
    #fit$postweight <- NULL
    fit$postweight.eval <- NULL
    fit$pi.eval <- NULL
    fit$model.coef.eval <- NULL
    fit$model.coef.stand.eval <- NULL
    fit$concomitant.coef.eval <- NULL
    fit$concomitant.coef.stand.eval <- NULL
      }
    }
    fit
  }
  #error = function(e) return(paste("In BS-Sample",B,"caused the error: ", e)))
  #lapply(c(1,2,-3, 4), function(x){
  #  +     a <- try(stopifnot(x > 0))  # force an error
  #  +     if (inherits(a, 'try-error')) return(NULL)
  #  +     x
  #  + })
  # cores=10

  if(parallel){
    cl <- makeCluster(cores)
    clusterEvalQ(cl, {
      library(DiscMix)
    })#V2 #V3
    clusterExport(cl, c("fitcall","small.output","bootindex","BS.seedindex",
    "y","x","z","u","x.long","y.long","ti","postweight.init","event","weights"), envir=environment()) #V2
    #clusterExport(cl, c("fitcall","small.output"), envir=environment()) #V3 without bootindex
    #clusterExport(cl, ls(envir = sys.frame(sys.nframe())), envir = sys.frame(sys.nframe()))#V1
    #bootlist <- parLapply(cl, bootindex, indexcorepar) #V3
    bootlist <- parLapply(cl, seq(B), bootcorepar)#V1 #V2
    #bootlist <- parLapply(cl, seq(B), tryCatch(bootcorepar, error = function(e) {cat("Error in BS Sample",x,":"e); return(fit <- NULL)}))
    stopCluster(cl)
  }else{
    get(ls(envir = parent.frame()), envir = parent.frame())
    bootlist <- lapply(seq(B), bootcore)
  }
  return(bootlist)
}
