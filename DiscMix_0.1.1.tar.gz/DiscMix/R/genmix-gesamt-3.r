################################################################################
#####    An R Package for fitting general finite mixture models            #####
################################################################################
# authors of DiscMix: Micha Schneider \& Wolfgang Poessnecker

# MRSP
if(!("MRSP" %in% loadedNamespaces())){ library(MRSP) }  ## automatically loads packages parallel and compiler
multinomlogitmodel <- multinomlogit()
sequentiallogitmodel <- sequentiallogit()
cumulativelogitmodel <- cumulativelogit()
cubbinomialmodel <- CUBbinomiallogit()

## prevent dimension dropping on countless occasions in the code.
#`[` <- function(..., drop=FALSE) base::`[`(...,drop=drop)
# `[` <- function(..., drop=TRUE) base::`[`(...,drop=drop)



#source("genmix-classes-2.r")
#source("genmix-helpers-3.r")
#source("genmix-models-18.r")
#source("genmix-15.r")
#source("genmix_function6(4).r")
#source("bootp.genmix2.r")
#source("genmix2-14.r")
